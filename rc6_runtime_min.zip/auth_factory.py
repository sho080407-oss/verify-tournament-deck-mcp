from __future__ import annotations
import base64, ipaddress, json, os, socket, time
from urllib.parse import urlparse

# Imported only by the production MCP entry point; unit tests for verification logic do not require the MCP SDK.
from pydantic import AnyHttpUrl
from mcp.server.auth.provider import AccessToken, TokenVerifier
from mcp.server.auth.settings import AuthSettings


def _scope_list(raw):
    return raw.split() if isinstance(raw, str) else list(raw or [])


def _audience_ok(claims: dict, resource: str, *, require: bool = True) -> bool:
    aud = claims.get("aud") or claims.get("resource")
    if aud is None:
        return not require
    if isinstance(aud, list):
        return resource in [str(x) for x in aud]
    return str(aud) == resource


def _b64url_decode(value: str) -> bytes:
    value = value.strip()
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _b64url_uint(value: str) -> int:
    return int.from_bytes(_b64url_decode(value), "big")


def _dev_local_auth_allowed(url: str) -> bool:
    if os.environ.get("VTD_ENV", "development").lower() == "production":
        return False
    if os.environ.get("VTD_DEV_ALLOW_LOCAL_AUTH_SIM") != "1":
        return False
    p = urlparse(url)
    return p.scheme == "http" and (p.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}


def _validate_public_https(url: str, *, issuer: str | None = None) -> None:
    """Fail closed on non-HTTPS, local/private targets, and unapproved cross-origin JWKS hosts.

    A single development-only escape hatch exists for Bridge 19's localhost IdP
    simulator. It is impossible to activate when VTD_ENV=production.
    """
    p = urlparse(url)
    if _dev_local_auth_allowed(url):
        return
    if p.scheme != "https" or not p.hostname:
        raise RuntimeError("JWKS URL must use HTTPS")
    host = p.hostname.lower().rstrip(".")
    try:
        literal = ipaddress.ip_address(host)
        if literal.is_private or literal.is_loopback or literal.is_link_local or literal.is_multicast or literal.is_reserved or literal.is_unspecified:
            raise RuntimeError("JWKS URL may not use a private/local address")
    except ValueError:
        # DNS rebinding defense when DNS is available. A temporary DNS failure is not accepted in production setup.
        try:
            addrs = {x[4][0] for x in socket.getaddrinfo(host, p.port or 443, type=socket.SOCK_STREAM)}
        except socket.gaierror:
            addrs = set()
        if os.environ.get("VTD_ENV", "development").lower() == "production" and not addrs:
            raise RuntimeError("JWKS hostname does not resolve")
        for addr in addrs:
            try:
                ip = ipaddress.ip_address(addr)
            except ValueError:
                continue
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
                raise RuntimeError("JWKS hostname resolves to a private/local address")
    if issuer:
        issuer_host = (urlparse(issuer).hostname or "").lower().rstrip(".")
        if issuer_host and host != issuer_host:
            allow = {x.strip().lower().rstrip(".") for x in os.environ.get("VTD_AUTH_JWKS_HOST_ALLOWLIST", "").split(",") if x.strip()}
            if host not in allow:
                raise RuntimeError("cross-origin JWKS host is not allowlisted")


class StaticTokenVerifier(TokenVerifier):
    def __init__(self, resource: str, mapping: dict[str, dict]):
        self.resource = resource
        self.mapping = mapping

    async def verify_token(self, token: str):
        row = self.mapping.get(token)
        if not row:
            return None
        return AccessToken(
            token=token,
            client_id=str(row.get("client_id") or row.get("sub") or "static-client"),
            scopes=list(row.get("scopes") or ["deck:verify"]),
            resource=self.resource,
            subject=str(row.get("sub") or ""),
            claims={"iss": str(row.get("iss") or "static"), **row},
        )


class IntrospectionTokenVerifier(TokenVerifier):
    """OAuth 2.1 resource-server verifier backed by RFC 7662 token introspection."""

    def __init__(self, *, endpoint: str, client_id: str, client_secret: str, resource: str, issuer: str):
        self.endpoint = endpoint
        self.client_id = client_id
        self.client_secret = client_secret
        self.resource = resource
        self.issuer = issuer

    async def verify_token(self, token: str):
        import httpx

        async with httpx.AsyncClient(timeout=10, follow_redirects=False) as c:
            r = await c.post(
                self.endpoint,
                data={"token": token},
                auth=(self.client_id, self.client_secret),
                headers={"Accept": "application/json"},
            )
        if r.status_code != 200:
            return None
        try:
            d = r.json()
        except Exception:
            return None
        if not d.get("active"):
            return None
        token_issuer = str(d.get("iss") or "")
        if not token_issuer or token_issuer != self.issuer:
            return None
        # OpenAI's MCP OAuth contract requires tokens to be minted for this exact
        # protected resource and to carry the tool scope.  Do not accept an
        # otherwise-active opaque token that omits audience/resource.
        if not _audience_ok(d, self.resource, require=True):
            return None
        subject = str(d.get("sub") or "")
        if not subject:
            return None
        scopes = _scope_list(d.get("scope") or d.get("scp") or [])
        if "deck:verify" not in scopes:
            return None
        return AccessToken(
            token=token,
            client_id=str(d.get("client_id") or d.get("azp") or subject),
            scopes=scopes,
            resource=self.resource,
            subject=subject,
            expires_at=int(d["exp"]) if d.get("exp") else None,
            claims=d,
        )


class JWKSJWTTokenVerifier(TokenVerifier):
    """Offline access-token verification against an issuer-published JWKS.

    The verifier deliberately supports a small, explicit algorithm set and performs all
    resource-server checks itself. It never accepts `alg=none`, symmetric JWT algorithms,
    or a token without issuer/audience/expiry/subject/required scope.
    """

    SUPPORTED_ALGORITHMS = {"RS256", "RS384", "RS512", "PS256", "PS384", "PS512", "ES256", "ES384"}

    def __init__(
        self,
        *,
        jwks_url: str,
        resource: str,
        issuer: str,
        required_scopes: list[str] | None = None,
        algorithms: list[str] | None = None,
        cache_ttl_seconds: int = 300,
        clock_skew_seconds: int = 60,
    ):
        self.jwks_url = jwks_url
        self.resource = resource
        self.issuer = issuer
        self.required_scopes = list(required_scopes or ["deck:verify"])
        requested = list(algorithms or ["RS256"])
        unsupported = [x for x in requested if x not in self.SUPPORTED_ALGORITHMS]
        if unsupported:
            raise RuntimeError("unsupported JWT algorithms: " + ",".join(unsupported))
        self.algorithms = requested
        self.cache_ttl_seconds = max(30, int(cache_ttl_seconds))
        self.clock_skew_seconds = max(0, int(clock_skew_seconds))
        self._jwks: dict | None = None
        self._jwks_loaded_at = 0.0
        _validate_public_https(self.jwks_url, issuer=self.issuer)

    async def _fetch_jwks(self, *, force: bool = False) -> dict:
        now = time.monotonic()
        if not force and self._jwks is not None and now - self._jwks_loaded_at < self.cache_ttl_seconds:
            return self._jwks
        import httpx

        async with httpx.AsyncClient(timeout=10, follow_redirects=False) as c:
            r = await c.get(self.jwks_url, headers={"Accept": "application/json"})
        if r.status_code != 200:
            raise RuntimeError("JWKS endpoint returned non-200")
        try:
            doc = r.json()
        except Exception as e:
            raise RuntimeError("JWKS response is not JSON") from e
        keys = doc.get("keys") if isinstance(doc, dict) else None
        if not isinstance(keys, list) or not keys:
            raise RuntimeError("JWKS contains no keys")
        self._jwks = {"keys": keys}
        self._jwks_loaded_at = now
        return self._jwks

    @staticmethod
    def _public_key(jwk: dict):
        from cryptography.hazmat.primitives.asymmetric import ec, rsa

        if jwk.get("kty") == "RSA":
            if not jwk.get("n") or not jwk.get("e"):
                raise ValueError("RSA JWK missing n/e")
            return rsa.RSAPublicNumbers(_b64url_uint(jwk["e"]), _b64url_uint(jwk["n"])).public_key()
        if jwk.get("kty") == "EC":
            crv = jwk.get("crv")
            curves = {"P-256": ec.SECP256R1, "P-384": ec.SECP384R1}
            if crv not in curves or not jwk.get("x") or not jwk.get("y"):
                raise ValueError("unsupported/incomplete EC JWK")
            return ec.EllipticCurvePublicNumbers(_b64url_uint(jwk["x"]), _b64url_uint(jwk["y"]), curves[crv]()).public_key()
        raise ValueError("unsupported JWK kty")

    async def _find_key(self, kid: str, alg: str) -> dict | None:
        for force in (False, True):
            doc = await self._fetch_jwks(force=force)
            candidates = [k for k in doc["keys"] if str(k.get("kid") or "") == kid]
            for key in candidates:
                if key.get("use") not in (None, "sig"):
                    continue
                key_ops = key.get("key_ops")
                if key_ops is not None and (not isinstance(key_ops, list) or "verify" not in key_ops):
                    continue
                if key.get("alg") and key.get("alg") != alg:
                    continue
                return key
        return None

    @staticmethod
    def _verify_signature(*, alg: str, public_key, signing_input: bytes, signature: bytes) -> None:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import ec, padding
        from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

        hashes_by_alg = {
            "RS256": hashes.SHA256, "PS256": hashes.SHA256, "ES256": hashes.SHA256,
            "RS384": hashes.SHA384, "PS384": hashes.SHA384, "ES384": hashes.SHA384,
            "RS512": hashes.SHA512, "PS512": hashes.SHA512,
        }
        h = hashes_by_alg[alg]()
        if alg.startswith("RS"):
            public_key.verify(signature, signing_input, padding.PKCS1v15(), h)
            return
        if alg.startswith("PS"):
            public_key.verify(signature, signing_input, padding.PSS(mgf=padding.MGF1(h), salt_length=h.digest_size), h)
            return
        if alg.startswith("ES"):
            expected = 64 if alg == "ES256" else 96
            if len(signature) != expected:
                raise ValueError("invalid ECDSA JWT signature length")
            half = expected // 2
            der = encode_dss_signature(int.from_bytes(signature[:half], "big"), int.from_bytes(signature[half:], "big"))
            public_key.verify(der, signing_input, ec.ECDSA(h))
            return
        raise ValueError("unsupported JWT algorithm")

    async def verify_token(self, token: str):
        try:
            if len(token) > 65536:
                return None
            parts = token.split(".")
            if len(parts) != 3:
                return None
            header = json.loads(_b64url_decode(parts[0]))
            claims = json.loads(_b64url_decode(parts[1]))
            if not isinstance(header, dict) or not isinstance(claims, dict):
                return None
            alg = str(header.get("alg") or "")
            kid = str(header.get("kid") or "")
            # This verifier does not define any critical JOSE extensions.  A token
            # declaring one must be rejected rather than silently ignoring it.
            if header.get("crit"):
                return None
            if alg not in self.algorithms or alg not in self.SUPPORTED_ALGORITHMS or not kid:
                return None
            jwk = await self._find_key(kid, alg)
            if not jwk:
                return None
            public_key = self._public_key(jwk)
            signing_input = f"{parts[0]}.{parts[1]}".encode("ascii")
            self._verify_signature(alg=alg, public_key=public_key, signing_input=signing_input, signature=_b64url_decode(parts[2]))

            now = int(time.time())
            skew = self.clock_skew_seconds
            issuer = str(claims.get("iss") or "")
            if not issuer or issuer != self.issuer:
                return None
            if not _audience_ok(claims, self.resource, require=True):
                return None
            exp = claims.get("exp")
            if exp is None or int(exp) < now - skew:
                return None
            if claims.get("nbf") is not None and int(claims["nbf"]) > now + skew:
                return None
            if claims.get("iat") is not None and int(claims["iat"]) > now + skew:
                return None
            subject = str(claims.get("sub") or "")
            if not subject:
                return None
            scopes = _scope_list(claims.get("scope") or claims.get("scp") or [])
            if any(s not in scopes for s in self.required_scopes):
                return None
            return AccessToken(
                token=token,
                client_id=str(claims.get("client_id") or claims.get("azp") or subject),
                scopes=scopes,
                resource=self.resource,
                subject=subject,
                expires_at=int(exp),
                claims=claims,
            )
        except Exception:
            return None


def build_auth():
    env = os.environ.get("VTD_ENV", "development").lower()
    mode = os.environ.get("VTD_AUTH_MODE", "disabled").lower()
    resource = os.environ.get("VTD_PUBLIC_MCP_URL", "http://127.0.0.1:8000/mcp")
    if mode == "disabled":
        if env == "production":
            raise RuntimeError("VTD_AUTH_MODE=disabled is forbidden in production")
        return None, None
    issuer = os.environ.get("VTD_AUTH_ISSUER_URL")
    if not issuer:
        raise RuntimeError("VTD_AUTH_ISSUER_URL is required when auth is enabled")
    settings = AuthSettings(
        issuer_url=AnyHttpUrl(issuer),
        resource_server_url=AnyHttpUrl(resource),
        required_scopes=["deck:verify"],
        validate_token_resource=True,
    )
    if mode == "static":
        if env == "production":
            raise RuntimeError("VTD_AUTH_MODE=static is forbidden in production")
        mapping = json.loads(os.environ.get("VTD_STATIC_TOKENS_JSON", "{}"))
        if not mapping:
            raise RuntimeError("VTD_STATIC_TOKENS_JSON is required for static auth")
        return settings, StaticTokenVerifier(resource, mapping)
    if mode == "introspection":
        endpoint = os.environ.get("VTD_TOKEN_INTROSPECTION_URL")
        cid = os.environ.get("VTD_INTROSPECTION_CLIENT_ID")
        secret = os.environ.get("VTD_INTROSPECTION_CLIENT_SECRET")
        if not all((endpoint, cid, secret)):
            raise RuntimeError("introspection endpoint/client credentials are required")
        return settings, IntrospectionTokenVerifier(endpoint=endpoint, client_id=cid, client_secret=secret, resource=resource, issuer=issuer)
    if mode in {"jwt", "jwks", "jwt_jwks", "oidc", "oidc_jwks"}:
        jwks_url = os.environ.get("VTD_JWKS_URL")
        if mode in {"oidc", "oidc_jwks"}:
            from oidc_discovery import resolve_jwks_uri
            jwks_url, _, _ = resolve_jwks_uri(issuer=issuer, discovery_url=os.environ.get("VTD_OIDC_DISCOVERY_URL"))
        if not jwks_url:
            raise RuntimeError("VTD_JWKS_URL is required for JWT/JWKS auth")
        algorithms = [x.strip() for x in os.environ.get("VTD_JWT_ALGORITHMS", "RS256").split(",") if x.strip()]
        return settings, JWKSJWTTokenVerifier(
            jwks_url=jwks_url,
            resource=resource,
            issuer=issuer,
            required_scopes=["deck:verify"],
            algorithms=algorithms,
            cache_ttl_seconds=int(os.environ.get("VTD_JWKS_CACHE_TTL", "300")),
            clock_skew_seconds=int(os.environ.get("VTD_JWT_CLOCK_SKEW", "60")),
        )
    raise RuntimeError(f"unsupported VTD_AUTH_MODE: {mode}")
