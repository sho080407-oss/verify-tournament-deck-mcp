from __future__ import annotations
from safe_download import download_limited, SafeDownloadError

"""Historical v20.17.x runtime bundle restoration and lineage replay.

Archives are treated as untrusted input. They are quarantined, safely extracted, and
never executed until the historical checkpoint/explicit manifest covers every semantic
runtime delta introduced by that lineage stage. Each accepted stage is content-addressed
by parent runtime fingerprint + archive hash + selected historical hash set.
"""

import hashlib
import json
import os
import shutil
import stat
import tempfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

MAX_ARCHIVE_BYTES = int(os.environ.get("VTD_MAX_RUNTIME_ARCHIVE_BYTES", str(256 * 1024 * 1024)))
MAX_EXTRACTED_BYTES = int(os.environ.get("VTD_MAX_RUNTIME_EXTRACTED_BYTES", str(1024 * 1024 * 1024)))
MAX_ARCHIVE_FILES = int(os.environ.get("VTD_MAX_RUNTIME_ARCHIVE_FILES", "25000"))
MAX_COMPRESSION_RATIO = float(os.environ.get("VTD_MAX_RUNTIME_COMPRESSION_RATIO", "250"))
RUNTIME_PREFIXES = ("engine/", "scripts/", "references/")


class RuntimeRestoreError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return sha256_bytes(raw)


def normalize_relpath(value: str) -> str:
    raw = str(value).replace("\\", "/").strip()
    while raw.startswith("./"):
        raw = raw[2:]
    p = PurePosixPath(raw)
    if not raw or p.is_absolute() or ".." in p.parts:
        raise RuntimeRestoreError(f"unsafe archive path: {value!r}")
    return p.as_posix()


def _zip_member_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return stat.S_ISLNK(mode)


def safe_extract_zip(archive_path: str | Path, destination: str | Path) -> dict[str, Any]:
    archive_path = Path(archive_path)
    destination = Path(destination)
    if archive_path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise RuntimeRestoreError("runtime archive exceeds size limit")
    destination.mkdir(parents=True, exist_ok=True)
    total = 0
    count = 0
    rows: list[dict[str, Any]] = []
    root_resolved = destination.resolve()
    with zipfile.ZipFile(archive_path, "r") as zf:
        infos = zf.infolist()
        if len(infos) > MAX_ARCHIVE_FILES:
            raise RuntimeRestoreError("runtime archive contains too many files")
        for info in infos:
            rel = normalize_relpath(info.filename)
            if info.flag_bits & 0x1:
                raise RuntimeRestoreError(f"encrypted ZIP member is not allowed: {rel}")
            if _zip_member_is_symlink(info):
                raise RuntimeRestoreError(f"symlink ZIP member is not allowed: {rel}")
            target = destination / rel
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            count += 1
            total += int(info.file_size)
            if total > MAX_EXTRACTED_BYTES:
                raise RuntimeRestoreError("runtime archive extracted size exceeds limit")
            if info.compress_size and info.file_size / max(1, info.compress_size) > MAX_COMPRESSION_RATIO:
                raise RuntimeRestoreError(f"suspicious compression ratio: {rel}")
            target.parent.mkdir(parents=True, exist_ok=True)
            resolved_parent = target.parent.resolve()
            if root_resolved != resolved_parent and root_resolved not in resolved_parent.parents:
                raise RuntimeRestoreError(f"archive member escaped destination: {rel}")
            with zf.open(info, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
            rows.append({"path": rel, "size": int(info.file_size), "sha256": sha256_file(target)})
    rows.sort(key=lambda x: x["path"])
    return {"file_count": count, "total_uncompressed_bytes": total, "files": rows, "manifest_sha256": canonical_hash(rows)}


def semantic_runtime_manifest(root: str | Path) -> dict[str, str]:
    root = Path(root)
    out: dict[str, str] = {}
    for rel_root in ("engine", "scripts", "references"):
        base = root / rel_root
        if not base.exists():
            continue
        for p in sorted(x for x in base.rglob("*") if x.is_file() and x.suffix in {".py", ".json", ".md", ".yaml", ".yml"}):
            out[p.relative_to(root).as_posix()] = sha256_file(p)
    return out


def bundle_fingerprint(root: str | Path) -> str:
    # Must remain byte-for-byte compatible with LegacyV20171Bridge.bundle_fingerprint().
    root = Path(root)
    rows = []
    for rel_root in ("engine", "scripts", "references"):
        base = root / rel_root
        if not base.exists():
            continue
        for p in sorted(x for x in base.rglob("*") if x.is_file() and x.suffix in {".py", ".json", ".md", ".yaml", ".yml"}):
            data = p.read_bytes()
            rows.append([str(p.relative_to(root)), hashlib.sha256(data).hexdigest(), len(data)])
    return canonical_hash(rows)


def _manifest_from_explicit(expected_manifest: dict | None) -> tuple[dict[str, str], str | None, str | None]:
    if not isinstance(expected_manifest, dict):
        return {}, None, None
    files = expected_manifest.get("files") or expected_manifest.get("file_hashes") or expected_manifest.get("runtime_hashes") or {}
    normalized: dict[str, str] = {}
    if isinstance(files, dict):
        for k, v in files.items():
            if isinstance(v, dict):
                v = v.get("sha256") or v.get("hash")
            if isinstance(v, str) and len(v.strip()) >= 32:
                try:
                    normalized[normalize_relpath(str(k))] = v.strip().lower()
                except RuntimeRestoreError:
                    continue
    archive_sha = expected_manifest.get("archive_sha256") or expected_manifest.get("package_sha256")
    bundle_fp = expected_manifest.get("engine_bundle_fingerprint")
    return normalized, str(archive_sha).lower() if archive_sha else None, str(bundle_fp) if bundle_fp else None


def _runtime_hashes(value: dict[str, str]) -> dict[str, str]:
    return {k: v for k, v in value.items() if str(k).startswith(RUNTIME_PREFIXES)}


def _candidate_clean(row: dict) -> dict[str, Any] | None:
    if not isinstance(row, dict):
        return None
    hashes = row.get("hashes") if isinstance(row.get("hashes"), dict) else {}
    clean: dict[str, str] = {}
    for k, v in hashes.items():
        if isinstance(v, dict):
            v = v.get("sha256") or v.get("hash")
        if isinstance(v, str) and len(v.strip()) >= 32:
            try:
                clean[normalize_relpath(str(k))] = v.strip().lower()
            except RuntimeRestoreError:
                continue
    if not clean:
        return None
    return {"source": row.get("source") or "legacy_checkpoint", "hashes": clean, "priority": int(row.get("priority", 10))}


def merge_expected_hashes(
    checkpoint_hash_sets: list[dict] | None,
    explicit_manifest: dict | None = None,
    *,
    payload_runtime_manifest: dict[str, str] | None = None,
    source_hint: str | None = None,
) -> dict[str, Any]:
    explicit_files, archive_sha, explicit_bundle_fp = _manifest_from_explicit(explicit_manifest)
    candidates: list[dict[str, Any]] = []
    if explicit_files:
        candidates.append({"source": "explicit_manifest", "hashes": explicit_files, "priority": 1000})
    for row in checkpoint_hash_sets or []:
        c = _candidate_clean(row)
        if c:
            candidates.append(c)

    hint = (source_hint or "").casefold().strip()
    payload = payload_runtime_manifest or {}
    scored = []
    for c in candidates:
        runtime = _runtime_hashes(c["hashes"])
        matched = sum(1 for k, v in runtime.items() if payload.get(k) == v)
        present = sum(1 for k in runtime if k in payload)
        ratio = matched / max(1, len(runtime))
        hint_match = bool(hint and hint in str(c["source"]).casefold())
        c = dict(c)
        c.update({"runtime_hashes": runtime, "payload_matches": matched, "payload_present": present, "payload_match_ratio": ratio, "hint_match": hint_match})
        scored.append(c)
    # Explicit manifest wins. Otherwise choose the historical set that best matches the archive payload;
    # a caller-provided stage hint breaks ties and avoids applying CP12R expectations to a CP12T patch.
    scored.sort(key=lambda x: (
        -int(x["source"] == "explicit_manifest"),
        -int(x.get("hint_match", False)),
        -float(x.get("payload_match_ratio", 0.0)),
        -int(x.get("payload_matches", 0)),
        -int(x.get("priority", 0)),
        -len(x.get("runtime_hashes") or {}),
        str(x.get("source")),
    ))
    selected = scored[0] if scored else {"source": None, "hashes": {}, "runtime_hashes": {}, "priority": 0}
    return {
        "selected_source": selected.get("source"),
        "files": selected.get("runtime_hashes") or {},
        "all_selected_hashes": selected.get("hashes") or {},
        "ignored_nonruntime_hashes": {k: v for k, v in (selected.get("hashes") or {}).items() if k not in (selected.get("runtime_hashes") or {})},
        "candidate_sets": scored,
        "archive_sha256": archive_sha,
        "engine_bundle_fingerprint": explicit_bundle_fp,
    }


def detect_runtime_roots(extracted: str | Path) -> list[Path]:
    """Find complete runnable package roots only."""
    extracted = Path(extracted)
    roots: list[Path] = []
    for p in [extracted, *[x for x in extracted.rglob("*") if x.is_dir()]]:
        if (p / "engine").is_dir() and (p / "scripts" / "research_engine.py").is_file():
            roots.append(p)
    uniq = {str(p.resolve()): p for p in roots}
    return sorted(uniq.values(), key=lambda p: (len(p.relative_to(extracted).parts) if p != extracted else 0, p.as_posix()))


def detect_overlay_roots(extracted: str | Path) -> list[Path]:
    """Find partial historical runtime overlays.

    A valid v20.17.x runtime delta is not limited to ``engine/``. Historical
    lineage can legitimately change ``scripts/`` or ``references/`` only, so a
    ZIP containing one of those semantic runtime trees must still be eligible
    for hash-authorized overlay reconstruction. Evidence-only archives (for
    example a lone checkpoint.json) intentionally do not match this detector.
    """
    extracted = Path(extracted)
    roots: list[Path] = []
    semantic_suffixes = {".py", ".json", ".md", ".yaml", ".yml"}
    for p in [extracted, *[x for x in extracted.rglob("*") if x.is_dir()]]:
        # Complete packages are handled by detect_runtime_roots().
        if (p / "engine").is_dir() and (p / "scripts" / "research_engine.py").is_file():
            continue
        has_runtime_tree = any((p / rel.rstrip("/")).is_dir() for rel in RUNTIME_PREFIXES)
        if not has_runtime_tree:
            continue
        has_semantic_payload = False
        for rel in RUNTIME_PREFIXES:
            base = p / rel.rstrip("/")
            if not base.is_dir():
                continue
            if any(x.is_file() and x.suffix in semantic_suffixes for x in base.rglob("*")):
                has_semantic_payload = True
                break
        if has_semantic_payload:
            roots.append(p)
    uniq = {str(p.resolve()): p for p in roots}
    return sorted(uniq.values(), key=lambda p: (0 if p.name == "runtime_overlay" else 1, len(p.parts), p.as_posix()))


def _overlay_tree(src: Path, dst: Path) -> None:
    """Overlay a whole semantic tree.

    This is used only when the archive/bundle itself is independently authorized.
    Historical checkpoint hash sets normally use _overlay_expected_files() instead,
    so helper scripts or unrelated evidence carried beside a runtime overlay cannot
    silently become executable runtime state.
    """
    for p in sorted(src.rglob("*")):
        rel = p.relative_to(src)
        if any(part in {"__MACOSX", ".git", "runtime", "runtime_overlay", ".research-cache", "__pycache__"} for part in rel.parts):
            continue
        if rel.parts and rel.parts[0] not in {"engine", "scripts", "references"}:
            continue
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif p.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)


def _overlay_expected_files(roots: list[Path], dst: Path, expected_files: dict[str, str]) -> dict[str, Any]:
    """Apply only files explicitly authorized by a historical hash set.

    A root becomes part of the executable lineage only when it contains at least
    one expected path with the expected SHA-256. Extra semantic files inside such
    a selected root are treated as unverified deltas and quarantine the stage.
    Sibling provenance/helper trees that contain no expected runtime file are not
    promoted into the runtime at all.
    """
    copied: list[str] = []
    missing_payload: list[str] = []
    hash_mismatch_payload: dict[str, list[str]] = {}
    selected_roots: dict[str, Path] = {}
    matches_by_rel: dict[str, list[Path]] = {}

    for rel, want in sorted(expected_files.items()):
        rel = normalize_relpath(rel)
        if not rel.startswith(RUNTIME_PREFIXES):
            continue
        candidates: list[tuple[Path, Path]] = []
        for root in roots:
            candidate = root / rel
            if candidate.is_file():
                candidates.append((root, candidate))
        # Deduplicate identical files reachable through duplicate root discovery.
        uniq = {str(x.resolve()): (r, x) for r, x in candidates}
        candidates = list(uniq.values())
        matching = [(r, x) for r, x in candidates if sha256_file(x).lower() == str(want).lower()]
        if matching:
            matching.sort(key=lambda rx: (len(rx[0].parts), rx[0].as_posix(), rx[1].as_posix()))
            matches_by_rel[rel] = [x for _, x in matching]
            # Prefer the most specific root (runtime_overlay beats an ancestor bundle root).
            root, src = sorted(matching, key=lambda rx: (-len(rx[0].parts), rx[0].as_posix()))[0]
            selected_roots[str(root.resolve())] = root
            target = dst / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, target)
            copied.append(rel)
        elif candidates:
            hash_mismatch_payload[rel] = [sha256_file(x).lower() for _, x in candidates]
        else:
            # A hash may describe a file unchanged from the parent; compare_expected
            # will verify the inherited copy after overlay application.
            missing_payload.append(rel)

    selected_payload_manifest: dict[str, str] = {}
    for root in selected_roots.values():
        selected_payload_manifest.update(semantic_runtime_manifest(root))
    unexpected_selected_semantic = sorted(
        rel for rel in selected_payload_manifest
        if rel not in expected_files
    )
    return {
        "copied": copied,
        "missing_payload": missing_payload,
        "hash_mismatch_payload": hash_mismatch_payload,
        "selected_roots": [str(x) for x in sorted(selected_roots.values(), key=lambda p: p.as_posix())],
        "unexpected_selected_semantic": unexpected_selected_semantic,
    }


def compare_expected(root: str | Path, expected: dict[str, str]) -> dict[str, Any]:
    root = Path(root)
    matched: list[str] = []
    mismatched: dict[str, dict[str, str | None]] = {}
    missing: list[str] = []
    for rel, want in sorted(expected.items()):
        p = root / rel
        if not p.is_file():
            missing.append(rel)
            continue
        got = sha256_file(p)
        if got.lower() == str(want).lower():
            matched.append(rel)
        else:
            mismatched[rel] = {"expected": str(want).lower(), "actual": got.lower()}
    return {"expected_count": len(expected), "matched_count": len(matched), "matched": matched, "missing": missing, "mismatched": mismatched, "all_expected_match": bool(expected) and not missing and not mismatched}


def _payload_runtime_manifest(full_roots: list[Path], overlay_roots: list[Path]) -> dict[str, str]:
    if full_roots:
        return semantic_runtime_manifest(full_roots[0])
    merged: dict[str, str] = {}
    for root in overlay_roots:
        merged.update(semantic_runtime_manifest(root))
    return merged


def _make_writable(root: Path) -> None:
    for p in [root, *list(root.rglob("*"))]:
        try:
            if p.is_dir():
                os.chmod(p, 0o755)
            elif p.is_file():
                os.chmod(p, 0o644)
        except OSError:
            pass


def _make_read_only(root: Path) -> None:
    # Files first, dirs last. Read/execute stays available; mutation is removed.
    for p in sorted(root.rglob("*"), key=lambda x: len(x.parts), reverse=True):
        try:
            if p.is_file():
                os.chmod(p, 0o444)
            elif p.is_dir():
                os.chmod(p, 0o555)
        except OSError:
            pass
    try:
        os.chmod(root, 0o555)
    except OSError:
        pass


class HistoricalRuntimeRestorer:
    def __init__(self, storage_root: str | Path, clean_base_root: str | Path):
        self.storage_root = Path(storage_root)
        self.clean_base_root = Path(clean_base_root).resolve()
        self.storage_root.mkdir(parents=True, exist_ok=True)

    def _run_root(self, run_id: str) -> Path:
        safe = "".join(ch for ch in run_id if ch.isalnum() or ch in "._-")
        if safe != run_id or not safe:
            raise RuntimeRestoreError("invalid run_id")
        p = self.storage_root / safe
        p.mkdir(parents=True, exist_ok=True)
        return p

    def download_file(self, file_obj: dict) -> Path:
        url = str(file_obj.get("download_url") or "").strip()
        if not url:
            raise RuntimeRestoreError("runtime_bundle_file.download_url is required")
        name = str(file_obj.get("file_name") or "historical-runtime.zip")
        if Path(name).suffix.lower() != ".zip":
            raise RuntimeRestoreError("historical runtime bundle must be a ZIP archive")
        try:
            return download_limited(url=url, storage_root=self.storage_root, filename="runtime-bundle.zip", max_bytes=MAX_ARCHIVE_BYTES, user_agent="verify-tournament-deck-v20.18.22")
        except SafeDownloadError as e:
            raise RuntimeRestoreError(str(e)) from e

    def register_archive_path(
        self,
        *,
        run_id: str,
        archive_path: str | Path,
        checkpoint_hash_sets: list[dict] | None = None,
        expected_manifest: dict | None = None,
        source_file: dict | None = None,
        base_runtime_root: str | Path | None = None,
        source_hint: str | None = None,
    ) -> dict[str, Any]:
        archive_path = Path(archive_path)
        if not archive_path.is_file():
            raise RuntimeRestoreError("runtime archive not found")
        archive_sha = sha256_file(archive_path)
        explicit_files, explicit_archive_sha, _ = _manifest_from_explicit(expected_manifest)
        if explicit_archive_sha and archive_sha.lower() != explicit_archive_sha.lower():
            return {"schema": "v20.18-historical-runtime-v2", "status": "REJECTED_ARCHIVE_HASH_MISMATCH", "activated": False, "archive_sha256": archive_sha, "expected_archive_sha256": explicit_archive_sha, "source_file": source_file or {}}

        base_root = Path(base_runtime_root).resolve() if base_runtime_root else self.clean_base_root
        if not (base_root / "engine").is_dir() or not (base_root / "scripts" / "research_engine.py").is_file():
            raise RuntimeRestoreError("base runtime is not a runnable v20.17.x package")
        parent_fp = bundle_fingerprint(base_root)

        # Extract to a temporary quarantine first so the selected historical hash set can be
        # chosen by actual archive payload, not merely checkpoint priority.
        scratch = Path(tempfile.mkdtemp(prefix="vtd-lineage-stage-", dir=self.storage_root))
        quarantine_tmp = scratch / "quarantine"
        extract_meta = safe_extract_zip(archive_path, quarantine_tmp)
        full_roots = detect_runtime_roots(quarantine_tmp)
        overlay_roots = detect_overlay_roots(quarantine_tmp)
        payload_manifest = _payload_runtime_manifest(full_roots, overlay_roots)
        expected = merge_expected_hashes(checkpoint_hash_sets, expected_manifest, payload_runtime_manifest=payload_manifest, source_hint=source_hint)

        stage_id = canonical_hash({"parent_engine_bundle": parent_fp, "archive_sha256": archive_sha, "expected_source": expected.get("selected_source"), "expected_files": expected.get("files")})
        run_root = self._run_root(run_id)
        package_root = run_root / stage_id
        quarantine = package_root / "quarantine"
        restored = package_root / "restored"
        if package_root.exists():
            # Content-addressed rerun should be deterministic; recreate to avoid stale partial data.
            try:
                shutil.rmtree(package_root)
            except PermissionError:
                # A previously sealed exact stage is immutable. Reuse it only if metadata exists.
                meta = package_root / "stage.json"
                if meta.is_file():
                    return json.loads(meta.read_text(encoding="utf-8"))
                raise
        package_root.mkdir(parents=True, exist_ok=True)
        shutil.move(str(quarantine_tmp), str(quarantine))
        shutil.rmtree(scratch, ignore_errors=True)

        runtime_payload_present = bool(full_roots or overlay_roots)
        # Paths moved from scratch to package quarantine; rediscover there.
        full_roots = detect_runtime_roots(quarantine)
        overlay_roots = detect_overlay_roots(quarantine)
        runtime_kind = "full_runtime" if full_roots else ("runtime_overlay" if overlay_roots else "evidence_only")
        expected_files = expected.get("files") or {}
        overlay_application = {"copied": [], "missing_payload": [], "hash_mismatch_payload": {}, "selected_roots": [], "unexpected_selected_semantic": []}
        if full_roots:
            shutil.copytree(full_roots[0], restored)
        else:
            shutil.copytree(base_root, restored)
            # Parent stages are sealed read-only; the child is a new content-addressed copy.
            _make_writable(restored)
            if expected_files:
                # Checkpoint-driven lineage: promote only independently hashed runtime files.
                overlay_application = _overlay_expected_files(overlay_roots, restored, expected_files)
            else:
                # Archive/bundle-authorized lineage may intentionally carry a complete overlay.
                for overlay in overlay_roots:
                    _overlay_tree(overlay, restored)

        comparison = compare_expected(restored, expected_files)
        semantic = semantic_runtime_manifest(restored)
        semantic_fp = bundle_fingerprint(restored)
        base_semantic = semantic_runtime_manifest(base_root)
        changed_from_base = sorted(k for k, v in semantic.items() if base_semantic.get(k) != v)
        removed_from_base = sorted(k for k in base_semantic if k not in semantic)
        expected_covered_changes = sorted(k for k in changed_from_base if expected_files.get(k) == semantic.get(k))
        unverified_changed_semantic = sorted(
            (set(changed_from_base) - set(expected_covered_changes))
            | set(overlay_application.get("unexpected_selected_semantic") or [])
        )
        archive_authorized = bool(explicit_archive_sha and archive_sha.lower() == explicit_archive_sha.lower())
        bundle_authorized = bool(
            expected.get("engine_bundle_fingerprint")
            and semantic_fp == expected["engine_bundle_fingerprint"]
        )
        # Delta authorization is intentionally strict: every semantic change from
        # the parent runtime must be named by an independently sourced expected
        # hash and no parent semantic file may silently disappear.
        delta_authorized = bool(expected_files) and not unverified_changed_semantic and not removed_from_base
        executable_surface = (restored / "engine").is_dir() and (restored / "scripts" / "research_engine.py").is_file()
        execution_authorized = runtime_payload_present and executable_surface and (
            archive_authorized or bundle_authorized or delta_authorized
        )
        lineage_match = bool(
            comparison.get("all_expected_match")
            or archive_authorized
            or bundle_authorized
        )
        exact = bool(lineage_match and execution_authorized)

        # When neither payload nor independent lineage evidence exists, report
        # the provenance failure first. This keeps evidence-only ZIPs distinct
        # from known-hash runtime bundles whose payload is malformed/missing.
        if not expected_files and not expected.get("engine_bundle_fingerprint") and not archive_authorized:
            status = "QUARANTINED_NO_EXPECTED_HASHES"
        elif not runtime_payload_present:
            status = "QUARANTINED_NO_RUNTIME_PAYLOAD"
        elif not executable_surface:
            status = "QUARANTINED_NOT_EXECUTABLE_RUNTIME"
        elif comparison.get("mismatched") or comparison.get("missing"):
            status = "QUARANTINED_HASH_MISMATCH"
        elif not execution_authorized:
            status = "QUARANTINED_UNVERIFIED_SEMANTIC_DELTA"
        elif not exact:
            status = "QUARANTINED_LINEAGE_NOT_EXACT"
        else:
            status = "HASH_VERIFIED_PENDING_SELF_TEST"

        record = {
            "schema": "v20.18-historical-runtime-v2",
            "status": status,
            "activated": False,
            "lineage_stage_id": stage_id,
            "parent_runtime_root": str(base_root),
            "parent_engine_bundle_fingerprint": parent_fp,
            "archive_sha256": archive_sha,
            "source_file": {k: v for k, v in (source_file or {}).items() if k != "download_url"},
            "archive": extract_meta,
            "runtime_kind": runtime_kind,
            "runtime_root": str(restored),
            "detected_full_runtime_roots": [str(x.relative_to(quarantine)) for x in full_roots[:10]],
            "detected_overlay_roots": [str(x.relative_to(quarantine)) for x in overlay_roots[:10]],
            "expected_hash_source": expected.get("selected_source"),
            "expected_hash_count": len(expected_files),
            "ignored_nonruntime_hash_count": len(expected.get("ignored_nonruntime_hashes") or {}),
            "comparison": comparison,
            "engine_bundle_fingerprint": semantic_fp,
            "executable_surface": executable_surface,
            "changed_from_parent": changed_from_base,
            "changed_from_clean": changed_from_base if base_root == self.clean_base_root else None,
            "removed_from_parent": removed_from_base,
            "expected_covered_changes": expected_covered_changes,
            "unverified_changed_semantic": unverified_changed_semantic,
            "archive_authorized": archive_authorized,
            "bundle_authorized": bundle_authorized,
            "delta_authorized": delta_authorized,
            "execution_authorized": execution_authorized,
            "lineage_match": lineage_match,
            "candidate_hash_sets": [{"source": x.get("source"), "count": len(x.get("runtime_hashes") or {}), "payload_matches": x.get("payload_matches"), "payload_match_ratio": x.get("payload_match_ratio"), "hint_match": x.get("hint_match")} for x in expected.get("candidate_sets") or []],
            "overlay_application": overlay_application,
        }
        (package_root / "stage.json").write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
        return record

    def seal_verified_runtime(self, record: dict[str, Any]) -> dict[str, Any]:
        root = Path(str(record.get("runtime_root") or ""))
        if not root.is_dir():
            raise RuntimeRestoreError("verified runtime root missing")
        # Recompute immediately before sealing.
        fp = bundle_fingerprint(root)
        if fp != record.get("engine_bundle_fingerprint"):
            raise RuntimeRestoreError("runtime changed before sealing")
        _make_read_only(root)
        record = dict(record)
        record["sealed_read_only"] = True
        record["sealed_engine_bundle_fingerprint"] = fp
        stage_meta = root.parent / "stage.json"
        try:
            stage_meta.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
            os.chmod(stage_meta, 0o444)
        except OSError:
            pass
        return record
