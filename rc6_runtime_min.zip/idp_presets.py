from __future__ import annotations

from dataclasses import dataclass, asdict
from urllib.parse import urlparse

from oidc_discovery import validate_chatgpt_oauth_metadata, validate_workspace_domain_metadata


@dataclass(frozen=True)
class IdPPreset:
    id: str
    display_name: str
    issuer_examples: tuple[str, ...]
    discovery: str
    client_registration: str
    preferred_client_mode: str
    notes: tuple[str, ...]
    manual_checks: tuple[str, ...]

    def to_dict(self) -> dict:
        d = asdict(self)
        d["issuer_examples"] = list(self.issuer_examples)
        d["notes"] = list(self.notes)
        d["manual_checks"] = list(self.manual_checks)
        return d


PRESETS: dict[str, IdPPreset] = {
    "auth0": IdPPreset(
        id="auth0",
        display_name="Auth0",
        issuer_examples=("https://TENANT.REGION.auth0.com/", "https://login.example.com/"),
        discovery="OIDC discovery at <issuer>/.well-known/openid-configuration",
        client_registration="CIMD when enabled; DCR via /oidc/register when tenant DCR is explicitly enabled; predefined client also supported",
        preferred_client_mode="cimd_or_predefined",
        notes=(
            "Auth0 DCR is disabled by default and is open registration when enabled.",
            "DCR-created third-party clients require PKCE and explicit API grants/default permissions for API scope access.",
            "Legacy Auth0 tenants can have permissive DCR behavior; strict third-party security/default API access must be checked before relying on DCR scopes.",
        ),
        manual_checks=(
            "The API identifier/audience used by Auth0 must equal the canonical MCP resource URL that ChatGPT sends in resource=.",
            "The deck:verify permission/scope must be granted to the client path actually used by ChatGPT.",
            "If using DCR, verify the tenant has DCR enabled and third-party application security is strict enough to preserve the requested API scope.",
        ),
    ),
    "okta": IdPPreset(
        id="okta",
        display_name="Okta",
        issuer_examples=("https://ORG.okta.com/oauth2/default", "https://ORG.okta.com/oauth2/AUTH_SERVER_ID"),
        discovery="OIDC/OAuth metadata from the selected authorization server",
        client_registration="CIMD when enabled on the org/custom authorization server; predefined client is stable; DCR/MCP registration availability is tenant/feature dependent and must be discovered",
        preferred_client_mode="cimd_or_predefined",
        notes=(
            "Use a custom authorization server for tokens meant for your MCP API; the org authorization server is primarily for Okta resources.",
            "Okta added CIMD support and MCP/DCR-related registration capabilities in 2026, but availability can depend on org features/rollout.",
        ),
        manual_checks=(
            "Issuer should normally contain /oauth2/<authorization-server-id> for a custom authorization server.",
            "The authorization server must mint aud/resource exactly for the canonical MCP resource and include deck:verify.",
            "Do not assume a registration endpoint is usable just because an Okta API can create clients; require advertised metadata/CIMD or a predefined client.",
        ),
    ),
    "keycloak": IdPPreset(
        id="keycloak",
        display_name="Keycloak",
        issuer_examples=("https://id.example.com/realms/REALM",),
        discovery="OIDC discovery at /realms/<realm>/.well-known/openid-configuration",
        client_registration="OIDC DCR endpoint /realms/<realm>/clients-registrations/openid-connect; commonly protected by registration policy/token, so predefined client is the safest default unless open DCR is intentionally configured",
        preferred_client_mode="predefined_or_open_dcr",
        notes=(
            "Keycloak exposes a standards-based OpenID Connect dynamic client registration endpoint.",
            "Client registration commonly requires an Initial Access Token or an authenticated registration policy; endpoint presence alone does not prove ChatGPT can register automatically.",
        ),
        manual_checks=(
            "Issuer must identify the intended realm (/realms/<realm>), not the Keycloak root URL.",
            "If relying on DCR, verify anonymous/open registration policy is intentionally enabled for the OpenID Connect registration endpoint or use a predefined client.",
            "Configure an audience mapper/client scope so the access token aud/resource includes the canonical MCP resource exactly and contains deck:verify.",
        ),
    ),
    "entra": IdPPreset(
        id="entra",
        display_name="Microsoft Entra ID",
        issuer_examples=("https://login.microsoftonline.com/TENANT_ID/v2.0",),
        discovery="OIDC discovery at the tenant-specific v2.0 authority",
        client_registration="Predefined/static OAuth client required; Microsoft Entra ID does not publish an RFC 7591 registration endpoint",
        preferred_client_mode="predefined",
        notes=(
            "Microsoft Entra ID supports securing MCP servers with the RFC 8707 resource parameter when the MCP canonical resource URL exactly matches the API Application ID URI.",
            "DCR is not available for Entra-protected MCP servers; register the OAuth client statically.",
        ),
        manual_checks=(
            "Use a tenant-specific issuer rather than common/organizations/consumers so token issuer validation is deterministic.",
            "Set the MCP server app registration Application ID URI to the exact canonical MCP resource URL advertised in protected-resource metadata.",
            "Configure the API for v2 access tokens, expose/grant deck:verify, register the exact ChatGPT redirect URI shown in the MCP management page, and ensure required consent is granted.",
        ),
    ),
    "generic": IdPPreset(
        id="generic",
        display_name="Generic OAuth/OIDC 2.1 provider",
        issuer_examples=("https://auth.example.com/",),
        discovery="OIDC Discovery or RFC 8414 authorization-server metadata",
        client_registration="CIMD preferred; otherwise DCR or a predefined client",
        preferred_client_mode="cimd",
        notes=("No provider-specific assumptions are made.",),
        manual_checks=(
            "Provider must echo resource through authorization/token requests into aud/resource of the access token.",
            "Provider must publish S256 PKCE and a usable CIMD/DCR/predefined client path.",
        ),
    ),
}


def get_preset(provider: str) -> IdPPreset:
    key = (provider or "generic").strip().lower()
    aliases = {"microsoft": "entra", "azure": "entra", "azuread": "entra", "msentra": "entra", "auth-0": "auth0"}
    key = aliases.get(key, key)
    if key not in PRESETS:
        raise ValueError(f"unknown identity provider preset: {provider}")
    return PRESETS[key]


def infer_provider(issuer: str) -> str:
    host = (urlparse(issuer).hostname or "").lower()
    path = urlparse(issuer).path or ""
    if host.endswith("auth0.com"):
        return "auth0"
    if host.endswith("okta.com") or host.endswith("oktapreview.com"):
        return "okta"
    if host == "login.microsoftonline.com" or host.endswith("login.microsoftonline.us") or host.endswith("login.chinacloudapi.cn"):
        return "entra"
    if "/realms/" in path:
        return "keycloak"
    return "generic"


def _provider_shape_checks(provider: str, issuer: str, *, predefined_client: bool, keycloak_open_dcr: bool) -> tuple[list[str], list[str], dict]:
    blockers: list[str] = []
    warnings: list[str] = []
    checks: dict = {}
    p = urlparse(issuer)
    path = p.path or ""
    host = (p.hostname or "").lower()
    if provider == "auth0":
        checks["issuer_shape"] = issuer.startswith("https://")
        warnings.append("Auth0 DCR is opt-in; prefer CIMD or a predefined client unless open DCR is intentional and API grants are configured.")
    elif provider == "okta":
        checks["custom_authorization_server"] = "/oauth2/" in path
        if not checks["custom_authorization_server"]:
            blockers.append("Okta preset requires a custom authorization server issuer containing /oauth2/<id> for MCP API tokens")
    elif provider == "keycloak":
        checks["realm_issuer"] = "/realms/" in path
        if not checks["realm_issuer"]:
            blockers.append("Keycloak issuer must identify a realm (/realms/<realm>)")
        if not predefined_client and not keycloak_open_dcr:
            warnings.append("Keycloak DCR endpoint presence does not prove anonymous registration; declare --keycloak-open-dcr only after intentionally enabling an open registration policy, or use a predefined client.")
    elif provider == "entra":
        checks["tenant_specific_v2_issuer"] = host.startswith("login.microsoftonline.") and path.endswith("/v2.0") and all(x not in path.lower().split("/") for x in ("common", "organizations", "consumers"))
        if not checks["tenant_specific_v2_issuer"]:
            blockers.append("Entra preset requires a tenant-specific .../<tenant-id>/v2.0 issuer")
        checks["predefined_client"] = predefined_client
        if not predefined_client:
            blockers.append("Microsoft Entra ID does not expose RFC 7591 DCR for MCP; use a predefined/static OAuth client")
    return blockers, warnings, checks


def validate_preset_configuration(*, provider: str, issuer: str, predefined_client: bool = False, keycloak_open_dcr: bool = False) -> dict:
    preset = get_preset(provider)
    blockers, warnings, checks = _provider_shape_checks(preset.id, issuer, predefined_client=predefined_client, keycloak_open_dcr=keycloak_open_dcr)
    if preset.id == "keycloak" and not predefined_client and not keycloak_open_dcr:
        blockers.append("Keycloak preset requires either a predefined client or explicit --keycloak-open-dcr attestation before deployment")
    return {
        "ok": not blockers,
        "provider": preset.id,
        "display_name": preset.display_name,
        "checks": checks,
        "blockers": list(dict.fromkeys(blockers)),
        "warnings": list(dict.fromkeys(warnings)),
        "manual_checks": list(preset.manual_checks),
    }


def evaluate_provider_compatibility(
    *,
    provider: str,
    issuer: str,
    metadata: dict,
    mcp_url: str,
    predefined_client: bool = False,
    keycloak_open_dcr: bool = False,
) -> dict:
    preset = get_preset(provider)
    generic = validate_chatgpt_oauth_metadata(issuer=issuer, metadata=metadata, predefined_client=predefined_client)
    workspace = validate_workspace_domain_metadata(issuer=issuer, metadata=metadata)
    blockers = list(generic["blockers"]) + list(workspace["blockers"])
    warnings: list[str] = list(generic.get("warnings") or [])
    pblock, pwarn, pchecks = _provider_shape_checks(preset.id, issuer, predefined_client=predefined_client, keycloak_open_dcr=keycloak_open_dcr)
    blockers.extend(pblock); warnings.extend(pwarn)

    discovered_mode = generic["checks"].get("client_registration_mode", "none")
    mode = "predefined" if predefined_client else discovered_mode
    if preset.id == "auth0" and mode == "dcr":
        warnings.append("Auth0 DCR must be enabled explicitly and deck:verify must be part of the API access/default permissions for third-party clients.")
    if preset.id == "okta" and mode == "dcr":
        warnings.append("Okta DCR/MCP registration capability can be feature/rollout dependent; confirm the advertised registration endpoint works for the intended org.")
    if preset.id == "keycloak" and mode == "dcr" and not keycloak_open_dcr and not predefined_client:
        blockers.append("Keycloak DCR selected but anonymous/open DCR was not explicitly attested; endpoint may require an Initial Access Token")
    if preset.id == "entra" and mode != "predefined":
        blockers.append("Entra requires predefined/static client registration")

    provider_ready = not blockers
    return {
        "ok": provider_ready,
        "status": "IDP_COMPATIBLE_PRELIVE" if provider_ready else "IDP_COMPATIBILITY_BLOCKED",
        "provider": preset.id,
        "display_name": preset.display_name,
        "issuer": issuer,
        "mcp_resource": mcp_url,
        "generic_oauth_checks": generic["checks"],
        "workspace_identity_checks": workspace["checks"],
        "userinfo_endpoint": workspace["userinfo_endpoint"],
        "provider_checks": pchecks,
        "client_registration_mode": mode,
        "preferred_client_mode": preset.preferred_client_mode,
        "blockers": blockers,
        "warnings": warnings,
        "manual_checks": list(preset.manual_checks),
        "preset": preset.to_dict(),
        "live_resource_echo": "PENDING_TOKEN_FLOW",
    }
