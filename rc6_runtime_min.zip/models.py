from __future__ import annotations
from typing import Any, Literal
from pydantic import BaseModel, Field

class CardCount(BaseModel):
    name: str
    # Generic upper bound. Per-game legality is enforced by the legacy game plugin/ruleset.
    count: int = Field(ge=0, le=60)

class DeckInput(BaseModel):
    main: list[CardCount]
    extra: list[CardCount] = []
    side: list[CardCount] = []

class RulesetInput(BaseModel):
    jurisdiction: str
    effective_date: str | None = None
    locked: bool = False

class RunSummary(BaseModel):
    run_id: str
    label: str | None = None
    status: str
    current_stage: str
    next_stage: str | None = None
    final_label: str
    checkpoint_id: str | None = None
    fingerprints: dict[str, str] = {}
    reused_evidence: list[str] = []
    invalidated_evidence: list[str] = []
    blockers: list[str] = []
    final_gate: dict[str, Any] = {}
    incremental_plan_summary: dict[str, Any] = {}

class Change(BaseModel):
    zone: Literal['main','extra']
    card: str
    delta: int


class OpenAIFile(BaseModel):
    download_url: str
    file_id: str
    mime_type: str | None = None
    file_name: str | None = None
