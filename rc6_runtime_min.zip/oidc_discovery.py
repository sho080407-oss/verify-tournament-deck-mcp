from __future__ import annotations
import ipaddress, os, socket
from urllib.parse import urlparse


class OIDCDiscoveryError(RuntimeError):
    pass


def _dev_local_auth_allowed(url: str) -> bool:
    if os.environ.get("VTD_ENV", "development").lower() == "production":
        return False
    if os.environ.get("VTD_DEV_ALLOW_LOCAL_AUTH_SIM") != "1":
        return False
    p = urlparse(url)
    return p.scheme == "http" and (p.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}


def _public_https(url: str, *, issuer: str | None = None, purpose: str = "OIDC metadata") -> None:
    p = urlparse(url)
    if _dev_local_auth_allowed(url):
        return
    if p.scheme != "https" or not p.hostname:
        raise OIDCDiscoveryError(f"{purpose} URL must use HTTPS")
    host = p.hostname.lower().rstrip(".")
    try:
        ip = ipaddress.ip_address(host)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            raise OIDCDiscoveryError(f"{purpose} URL may not use a private/local address")
    except ValueError:
        if os.environ.get("VTD_ENV", "development").lower() != "production" and os.environ.get("VTD_SKIP_AUTH_DNS_CHECK") == "1":
            addrs = set()
        else:
            try:
                addrs = {x[4][0] for x in socket.getaddrinfo(host, p.port or 443, type=socket.SOCK_STREAM)}
            except socket.gaierror:
                addrs = set()
        if os.environ.get("VTD_ENV", "development").lower() == "production" and not addrs:
            raise OIDCDiscoveryError(f"{purpose} hostname does not resolve")
        for raw in addrs:
            try:
                ip = ipaddress.ip_address(raw)
            except ValueError:
                continue
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
                raise OIDCDiscoveryError(f"{purpose} hostname resolves to a private/local address")
    if issuer:
        issuer_host = (urlparse(issuer).hostname or "").lower().rstrip(".")
        if issuer_host and host != issuer_host:
            allow = {x.strip().lower().rstrip(".") for x in os.environ.get("VTD_AUTH_JWKS_HOST_ALLOWLIST", "").split(",") if x.strip()}
            if host not in allow:
                raise OIDCDiscoveryError(f"cross-origin {purpose} host is not allowlisted")


def discovery_candidates(issuer: str) -> list[str]:
    """Return standards-based discovery candidates without normalizing issuer identity.

    OIDC Discovery appends `/.well-known/openid-configuration` to the issuer.
    RFC 8414 inserts `/.well-known/oauth-authorization-server` before an issuer path.
    """
    p = urlparse(issuer)
    if (p.scheme != "https" and not _dev_local_auth_allowed(issuer)) or not p.netloc or p.query or p.fragment:
        raise OIDCDiscoveryError("issuer must be an HTTPS URL without query/fragment")
    base = issuer.rstrip("/")
    oidc = base + "/.well-known/openid-configuration"
    path = p.path or ""
    oauth = f"{p.scheme}://{p.netloc}/.well-known/oauth-authorization-server{path.rstrip('/')}"
    out = []
    for u in (oidc, oauth):
        if u not in out:
            out.append(u)
    return out


def _fetch_json(url: str) -> dict:
    import httpx
    with httpx.Client(timeout=10, follow_redirects=False) as c:
        r = c.get(url, headers={"Accept": "application/json"})
    if r.status_code != 200:
        raise OIDCDiscoveryError(f"discovery endpoint returned {r.status_code}")
    try:
        doc = r.json()
    except Exception as e:
        raise OIDCDiscoveryError("discovery response is not JSON") from e
    if not isinstance(doc, dict):
        raise OIDCDiscoveryError("discovery response must be an object")
    return doc


def resolve_authorization_metadata(*, issuer: str, discovery_url: str | None = None, fetcher=None) -> tuple[dict, str]:
    fetcher = fetcher or _fetch_json
    candidates = [discovery_url] if discovery_url else discovery_candidates(issuer)
    errors = []
    for url in candidates:
        if not url:
            continue
        try:
            _public_https(url, issuer=issuer, purpose="OIDC discovery")
            doc = fetcher(url)
            if doc.get("issuer") != issuer:
                raise OIDCDiscoveryError("discovery issuer does not exactly match configured issuer")
            return doc, url
        except Exception as e:
            errors.append(f"{url}: {e}")
    raise OIDCDiscoveryError("authorization-server discovery failed: " + " | ".join(errors))


def resolve_jwks_uri(*, issuer: str, discovery_url: str | None = None, fetcher=None) -> tuple[str, dict, str]:
    doc, used = resolve_authorization_metadata(issuer=issuer, discovery_url=discovery_url, fetcher=fetcher)
    jwks = str(doc.get("jwks_uri") or "")
    if not jwks:
        raise OIDCDiscoveryError("authorization metadata is missing jwks_uri")
    _public_https(jwks, issuer=issuer, purpose="JWKS")
    return jwks, doc, used



def validate_workspace_domain_metadata(*, issuer: str, metadata: dict) -> dict:
    """Validate the OIDC identity contract used by ChatGPT workspace domain restrictions.

    Public OAuth plugins should advertise enabled `openid` and `email` scopes and
    a UserInfo Endpoint.  Runtime verification of `email` and
    `email_verified: true` is handled by the workspace identity preflight script.
    """
    blockers = []
    checks = {}
    scopes = metadata.get("scopes_supported") or []
    checks["openid_scope_advertised"] = isinstance(scopes, list) and "openid" in scopes
    checks["email_scope_advertised"] = isinstance(scopes, list) and "email" in scopes
    if not checks["openid_scope_advertised"]:
        blockers.append("authorization server must advertise and enable openid scope")
    if not checks["email_scope_advertised"]:
        blockers.append("authorization server must advertise and enable email scope")
    endpoint = str(metadata.get("userinfo_endpoint") or "")
    try:
        _public_https(endpoint, issuer=issuer, purpose="userinfo_endpoint")
        checks["userinfo_endpoint_https"] = True
    except Exception:
        checks["userinfo_endpoint_https"] = False
        blockers.append("authorization server must advertise a safe UserInfo Endpoint")
    return {
        "ok": not blockers,
        "checks": checks,
        "blockers": blockers,
        "userinfo_endpoint": endpoint,
    }

def validate_chatgpt_oauth_metadata(*, issuer: str, metadata: dict, predefined_client: bool = False) -> dict:
    """Validate the discovery fields ChatGPT needs before it can link an MCP server.

    This checks not only that client registration is advertised, but also that a
    usable HTTPS DCR endpoint exists and that a CIMD-only deployment exposes a
    token endpoint authentication method ChatGPT can use (none/private_key_jwt).
    """
    blockers = []
    warnings = []
    checks = {}
    checks["issuer_exact"] = metadata.get("issuer") == issuer
    if not checks["issuer_exact"]:
        blockers.append("issuer mismatch")
    for key in ("authorization_endpoint", "token_endpoint"):
        value = str(metadata.get(key) or "")
        try:
            _public_https(value, issuer=issuer, purpose=key)
            checks[key + "_https"] = True
        except Exception:
            checks[key + "_https"] = False
            blockers.append(f"{key} missing or unsafe")
    pkce = metadata.get("code_challenge_methods_supported") or []
    checks["pkce_s256"] = isinstance(pkce, list) and "S256" in pkce
    if not checks["pkce_s256"]:
        blockers.append("code_challenge_methods_supported must include S256")
    methods = metadata.get("token_endpoint_auth_methods_supported") or []
    checks["token_auth_methods_declared"] = isinstance(methods, list) and bool(methods)
    if not checks["token_auth_methods_declared"]:
        blockers.append("token_endpoint_auth_methods_supported missing")
    method_set={str(x) for x in methods} if isinstance(methods,list) else set()
    cimd = metadata.get("client_id_metadata_document_supported") is True
    reg=str(metadata.get("registration_endpoint") or "")
    dcr=False
    if reg:
        try:
            _public_https(reg, issuer=issuer, purpose="registration_endpoint")
            dcr=True
            checks["registration_endpoint_https"] = True
        except Exception:
            checks["registration_endpoint_https"] = False
            blockers.append("registration_endpoint is advertised but missing or unsafe")
    else:
        checks["registration_endpoint_https"] = False
    cimd_methods={"none","private_key_jwt"}
    checks["cimd_token_auth_compatible"] = (not cimd) or bool(method_set & cimd_methods)
    if cimd and not checks["cimd_token_auth_compatible"]:
        if not dcr and not predefined_client:
            blockers.append("CIMD is the only client-registration path but token_endpoint_auth_methods_supported has no ChatGPT-compatible none/private_key_jwt method")
        else:
            warnings.append("CIMD is advertised without a ChatGPT-compatible none/private_key_jwt token method; explicitly use DCR/predefined client or fix authorization-server metadata")
    checks["client_registration_available"] = cimd or dcr or predefined_client
    checks["client_registration_mode"] = "cimd" if cimd and checks["cimd_token_auth_compatible"] else "dcr" if dcr else "predefined" if predefined_client else "cimd_incompatible" if cimd else "none"
    if not checks["client_registration_available"]:
        blockers.append("no CIMD, safe DCR, or declared predefined client")
    checks["issuer_identification"] = metadata.get("authorization_response_iss_parameter_supported") is True
    # Issuer identification is preferred and enables the stable redirect URI, but OpenAI also supports callback-specific redirects.
    return {"ok": not blockers, "checks": checks, "blockers": blockers, "warnings": warnings}
