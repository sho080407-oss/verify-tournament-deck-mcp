from __future__ import annotations

"""Fail-closed importer for historical v20.17.x checkpoint JSON.

The importer intentionally separates *historical claims* from *authorized reusable
engine evidence*. A legacy Final Gate PASS is preserved as provenance, but it never
sets a v20.18 run to TOURNAMENT_FINAL_CONFIRMED. Reuse is authorized only after the
current run assets are attached and the available historical fingerprints match the
current dependency context.
"""

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from evidence_dag import (
    build_context,
    native_dependency_fingerprint,
    opening_analysis_fingerprint,
    sha256_obj,
)

PASS_WORDS = ("PASS", "PASS_", "PASS;", "PASS ")


def _root(doc: dict) -> dict:
    return doc.get("payload") if isinstance(doc.get("payload"), dict) else doc


def _checkpoint_id(doc: dict) -> str:
    r = _root(doc)
    return str(r.get("checkpoint_id") or r.get("checkpoint") or doc.get("checkpoint") or doc.get("stage") or "legacy-checkpoint")


def _created_at(doc: dict) -> str | None:
    r = _root(doc)
    return r.get("created_at_jst") or r.get("created_date_jst") or doc.get("created_at_jst") or doc.get("created_date_jst")


def _sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json_hash_variants(value: Any) -> dict[str, str]:
    variants = {
        "canonical_compact": json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8"),
        "pretty_indent2": json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8"),
        "pretty_indent2_newline": (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
        "default_sorted": json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8"),
    }
    return {k: _sha256_bytes(v) for k, v in variants.items()}


def _passish(value: Any) -> bool:
    if value is True:
        return True
    if isinstance(value, dict):
        if value.get("ok") is True or value.get("verified") is True:
            return True
        st = value.get("status")
        return isinstance(st, str) and st.upper().startswith("PASS")
    if isinstance(value, str):
        return value.strip().upper().startswith("PASS") or "FINAL GATE: PASS" in value.upper()
    return False


def _zone_rows(value: Any) -> list[dict]:
    rows: list[dict] = []
    if isinstance(value, dict):
        for name, count in value.items():
            try:
                c = int(count)
            except Exception:
                continue
            if str(name).strip() and c > 0:
                rows.append({"name": str(name).strip(), "count": c})
    elif isinstance(value, list):
        for row in value:
            if isinstance(row, dict):
                name = str(row.get("name", "")).strip()
                try:
                    c = int(row.get("count", 0))
                except Exception:
                    continue
                if name and c > 0:
                    rows.append({"name": name, "count": c})
            elif isinstance(row, (list, tuple)) and len(row) >= 2:
                name = str(row[0]).strip()
                try:
                    c = int(row[1])
                except Exception:
                    continue
                if name and c > 0:
                    rows.append({"name": name, "count": c})
    merged: dict[str, int] = {}
    for row in rows:
        merged[row["name"]] = merged.get(row["name"], 0) + int(row["count"])
    return [{"name": k, "count": merged[k]} for k in sorted(merged)]


def _deck_from_root(r: dict) -> dict | None:
    candidates = []
    if isinstance(r.get("deck_freeze"), dict):
        candidates.append(r["deck_freeze"])
    if isinstance(r.get("current_deck"), dict):
        candidates.append(r["current_deck"])
    if "current_main" in r or "current_extra" in r:
        candidates.append({"main": r.get("current_main"), "extra": r.get("current_extra")})
    if isinstance(r.get("deck"), dict):
        candidates.append(r["deck"])
    for c in candidates:
        main = _zone_rows(c.get("main"))
        extra = _zone_rows(c.get("extra"))
        side = _zone_rows(c.get("side"))
        if main or extra:
            return {"main": main, "extra": extra, "side": side}
    return None


def _declared_deck_fingerprint(r: dict) -> str | None:
    for obj in (r, r.get("deck_freeze"), r.get("current_deck"), r.get("player_deck"), r.get("fingerprints")):
        if not isinstance(obj, dict):
            continue
        for key in ("deck_fingerprint", "fingerprint", "analysis_fingerprint"):
            val = obj.get(key)
            if isinstance(val, str) and val.strip():
                return val.strip()
    return None


def _date_from_text(text: str) -> str | None:
    m = re.search(r"(20\d{2})[-_/](\d{2})[-_/](\d{2})", text or "")
    return "-".join(m.groups()) if m else None


def _ruleset_from_root(r: dict) -> dict | None:
    rs = r.get("ruleset")
    if isinstance(rs, dict):
        effective = rs.get("effective_date") or rs.get("effective_limit") or rs.get("current_effective_limit") or rs.get("previous_effective_limit")
        effective = str(effective) if effective else None
        effective = _date_from_text(effective or "") or effective
        return {
            "jurisdiction": str(rs.get("jurisdiction") or "Japan OCG"),
            "effective_date": effective,
            "locked": bool(rs.get("locked") or rs.get("locked_by_user")),
            "legacy_declared": copy.deepcopy(rs),
        }
    for value in (r.get("regulation"), (r.get("engine") or {}).get("ruleset") if isinstance(r.get("engine"), dict) else None):
        if isinstance(value, str) and value.strip():
            return {
                "jurisdiction": "Japan OCG" if "OCG" in value.upper() else "unknown",
                "effective_date": _date_from_text(value),
                "locked": "lock" in value.casefold() or "固定" in value,
                "legacy_declared": value,
            }
    return None


def _effective_date(ruleset: dict | None) -> str | None:
    if not isinstance(ruleset, dict):
        return None
    return ruleset.get("effective_date") or ruleset.get("effective_limit") or ruleset.get("current_effective_limit")


def _same_ruleset(a: dict | None, b: dict | None) -> bool:
    if not a or not b:
        return False
    ad, bd = _effective_date(a), _effective_date(b)
    aj = str(a.get("jurisdiction", "")).casefold()
    bj = str(b.get("jurisdiction", "")).casefold()
    return bool(ad and bd and ad == bd and (not aj or not bj or aj == bj))


def _claims_from_root(r: dict) -> dict[str, dict]:
    claims: dict[str, dict] = {}
    sources: dict[str, list[str]] = {}

    def mark(node: str, value: Any, source: str, *, structured: bool = False, evidence: Any = None):
        if not _passish(value):
            return
        cur = claims.setdefault(node, {"pass_claim": True, "structured": False, "evidence": None, "sources": []})
        cur["structured"] = bool(cur["structured"] or structured)
        if evidence is not None and cur.get("evidence") is None:
            cur["evidence"] = copy.deepcopy(evidence)
        cur["sources"].append(source)

    v = r.get("verification") if isinstance(r.get("verification"), dict) else {}
    sem = v.get("whole_dsl_semantic_fidelity")
    if isinstance(sem, dict) and sem.get("ok") is True:
        mark("WHOLE_DSL_SEMANTIC_FIDELITY", True, "verification.whole_dsl_semantic_fidelity", structured=True, evidence=sem)
    fr = v.get("full_regression")
    if isinstance(fr, dict) and _passish(fr):
        mark("FULL_REGRESSION", True, "verification.full_regression", structured=True, evidence=fr)
    if _passish(v.get("tournament_final_status")):
        mark("TOURNAMENT_FINAL", v.get("tournament_final_status"), "verification.tournament_final_status")

    retained = r.get("retained_player_evidence") if isinstance(r.get("retained_player_evidence"), dict) else {}
    for key, val in retained.items():
        k = str(key).casefold()
        if "semantic" in k:
            mark("WHOLE_DSL_SEMANTIC_FIDELITY", val, f"retained_player_evidence.{key}")
        if "regression" in k:
            mark("FULL_REGRESSION", val, f"retained_player_evidence.{key}")

    reused = r.get("reused_without_recompute") if isinstance(r.get("reused_without_recompute"), dict) else {}
    mapping = {
        "whole_dsl_semantic_fidelity": "WHOLE_DSL_SEMANTIC_FIDELITY",
        "full_regression": "FULL_REGRESSION",
        "tournament_final": "TOURNAMENT_FINAL",
    }
    for key, node in mapping.items():
        mark(node, reused.get(key), f"reused_without_recompute.{key}")

    pipeline = r.get("final_pipeline") if isinstance(r.get("final_pipeline"), dict) else {}
    for key, node in {
        "reality_calibration": "REALITY_CALIBRATION",
        "sealed_holdout": "SEALED_HOLDOUT",
        "final_ci": "FINAL_CI",
        "final_gate": "FINAL_GATE",
    }.items():
        mark(node, pipeline.get(key), f"final_pipeline.{key}")

    # Direct structured v20.17.1 result-like payloads are the strongest import source.
    direct = {
        "whole_dsl_semantic_fidelity": "WHOLE_DSL_SEMANTIC_FIDELITY",
        "full_regression": "FULL_REGRESSION",
        "tournament_final_suite": "TOURNAMENT_FINAL",
        "sealed_holdout": "SEALED_HOLDOUT",
        "final_ci": "FINAL_CI",
    }
    for key, node in direct.items():
        value = r.get(key)
        if isinstance(value, dict) and _passish(value if key != "tournament_final_suite" else value.get("suite_pre_holdout_ready")):
            mark(node, True, key, structured=True, evidence=value)
    fg = r.get("final_gate")
    if isinstance(fg, dict):
        mark("FINAL_GATE", fg, "final_gate", structured=True, evidence=fg)
    else:
        mark("FINAL_GATE", fg, "final_gate")

    # Late v20.17.1 lineages may provide the Final Gate document itself as a related
    # evidence JSON. Its sub-evidence can be imported independently; the historical
    # Final Gate PASS remains quarantined and must never certify v20.18 directly.
    schema = str(r.get("schema") or "")
    if schema.startswith("tournament-final-gate-") and _passish(r):
        ev = r.get("evidence") if isinstance(r.get("evidence"), dict) else {}
        mark("FINAL_GATE", True, "gate_document", structured=True, evidence=r)
        if _passish(ev.get("full_regression")):
            mark("FULL_REGRESSION", True, "gate_document.evidence.full_regression", structured=False, evidence=ev.get("full_regression"))
        tf = ev.get("tournament_final")
        if isinstance(tf, dict) and _passish(tf):
            mark("TOURNAMENT_FINAL", True, "gate_document.evidence.tournament_final", structured=True, evidence=tf)
        sh = ev.get("sealed_holdout")
        if isinstance(sh, dict) and _passish(sh):
            mark("SEALED_HOLDOUT", True, "gate_document.evidence.sealed_holdout", structured=True, evidence=sh)
        ci = ev.get("final_ci")
        if isinstance(ci, dict) and _passish(ci):
            mark("FINAL_CI", True, "gate_document.evidence.final_ci", structured=True, evidence=ci)
        rc = ev.get("reality_calibration")
        if _passish(rc):
            mark("REALITY_CALIBRATION", True, "gate_document.evidence.reality_calibration", structured=isinstance(rc, dict), evidence=rc if isinstance(rc, dict) else None)

    # Opening exact is historically represented as a resume flag or prose claim.
    rp = r.get("resume_policy") if isinstance(r.get("resume_policy"), dict) else {}
    if rp.get("opening_exact_658008_reused") is True or rp.get("recomputed_opening_exact") is False:
        mark("OPENING_EXACT", True, "resume_policy.opening_exact")

    completed = r.get("completed_range") or []
    if isinstance(completed, list):
        for i, raw in enumerate(completed):
            s = str(raw)
            u = s.upper()
            if "OPENING" in u and ("EXACT" in u or "658,008" in s or "658008" in s) and ("REUS" in u or "PASS" in u):
                mark("OPENING_EXACT", True, f"completed_range[{i}]")
            if "WHOLE-DSL SEMANTIC FIDELITY PASS" in u:
                mark("WHOLE_DSL_SEMANTIC_FIDELITY", True, f"completed_range[{i}]")
            if "FULL REGRESSION PASS" in u or "FULL REGRESSION" in u and "PASS" in u:
                mark("FULL_REGRESSION", True, f"completed_range[{i}]")
            if "TOURNAMENT FINAL" in u and "PASS" in u:
                mark("TOURNAMENT_FINAL", True, f"completed_range[{i}]")
            if "REALITY CALIBRATION" in u and "PASS" in u:
                mark("REALITY_CALIBRATION", True, f"completed_range[{i}]")
            if "SEALED HOLDOUT" in u and "PASS" in u:
                mark("SEALED_HOLDOUT", True, f"completed_range[{i}]")
            if "FINAL CI" in u and "PASS" in u:
                mark("FINAL_CI", True, f"completed_range[{i}]")
            if "FINAL GATE" in u and "PASS" in u:
                mark("FINAL_GATE", True, f"completed_range[{i}]")
    return claims


def _fingerprints_from_root(r: dict) -> dict[str, Any]:
    out: dict[str, Any] = {}
    fp = r.get("fingerprints") if isinstance(r.get("fingerprints"), dict) else {}
    out.update(copy.deepcopy(fp))
    dsl = r.get("dsl") if isinstance(r.get("dsl"), dict) else {}
    v = r.get("verification") if isinstance(r.get("verification"), dict) else {}
    np = v.get("native_plan") if isinstance(v.get("native_plan"), dict) else {}
    fr = v.get("full_regression") if isinstance(v.get("full_regression"), dict) else {}
    engine = r.get("engine") if isinstance(r.get("engine"), dict) else {}
    package = r.get("package") if isinstance(r.get("package"), dict) else {}
    aliases = {
        "player_dsl_sha256": fp.get("player_dsl_sha256") or dsl.get("dsl_sha256") or fr.get("dsl_sha256") or r.get("player_dsl_sha256"),
        "native_dependency_digest": v.get("native_dependency_digest") or np.get("native_dependency_digest") or fp.get("native_dependency_digest"),
        "engine_bundle_fingerprint": fp.get("engine_bundle_fingerprint") or r.get("engine_bundle_fingerprint") or engine.get("bundle_fingerprint") or package.get("bundle_fingerprint"),
        "engine_source_digest": fp.get("engine_source_digest") or r.get("engine_source_digest") or engine.get("engine_source_digest") or package.get("engine_source_digest"),
        "opening_analysis_fingerprint": (r.get("deck_freeze") or {}).get("analysis_fingerprint") if isinstance(r.get("deck_freeze"), dict) else None,
        "regression_scope_fingerprint": fp.get("regression_scope_fingerprint") or fr.get("regression_scope_fingerprint"),
        "suite_manifest_sha256": fp.get("suite_manifest_sha256") or r.get("suite_manifest_sha256"),
        "holdout_commit_sha256": fp.get("holdout_commit_sha256") or r.get("holdout_commit_sha256"),
    }
    for k, val in aliases.items():
        if val is not None:
            out[k] = val
    return out



def _runtime_hash_sets_from_root(r: dict, checkpoint_id: str) -> list[dict]:
    """Extract historical runtime file hashes from known v20.17.x checkpoint shapes.

    Multiple sets are retained because a checkpoint may describe both an available base
    runtime and the authoritative retained/reconstructed runtime. Reconciliation chooses
    the highest-priority exact set rather than merging incompatible generations.
    """
    sets: list[dict] = []

    def clean_map(value: Any) -> dict[str, str]:
        out: dict[str, str] = {}
        if not isinstance(value, dict):
            return out
        for k, v in value.items():
            if isinstance(v, dict):
                v = v.get("sha256") or v.get("hash")
            if isinstance(v, str) and len(v.strip()) >= 32:
                key = str(k).replace("\\", "/")
                if key.endswith(".sha256"):
                    key = key[:-7]
                while key.startswith("./"):
                    key = key[2:]
                if key and ".." not in key.split("/"):
                    out[key] = v.strip().lower()
        return out

    def add(source: str, value: Any, priority: int):
        m = clean_map(value)
        if m:
            sets.append({"source": f"{checkpoint_id}:{source}", "hashes": m, "priority": priority})

    rr = r.get("runtime_reconstruction") if isinstance(r.get("runtime_reconstruction"), dict) else {}
    add("runtime_reconstruction.core_hashes", rr.get("core_hashes"), 90)
    add("runtime_reconstruction.runtime_hashes", rr.get("runtime_hashes"), 85)

    iw = r.get("incremental_work_this_checkpoint") if isinstance(r.get("incremental_work_this_checkpoint"), dict) else {}
    add("incremental_work.retained_cp12l_runtime_hashes", iw.get("retained_cp12l_runtime_hashes"), 80)
    add("incremental_work.expected_runtime_hashes", iw.get("expected_runtime_hashes"), 80)
    add("incremental_work.available_base_runtime_hashes", iw.get("available_base_runtime_hashes"), 20)

    for key in ("core_hashes", "runtime_hashes", "expected_runtime_hashes", "engine_file_hashes"):
        add(key, r.get(key), 70)

    # Convert named engine component hashes into path-based expectations.
    fp = r.get("fingerprints") if isinstance(r.get("fingerprints"), dict) else {}
    path_aliases = {
        "engine_full_match_sha256": "engine/full_match.py",
        "engine_rule_kernel_sha256": "engine/rule_kernel.py",
        "engine_action_templates_sha256": "engine/action_templates.py",
        "engine_route_planner_sha256": "engine/route_planner.py",
        "engine_state_sha256": "engine/state.py",
        "engine_mechanics_sha256": "engine/mechanics.py",
        "engine_ygo_geometry_sha256": "engine/ygo_geometry.py",
        "engine_yugioh_plugin_sha256": "engine/plugins/yugioh.py",
    }
    aliases: dict[str, str] = {}
    for k, path in path_aliases.items():
        v = fp.get(k) or r.get(k)
        if isinstance(v, str) and len(v.strip()) >= 32:
            aliases[path] = v.strip().lower()
    if aliases:
        sets.append({"source": f"{checkpoint_id}:named_engine_hashes", "hashes": aliases, "priority": 60})
    return sets

def _runtime_gaps_from_root(r: dict, checkpoint_id: str) -> list[dict]:
    gaps: list[dict] = []
    fr = r.get("full_regression") if isinstance(r.get("full_regression"), dict) else {}
    missing = fr.get("missing_exact_old_generated_fixtures")
    if isinstance(missing, dict):
        for k, v in missing.items():
            try:
                count = int(v)
            except Exception:
                continue
            if count > 0:
                gaps.append({"source": f"{checkpoint_id}:full_regression.missing_exact_old_generated_fixtures.{k}", "kind": "missing_generated_fixture", "count": count})
    for container_name in ("runtime_reconstruction", "resume_policy"):
        obj = r.get(container_name) if isinstance(r.get(container_name), dict) else {}
        for k, v in obj.items():
            lk = str(k).casefold()
            if "missing" not in lk and "unavailable" not in lk:
                continue
            if isinstance(v, bool):
                if v:
                    gaps.append({"source": f"{checkpoint_id}:{container_name}.{k}", "kind": "declared_gap", "value": True})
            elif isinstance(v, (int, float)) and v > 0:
                gaps.append({"source": f"{checkpoint_id}:{container_name}.{k}", "kind": "declared_gap", "count": int(v)})
            elif isinstance(v, (list, dict, str)) and v:
                gaps.append({"source": f"{checkpoint_id}:{container_name}.{k}", "kind": "declared_gap", "value": copy.deepcopy(v)})
    return gaps


def _integrity(doc: dict) -> dict:
    """Verify historical self-hashes when their legacy format is known.

    research-checkpoint-v2 payload_hash is canonical JSON SHA-256 of payload.
    Later top-level checkpoints use canonical JSON SHA-256 of the document excluding
    checkpoint_hash. A research checkpoint may also contain a differently-derived
    checkpoint_hash; when payload_hash is valid we keep that outer hash as unverified
    rather than falsely rejecting the payload.
    """
    out={'status':'NO_SELF_HASH','payload_hash_present':False,'payload_hash_ok':None,'checkpoint_hash_present':False,'checkpoint_hash_ok':None}
    if isinstance(doc.get('payload'),dict) and isinstance(doc.get('payload_hash'),str):
        out['payload_hash_present']=True
        out['payload_hash_ok']=sha256_obj(doc['payload'])==doc['payload_hash']
        out['status']='VERIFIED' if out['payload_hash_ok'] else 'FAILED'
    if isinstance(doc.get('checkpoint_hash'),str):
        out['checkpoint_hash_present']=True
        calc=sha256_obj({k:v for k,v in doc.items() if k!='checkpoint_hash'})
        out['checkpoint_hash_ok']=calc==doc['checkpoint_hash']
        if out['checkpoint_hash_ok']:
            out['status']='VERIFIED'
        elif out['payload_hash_present'] and out['payload_hash_ok']:
            out['status']='PAYLOAD_VERIFIED_OUTER_HASH_UNRECOGNIZED'
        elif not out['payload_hash_present']:
            out['status']='FAILED'
    return out


def _raw_hash(doc: dict) -> str:
    return sha256_obj(doc)


def _compatible_related(primary: dict, related: dict) -> tuple[bool, str]:
    pr, rr = _root(primary), _root(related)
    prun, rrun = pr.get("run_id") or primary.get("run_id"), rr.get("run_id") or related.get("run_id")
    pfp, rfp = _declared_deck_fingerprint(pr), _declared_deck_fingerprint(rr)
    prs, rrs = _ruleset_from_root(pr), _ruleset_from_root(rr)
    if prun and rrun and str(prun) != str(rrun):
        return False, "run_id_mismatch"
    if pfp and rfp and pfp != rfp:
        return False, "deck_fingerprint_mismatch"
    if prs and rrs and not _same_ruleset(prs, rrs):
        return False, "ruleset_mismatch"
    return True, "compatible"


def parse_legacy_checkpoint(primary: dict, related: list[dict] | None = None, *, deck_override: dict | None = None, ruleset_override: dict | None = None) -> dict:
    if not isinstance(primary, dict):
        raise ValueError("legacy_checkpoint must be an object")
    related = [x for x in (related or []) if isinstance(x, dict)]
    primary_integrity=_integrity(primary)
    if primary_integrity.get('status')=='FAILED':
        return {
            'schema':'v20.18-legacy-import-record-v1','primary_checkpoint':_checkpoint_id(primary),
            'primary_schema':primary.get('schema') or _root(primary).get('schema'),
            'integrity':{'primary':primary_integrity,'related':[]},
            'integrity_failed':True,'deck':None,'ruleset':None,'claims':{},'historical_fingerprints':{},
            'accepted_sources':[],'rejected_related':[],'final_gate_claim_quarantined':False,
        }
    accepted = [primary]
    rejected = []
    related_integrity=[]
    for doc in related:
        integ=_integrity(doc);related_integrity.append({'checkpoint':_checkpoint_id(doc),**integ})
        if integ.get('status')=='FAILED':
            rejected.append({"checkpoint": _checkpoint_id(doc), "reason": "integrity_failed"})
            continue
        ok, reason = _compatible_related(primary, doc)
        if ok:
            accepted.append(doc)
        else:
            rejected.append({"checkpoint": _checkpoint_id(doc), "reason": reason})

    roots = [_root(x) for x in accepted]
    deck = copy.deepcopy(deck_override) if isinstance(deck_override, dict) else None
    deck_source = "override" if deck else None
    if deck is None:
        for doc, r in zip(accepted, roots):
            d = _deck_from_root(r)
            if d:
                deck = d
                deck_source = _checkpoint_id(doc)
                break
    ruleset = copy.deepcopy(ruleset_override) if isinstance(ruleset_override, dict) else _ruleset_from_root(roots[0])

    claims: dict[str, dict] = {}
    fingerprints: dict[str, Any] = {}
    runtime_hash_sets: list[dict] = []
    runtime_gaps: list[dict] = []
    evidence_sources = []
    for doc, r in zip(accepted, roots):
        cid = _checkpoint_id(doc)
        c = _claims_from_root(r)
        for node, entry in c.items():
            cur = claims.setdefault(node, {"pass_claim": True, "structured": False, "evidence": None, "sources": []})
            cur["structured"] = bool(cur["structured"] or entry.get("structured"))
            if cur.get("evidence") is None and entry.get("evidence") is not None:
                cur["evidence"] = entry.get("evidence")
            cur["sources"].extend([f"{cid}:{x}" for x in entry.get("sources", [])])
        for k, v in _fingerprints_from_root(r).items():
            if k not in fingerprints and v is not None:
                fingerprints[k] = v
        runtime_hash_sets.extend(_runtime_hash_sets_from_root(r, cid))
        runtime_gaps.extend(_runtime_gaps_from_root(r, cid))
        evidence_sources.append({
            "checkpoint": cid,
            "schema": doc.get("schema") or r.get("schema"),
            "created_at": _created_at(doc),
            "source_hash": _raw_hash(doc),
            "declared_deck_fingerprint": _declared_deck_fingerprint(r),
        })

    pr = roots[0]
    return {
        "schema": "v20.18-legacy-import-record-v1",
        "primary_checkpoint": _checkpoint_id(primary),
        "primary_schema": primary.get("schema") or pr.get("schema"),
        "primary_created_at": _created_at(primary),
        "legacy_run_id": pr.get("run_id") or primary.get("run_id"),
        "legacy_status": pr.get("status"),
        "legacy_final_label": pr.get("final_label"),
        "legacy_next_resume_position": pr.get("next_resume_position"),
        "deck": deck,
        "deck_source": deck_source,
        "declared_deck_fingerprint": _declared_deck_fingerprint(pr),
        "ruleset": ruleset,
        "claims": claims,
        "historical_fingerprints": fingerprints,
        "historical_runtime_hash_sets": runtime_hash_sets,
        "historical_runtime_gaps": runtime_gaps,
        "accepted_sources": evidence_sources,
        "rejected_related": rejected,
        "final_gate_claim_quarantined": bool((claims.get("FINAL_GATE") or {}).get("pass_claim")),
        "integrity": {"primary": primary_integrity, "related": related_integrity},
        "integrity_failed": False,
    }


def _ruleset_match(record: dict, run: dict) -> bool:
    return _same_ruleset(record.get("ruleset"), run.get("ruleset"))


def _dsl_hash_match(expected: str | None, dsl: dict) -> tuple[bool, str | None, dict[str, str]]:
    variants = _json_hash_variants(dsl)
    if not expected:
        return False, None, variants
    for name, value in variants.items():
        if value == expected:
            return True, name, variants
    return False, None, variants


def _engine_component_hashes(legacy_root: str | Path) -> dict[str, str]:
    root = Path(legacy_root)
    mapping = {
        "engine_full_match_sha256": "engine/full_match.py",
        "engine_rule_kernel_sha256": "engine/rule_kernel.py",
        "engine_action_templates_sha256": "engine/action_templates.py",
        "engine_route_planner_sha256": "engine/route_planner.py",
    }
    out = {}
    for key, rel in mapping.items():
        p = root / rel
        if p.is_file():
            out[key] = _sha256_bytes(p.read_bytes())
    return out


def reconcile_legacy_import(run: dict, *, legacy_root: str | Path, engine_bundle_fingerprint: str) -> dict:
    record = run.get("legacy_import") or {}
    inputs = run.get("engine_inputs") or {}
    vs = inputs.get("verifier_spec") if isinstance(inputs.get("verifier_spec"), dict) else {}
    dsl = vs.get("player_dsl") if isinstance(vs.get("player_dsl"), dict) else None
    cfg = inputs.get("current_config") if isinstance(inputs.get("current_config"), dict) else None
    if cfg is None and isinstance(inputs.get("base_config"), dict):
        cfg = inputs.get("base_config")

    checks: dict[str, Any] = {}
    checks["deck_inventory_match"] = bool(record.get("deck") and run.get("deck") == record.get("deck"))
    checks["ruleset_match"] = _ruleset_match(record, run)

    hfp = record.get("historical_fingerprints") or {}
    if dsl is not None:
        dsl_ok, variant, variants = _dsl_hash_match(hfp.get("player_dsl_sha256"), dsl)
        checks["player_dsl_hash_match"] = dsl_ok
        checks["player_dsl_hash_variant"] = variant
        checks["current_player_dsl_hashes"] = variants
        current_native = native_dependency_fingerprint(dsl, legacy_root)
        checks["current_native_dependency_digest"] = current_native
        checks["native_dependency_match"] = bool(hfp.get("native_dependency_digest") and hfp.get("native_dependency_digest") == current_native)
    else:
        checks["player_dsl_hash_match"] = False
        checks["native_dependency_match"] = False

    if cfg is not None:
        opening = opening_analysis_fingerprint(cfg)
        hist_open = hfp.get("opening_analysis_fingerprint")
        checks["current_opening_analysis_fingerprint"] = opening
        checks["opening_analysis_match"] = bool(hist_open and (opening == hist_open or opening.startswith(str(hist_open))))
    else:
        checks["opening_analysis_match"] = False

    hist_bundle = hfp.get("engine_bundle_fingerprint")
    hr = run.get("historical_runtime") if isinstance(run.get("historical_runtime"), dict) else {}
    runtime_source_exact = bool(hr.get("activated") and hr.get("status") == "VERIFIED_EXACT" and hr.get("engine_bundle_fingerprint") == engine_bundle_fingerprint)
    runtime_gaps = list(record.get("historical_runtime_gaps") or [])
    source_gaps = [x for x in runtime_gaps if x.get("kind") != "missing_generated_fixture"]
    regression_evidence_gaps = [x for x in runtime_gaps if x.get("kind") == "missing_generated_fixture"]
    checks["historical_runtime_source_exact"] = runtime_source_exact
    checks["historical_runtime_gap_count"] = len(source_gaps)
    checks["historical_regression_evidence_gap_count"] = len(regression_evidence_gaps)
    checks["historical_regression_evidence_complete"] = not regression_evidence_gaps
    evidence_cert = run.get("historical_evidence") if isinstance(run.get("historical_evidence"), dict) else {}
    evidence_nodes = evidence_cert.get("nodes") if isinstance(evidence_cert.get("nodes"), dict) else {}
    certified_nodes = sorted(k for k,v in evidence_nodes.items() if isinstance(v,dict) and v.get("certified"))
    checks["historical_evidence_certificate_present"] = bool(evidence_cert)
    checks["historical_evidence_certified_nodes"] = certified_nodes
    if (evidence_nodes.get("FULL_REGRESSION") or {}).get("certified"):
        checks["historical_regression_evidence_complete"] = True
        checks["historical_regression_evidence_gap_count"] = 0
    # Runtime/source lineage and the historical test-evidence capsule are separate
    # dimensions. Source can be reconstructed exactly while old generated fixtures
    # are still missing; in that case the runtime is usable but Full Regression must
    # be rerun rather than imported.
    checks["historical_runtime_lineage_complete"] = bool(runtime_source_exact and not source_gaps)
    checks["engine_bundle_match"] = bool((hist_bundle and hist_bundle == engine_bundle_fingerprint) or checks["historical_runtime_lineage_complete"])
    current_components = _engine_component_hashes(legacy_root)
    checks["engine_component_matches"] = {
        key: bool(hfp.get(key) and hfp.get(key) == value)
        for key, value in current_components.items()
        if hfp.get(key)
    }
    checks["all_declared_engine_components_match"] = bool(checks["engine_component_matches"]) and all(checks["engine_component_matches"].values())

    # Build the current context for auditability whenever engine-ready assets exist.
    context = None
    if dsl is not None and cfg is not None:
        try:
            context = build_context(run, legacy_root=legacy_root, engine_bundle_fingerprint=engine_bundle_fingerprint)
        except Exception:
            context = None

    claims = copy.deepcopy(record.get("claims") or {})
    # Bridge 5 evidence certificates may upgrade an old prose/partial claim only when
    # the attached capsule was independently hash-validated against the exact restored
    # runtime lineage. Historical Final Gate is intentionally excluded.
    for node in ("FULL_REGRESSION","TOURNAMENT_FINAL","SEALED_HOLDOUT","FINAL_CI"):
        erow = evidence_nodes.get(node) if isinstance(evidence_nodes.get(node),dict) else {}
        if erow.get("certified"):
            claims[node] = {
                "pass_claim": True, "structured": True,
                "evidence": copy.deepcopy(erow.get("evidence")),
                "sources": list((claims.get(node) or {}).get("sources") or []) + ["historical_evidence_certificate"],
            }
    authorized: list[str] = []
    denied: dict[str, list[str]] = {}
    seed_evidence: dict[str, Any] = {}

    def decide(node: str, requirements: list[tuple[str, bool]], *, structured_required: bool = False):
        claim = claims.get(node) or {}
        reasons = []
        if not claim.get("pass_claim"):
            reasons.append("legacy_pass_claim_absent")
        if structured_required and not claim.get("structured"):
            reasons.append("structured_evidence_absent")
        for label, ok in requirements:
            if not ok:
                reasons.append(label)
        if reasons:
            denied[node] = reasons
            return False
        authorized.append(node)
        return True

    if decide("OPENING_EXACT", [
        ("deck_inventory_mismatch", checks["deck_inventory_match"]),
        ("opening_analysis_fingerprint_mismatch_or_absent", checks["opening_analysis_match"]),
    ]):
        pass

    if decide("WHOLE_DSL_SEMANTIC_FIDELITY", [
        ("ruleset_mismatch", checks["ruleset_match"]),
        ("player_dsl_fingerprint_mismatch_or_absent", checks["player_dsl_hash_match"]),
        ("native_dependency_fingerprint_mismatch_or_absent", checks["native_dependency_match"]),
    ]):
        src = (claims.get("WHOLE_DSL_SEMANTIC_FIDELITY") or {}).get("evidence")
        player = copy.deepcopy(src) if isinstance(src, dict) else {}
        if "player" in player and isinstance(player.get("player"), dict):
            bundle = player
            bundle["ok"] = bool(bundle.get("ok", bundle["player"].get("ok")))
        else:
            player.setdefault("ok", True)
            player.setdefault("bounded_card_count", len(player.get("bounded_cards", []) or []))
            player.setdefault("bounded_effect_count", len(player.get("bounded_effects", []) or []))
            bundle = {"player": player, "ok": True}
        bundle["legacy_import_provenance"] = record.get("primary_checkpoint")
        seed_evidence["whole_dsl_semantic_fidelity"] = bundle

    # Full regression depends on the complete executable/test bundle. Matching only a few
    # named engine files is useful diagnostic evidence but is intentionally insufficient.
    if decide("FULL_REGRESSION", [
        ("ruleset_mismatch", checks["ruleset_match"]),
        ("engine_bundle_fingerprint_mismatch_or_absent", checks["engine_bundle_match"]),
        ("historical_regression_evidence_capsule_incomplete", checks["historical_regression_evidence_complete"]),
    ], structured_required=True):
        src = copy.deepcopy((claims.get("FULL_REGRESSION") or {}).get("evidence") or {})
        src["ok"] = True
        src["legacy_import_provenance"] = record.get("primary_checkpoint")
        seed_evidence["full_regression"] = src

    tf_claim = claims.get("TOURNAMENT_FINAL") or {}
    tf_evidence = tf_claim.get("evidence")
    tf_structured = isinstance(tf_evidence, dict) and bool(tf_evidence.get("suite_pre_holdout_ready")) and bool(tf_evidence.get("matchups"))
    if decide("TOURNAMENT_FINAL", [
        ("deck_inventory_mismatch", checks["deck_inventory_match"]),
        ("ruleset_mismatch", checks["ruleset_match"]),
        ("player_dsl_fingerprint_mismatch_or_absent", checks["player_dsl_hash_match"]),
        ("engine_bundle_fingerprint_mismatch_or_absent", checks["engine_bundle_match"]),
        ("complete_tournament_suite_evidence_absent", tf_structured),
    ], structured_required=True):
        seed_evidence["tournament_final_suite"] = copy.deepcopy(tf_evidence)

    # We deliberately do not authorize Reality Calibration as a standalone seed. The
    # revalidator derives it again from a reusable/rerun Tournament Final suite.
    if (claims.get("REALITY_CALIBRATION") or {}).get("pass_claim"):
        denied.setdefault("REALITY_CALIBRATION", []).append("recomputed_from_tournament_final_in_v20.18")

    sh_claim = claims.get("SEALED_HOLDOUT") or {}
    sh_evidence = sh_claim.get("evidence")
    holdout_commit_present = bool(vs.get("holdout_commit")) or bool((evidence_nodes.get("SEALED_HOLDOUT") or {}).get("certified"))
    sh_structured = isinstance(sh_evidence, dict) and bool(sh_evidence.get("verified"))
    if decide("SEALED_HOLDOUT", [
        ("deck_inventory_mismatch", checks["deck_inventory_match"]),
        ("ruleset_mismatch", checks["ruleset_match"]),
        ("engine_bundle_fingerprint_mismatch_or_absent", checks["engine_bundle_match"]),
        ("holdout_commit_asset_absent", holdout_commit_present),
        ("verified_holdout_evidence_absent", sh_structured),
    ], structured_required=True):
        seed_evidence["sealed_holdout"] = copy.deepcopy(sh_evidence)

    ci_claim = claims.get("FINAL_CI") or {}
    ci_evidence = ci_claim.get("evidence")
    ci_structured = isinstance(ci_evidence, dict) and ci_evidence.get("ok") is True
    ci_assets = bool(vs.get("golden_manifest") and vs.get("source_lock")) or bool((evidence_nodes.get("FINAL_CI") or {}).get("certified"))
    if decide("FINAL_CI", [
        ("ruleset_mismatch", checks["ruleset_match"]),
        ("engine_bundle_fingerprint_mismatch_or_absent", checks["engine_bundle_match"]),
        ("final_ci_assets_absent", ci_assets),
        ("structured_final_ci_evidence_absent", ci_structured),
    ], structured_required=True):
        seed_evidence["final_ci"] = copy.deepcopy(ci_evidence)

    if (claims.get("FINAL_GATE") or {}).get("pass_claim"):
        denied["FINAL_GATE"] = ["legacy_final_gate_never_directly_imported", "v20.18_final_gate_must_be_re_evaluated"]

    seed = {
        "schema": "v20.18-legacy-evidence-seed-v1",
        "legacy_checkpoint": record.get("primary_checkpoint"),
        "authorized_nodes": sorted(set(authorized)),
        "evidence": seed_evidence,
        "provenance": record.get("accepted_sources") or [],
    }
    return {
        "schema": "v20.18-legacy-reconciliation-v1",
        "legacy_checkpoint": record.get("primary_checkpoint"),
        "checks": checks,
        "authorized_nodes": sorted(set(authorized)),
        "denied_nodes": denied,
        "current_context_fingerprint": sha256_obj(context) if context else None,
        "current_context": context,
        "reuse_seed": seed,
        "final_gate_recertification_required": True,
    }
