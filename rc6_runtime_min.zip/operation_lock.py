from __future__ import annotations
import contextlib, os, time
from pathlib import Path

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows dev only
    fcntl = None

class RunBusyError(RuntimeError):
    pass

@contextlib.contextmanager
def run_operation_lock(tenant_root: str | Path, run_id: str, timeout: float = 30.0):
    """Cross-process exclusive lock for one run. Prevents lost read-modify-write updates."""
    lock_dir = Path(tenant_root) / ".locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    p = lock_dir / f"{run_id}.lock"
    fh = p.open("a+")
    if fcntl is None:
        yield
        fh.close()
        return
    deadline = time.monotonic() + max(0.0, timeout)
    while True:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() >= deadline:
                fh.close()
                raise RunBusyError(f"run is busy: {run_id}")
            time.sleep(0.05)
    try:
        yield
    finally:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        fh.close()
