from __future__ import annotations
import html
import os
from starlette.applications import Starlette
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route, Mount


def _publisher() -> str:
    return (os.environ.get("VTD_PUBLISHER_NAME") or "Publisher not configured").strip()


def _base_host() -> str:
    host = (os.environ.get("RENDER_EXTERNAL_HOSTNAME") or "").strip()
    if host:
        return f"https://{host}"
    mcp = (os.environ.get("VTD_PUBLIC_MCP_URL") or "").strip()
    if mcp.endswith("/mcp"):
        return mcp[:-4]
    return mcp.rstrip("/")


def _page(title: str, body: str) -> HTMLResponse:
    pub = html.escape(_publisher())
    title_e = html.escape(title)
    return HTMLResponse(f"""<!doctype html><html lang='en'><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<title>{title_e} — Tournament Deck Verifier</title>
<style>body{{font-family:system-ui,-apple-system,sans-serif;max-width:820px;margin:48px auto;padding:0 20px;line-height:1.55}}nav a{{margin-right:14px}}code{{background:#f3f3f3;padding:2px 5px;border-radius:4px}}footer{{margin-top:48px;color:#666}}</style></head><body>
<nav><a href='/'>Home</a><a href='/support'>Support</a><a href='/privacy'>Privacy</a><a href='/terms'>Terms</a><a href='/demo'>Demo</a></nav>
<h1>{title_e}</h1><p><strong>Publisher:</strong> {pub}</p>{body}
<footer>Tournament Deck Verifier · {pub}</footer></body></html>""")


async def home(_):
    base = html.escape(_base_host())
    return _page("Tournament Deck Verifier", f"""
<p>A tournament-deck verification service that resumes durable verification runs, checks evidence lineage, and only issues a Final Gate when the configured verifier stages pass.</p>
<p><strong>MCP endpoint:</strong> <code>{base}/mcp</code></p>
<p>This site is the public information surface for the same publisher and host as the MCP service.</p>""")


async def support(_):
    return _page("Support", """
<p>For problems connecting the plugin, first confirm that the MCP endpoint is reachable and that OAuth authorization completes successfully. For verification-result questions, include the run identifier and the stage shown by <code>get_verification_status</code>; do not send OAuth tokens or other credentials.</p>
<p>If the issue concerns the public plugin listing or account access, use the support channel associated with the publisher identity in the OpenAI plugin directory.</p>""")


async def privacy(_):
    return _page("Privacy Policy", """
<p>The verifier processes deck lists, ruleset inputs, verification evidence, run state, and authenticated account identifiers needed to isolate each user's workspace. OAuth access tokens are used for authorization and are not included in exported checkpoints or public plugin packages.</p>
<p>Verification state is stored for continuity and checkpoint resumption. Historical evidence can be quarantined and revalidated rather than being treated as a new certification automatically. The service does not intentionally use verifier content for advertising.</p>
<p>Do not submit secrets inside deck data or evidence files. Authentication credentials should be supplied only through the configured OAuth flow or the hosting platform's secret store.</p>""")


async def terms(_):
    return _page("Terms of Use", """
<p>This service provides automated tournament-deck verification and decision support. Outputs are evidence-based assessments, not guarantees of tournament results. Users remain responsible for checking official card text, rulings, event policies, and current regulations before competition.</p>
<p>Do not use the service to upload unlawful content, credentials, malware, or files you are not authorized to provide. Availability may be interrupted for maintenance, security fixes, or upstream platform changes.</p>""")


async def demo(_):
    demo_url = (os.environ.get("VTD_DEMO_RECORDING_URL") or "").strip()
    if demo_url:
        safe = html.escape(demo_url, quote=True)
        return _page("Demo", f"<p>Review recording: <a href='{safe}' rel='noopener noreferrer'>{safe}</a></p>")
    return _page("Demo", "<p>The review recording has not been configured yet. Set <code>VTD_DEMO_RECORDING_URL</code> before final directory submission.</p>")


async def public_config(_):
    base = _base_host()
    return JSONResponse({
        "publisher_name": _publisher(),
        "website_url": f"{base}/" if base else "",
        "support_url": f"{base}/support" if base else "",
        "privacy_url": f"{base}/privacy" if base else "",
        "terms_url": f"{base}/terms" if base else "",
        "demo_url": (os.environ.get("VTD_DEMO_RECORDING_URL") or "").strip(),
        "mcp_url": f"{base}/mcp" if base else "",
    })


def wrap_app(inner):
    return Starlette(routes=[
        Route("/", home),
        Route("/support", support),
        Route("/privacy", privacy),
        Route("/terms", terms),
        Route("/demo", demo),
        Route("/.well-known/vtd-public-config", public_config),
        Mount("/", app=inner),
    ])
