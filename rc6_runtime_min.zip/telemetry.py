from __future__ import annotations
import json, logging, os, threading, time
from datetime import datetime, timezone

log=logging.getLogger("vtd.production")
if not log.handlers:
    h=logging.StreamHandler();h.setFormatter(logging.Formatter('%(message)s'));log.addHandler(h);log.setLevel(os.environ.get("VTD_LOG_LEVEL","INFO"))

class Metrics:
    def __init__(self):self._lock=threading.Lock();self.calls=0;self.errors=0;self.active=0;self.latency_sum=0.0
    def begin(self):
        with self._lock:self.calls+=1;self.active+=1
        return time.monotonic()
    def end(self,t0,ok=True):
        dt=time.monotonic()-t0
        with self._lock:self.active=max(0,self.active-1);self.latency_sum+=dt;self.errors+=0 if ok else 1
        return dt
    def prometheus(self):
        with self._lock:
            return f"vtd_http_requests_total {self.calls}\nvtd_http_errors_total {self.errors}\nvtd_http_active {self.active}\nvtd_http_latency_seconds_sum {self.latency_sum:.6f}\n"
metrics=Metrics()

def event(name:str,**fields):
    row={"ts":datetime.now(timezone.utc).isoformat(),"event":name,**fields};log.info(json.dumps(row,ensure_ascii=False,separators=(',',':')))

class RawTelemetryMiddleware:
    def __init__(self,app):self.app=app
    async def __call__(self,scope,receive,send):
        if scope.get('type')!='http':return await self.app(scope,receive,send)
        t0=metrics.begin();status=500
        async def wrapped(message):
            nonlocal status
            if message.get('type')=='http.response.start':status=int(message.get('status',500))
            await send(message)
        ok=False
        try:
            await self.app(scope,receive,wrapped);ok=status<500
        finally:
            dt=metrics.end(t0,ok);event('http_request',method=scope.get('method'),path=scope.get('path'),status=status,duration_ms=round(dt*1000,2))
