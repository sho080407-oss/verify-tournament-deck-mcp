from __future__ import annotations
import os
from contextlib import contextmanager
from mcp.server.fastmcp import FastMCP
from models import OpenAIFile
from auth_factory import build_auth
from production_context import current_adapter, current_tenant_root, current_principal
from operation_lock import run_operation_lock, RunBusyError
from operation_journal import OperationJournal
from profile_model import AuthenticatedProfile
from openai_tool_catalog import install_openai_tool_descriptor_overlay

auth_settings, token_verifier = build_auth()
server=FastMCP(
    'Tournament Deck Verifier v20.18.22',
    host=os.environ.get('MCP_HOST','0.0.0.0'),
    port=int(os.environ.get('MCP_PORT','8000')),
    stateless_http=True,
    auth=auth_settings,
    token_verifier=token_verifier,
)

def _request_id():
    # Kept transport-agnostic: journal identity is optional and never used for authorization.
    return None

@contextmanager
def _mutating_operation(run_id:str, operation:str):
    root=current_tenant_root(); journal=OperationJournal(root); rec=None
    with run_operation_lock(root,run_id,timeout=float(os.environ.get('VTD_RUN_LOCK_TIMEOUT','30'))):
        rec=journal.begin(run_id,operation,_request_id())
        try:
            yield current_adapter()
        except Exception as e:
            journal.finish(rec,ok=False,error=repr(e)); raise
        else:
            journal.finish(rec,ok=True)

def _read_adapter():
    return current_adapter()


@server.tool(meta={"openai/profile": True})
def get_profile() -> AuthenticatedProfile:
    """Return the opaque stable profile represented by the authenticated verifier credentials."""
    p=current_principal()
    return AuthenticatedProfile(id="vtd_"+p.stable_key)

@server.tool()
def create_verification_run(mode:str, game:str, deck:dict, ruleset:dict, constraints:dict|None=None, candidate_universe:dict|None=None, label:str|None=None, engine_inputs:dict|None=None) -> dict:
    """Create a run. engine_inputs may contain v20.17.1-compatible base/current config, candidate pool, builder spec and verifier spec. Holdout secrets are stored separately and never exported."""
    # Creation uses a tenant-global create lock; the generated run id is collision-resistant.
    with _mutating_operation('__create__','create_verification_run') as adapter:
        return adapter.create_run(mode=mode,game=game,deck=deck,constraints=constraints,ruleset=ruleset,candidate_universe=candidate_universe,label=label,engine_inputs=engine_inputs)

@server.tool()
def import_legacy_checkpoint(legacy_checkpoint:dict, related_checkpoints:list[dict]|None=None, game:str='yugioh_ocg', label:str|None=None, deck_override:dict|None=None, ruleset_override:dict|None=None, engine_inputs:dict|None=None) -> dict:
    """Import a historical v20.17.x checkpoint into a v20.18 revalidation run. Legacy Final Gate claims are quarantined and never directly certify the imported run. Related checkpoints may supply missing deck/evidence only when lineage fingerprints are compatible."""
    with _mutating_operation('__import__','import_legacy_checkpoint') as adapter:
        return adapter.import_legacy_checkpoint(legacy_checkpoint=legacy_checkpoint,related_checkpoints=related_checkpoints,game=game,label=label,deck_override=deck_override,ruleset_override=ruleset_override,engine_inputs=engine_inputs)

@server.tool(meta={"openai/fileParams":["runtime_bundle_file"]})
def attach_historical_runtime_bundle(run_id:str, runtime_bundle_file:OpenAIFile, expected_manifest:dict|None=None, lineage_stage:str|None=None) -> dict:
    """Attach one historical runtime lineage ZIP. Stages can be attached in order (for example CP12R then CP12T). Each stage is quarantined and may execute only when every semantic delta is covered by checkpoint/manifest hashes and the restored runtime passes self-test. lineage_stage is an optional checkpoint-name hint used to disambiguate multiple historical hash sets."""
    with _mutating_operation(run_id,'attach_historical_runtime_bundle') as adapter:
        return adapter.attach_historical_runtime_bundle(run_id, runtime_bundle_file.model_dump(exclude_none=True), expected_manifest, lineage_stage)

@server.tool(meta={"openai/fileParams":["evidence_capsule_file"]})
def attach_historical_evidence_capsule(run_id:str, evidence_capsule_file:OpenAIFile) -> dict:
    """Attach a historical evidence ZIP after exact runtime restoration. Manifest-bound regression fixtures, matchup evidence, sealed-holdout commitment/results and Final CI evidence are certified against the restored runtime lineage. Historical Final Gate is always quarantined."""
    with _mutating_operation(run_id,'attach_historical_evidence_capsule') as adapter:
        return adapter.attach_historical_evidence_capsule(run_id, evidence_capsule_file.model_dump(exclude_none=True))

@server.tool()
def build_missing_evidence_assets(run_id:str) -> dict:
    """Build Bridge 7 missing-evidence assets from verified historical provenance. Challenger-only historical tests may be scope-excluded only for revalidate_current when a manifest-bound RETAIN_INCUMBENT attestation matches the current deck. Missing incumbent/runtime coverage is replaced only by fresh SHA-bound superseding tests, never by arithmetic test-count substitution."""
    with _mutating_operation(run_id,'build_missing_evidence_assets') as adapter:
        return adapter.build_missing_evidence_assets(run_id)

@server.tool(meta={"openai/fileParams":["replay_asset_file"]})
def attach_replay_assets(run_id:str, replay_asset_file:OpenAIFile) -> dict:
    """Attach a Bridge 6/7 replay asset ZIP. It may contain exact recovered historical regression fixtures or a strict coverage_identity_matrix.json plus replacement tests. Test-count substitution alone is never accepted."""
    with _mutating_operation(run_id,'attach_replay_assets') as adapter:
        return adapter.attach_replay_assets(run_id, replay_asset_file.model_dump(exclude_none=True))

@server.tool()
def execute_missing_evidence(run_id:str, work_budget:str='standard', max_obligations:int=1) -> dict:
    """Execute only unresolved historical evidence obligations. Regression fixture groups and Tournament-Final matchups are checkpointed independently; already certified Holdout/Final-CI evidence is never rerun while fingerprints are unchanged."""
    with _mutating_operation(run_id,'execute_missing_evidence') as adapter:
        return adapter.execute_missing_evidence(run_id,work_budget,max_obligations)

@server.tool()
def build_tournament_final_suite(run_id:str) -> dict:
    """Bridge 8: cross-attest historical Tournament Final evidence against the exact restored runtime and build a fresh executable suite only for matchups that still require replay. Historical Final Gate is not reused."""
    with _mutating_operation(run_id,'build_tournament_final_suite') as adapter:
        return adapter.build_tournament_final_suite(run_id)

@server.tool()
def recertify_final_gate(run_id:str) -> dict:
    """Bridge 8: issue a new v20.18 Final Gate only when Whole-DSL, Full Regression, all Tournament-Final matchups, Reality Calibration, Sealed Holdout and Final CI are independently certified under matching fingerprints."""
    with _mutating_operation(run_id,'recertify_final_gate') as adapter:
        return adapter.recertify_final_gate(run_id)

@server.tool()
def attach_verification_assets(run_id:str, engine_inputs:dict, replace:bool=False) -> dict:
    """Attach or update engine-ready JSON assets for a blocked/waiting run. Secrets are separated from ordinary run state."""
    with _mutating_operation(run_id,'attach_verification_assets') as adapter:
        return adapter.attach_assets(run_id,engine_inputs,replace)

@server.tool()
def recover_interrupted_run(run_id:str) -> dict:
    """Mark any stale in-flight operation as interrupted and return the durable verifier status. The next advance_verification call resumes from the legacy/current checkpoint; completed fingerprint-stable stages are not rerun."""
    root=current_tenant_root()
    with run_operation_lock(root,run_id,timeout=float(os.environ.get('VTD_RUN_LOCK_TIMEOUT','30'))):
        recovered=OperationJournal(root).mark_recovered(run_id)
        out=current_adapter().status(run_id)
        out['recovered_interrupted_operations']=recovered
        out['resume_policy']='DURABLE_CHECKPOINT_ONLY_NO_COMPLETED_STAGE_RERUN'
        return out

@server.tool()
def find_verification_runs(query:str, limit:int=10) -> dict:
    """Find verification runs in the authenticated user's private verifier workspace by a task-specific query. This is read-only and does not advance or modify any run."""
    return {'runs':_read_adapter().find(query,limit)}

@server.tool()
def get_verification_status(run_id:str) -> dict:
    """Return the current durable status, checkpoint, blockers, and certification state for one verification run without changing it."""
    return _read_adapter().status(run_id)

@server.tool()
def advance_verification(run_id:str, work_budget:str='standard', stop_after:str|None=None) -> dict:
    """Execute only the next legal verification chunk. A process time budget may interrupt the legacy engine; its durable checkpoint is reused on the next call."""
    with _mutating_operation(run_id,'advance_verification') as adapter:
        return adapter.advance(run_id,work_budget,stop_after)

@server.tool()
def verify_change(run_id:str, changes:list[dict], reason:str|None=None) -> dict:
    """Evaluate proposed deck changes by creating or updating incremental verification work for the specified run while preserving the parent evidence lineage. This mutates verifier state but does not delete prior evidence."""
    with _mutating_operation(run_id,'verify_change') as adapter:
        return adapter.verify_change(run_id,changes,reason)

@server.tool()
def submit_reality_log(run_id:str, matches:list[dict], provenance:dict|None=None) -> dict:
    """Append user-supplied real-match observations and provenance to a verification run for Reality Calibration. This adds evidence to the private run and does not delete existing evidence."""
    with _mutating_operation(run_id,'submit_reality_log') as adapter:
        return adapter.submit_reality_log(run_id,matches,provenance)

@server.tool()
def get_verification_report(run_id:str, detail:str='summary') -> dict:
    """Return a verification report for one run at the requested detail level without changing verifier state or certification results."""
    return _read_adapter().report(run_id,detail)

@server.tool()
def export_checkpoint(run_id:str) -> dict:
    """Return the durable checkpoint payload for one verification run so it can be inspected or preserved; this read-only call does not modify the run."""
    return _read_adapter().export_checkpoint(run_id)

# Bridge 11: explicit OpenAI/MCP tool securitySchemes + behavior annotations on tools/list.
install_openai_tool_descriptor_overlay(server)

if __name__=='__main__': server.run(transport=os.environ.get('MCP_TRANSPORT','streamable-http'))
