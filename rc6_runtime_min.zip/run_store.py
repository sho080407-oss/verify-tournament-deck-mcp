from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path

from transactional_state import connect, database_path_from_runs_root, initialize, state_hash


class RunRevisionConflict(RuntimeError):
    pass


class RunAlreadyExists(RuntimeError):
    pass


class RunStore:
    """Transactional verifier run store.

    SQLite is canonical. Legacy JSON files are imported once and retained as a
    best-effort downgrade mirror so a Bridge 19 rollback can still see current
    non-secret run state.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.root, 0o700)
        except OSError:
            pass
        self.secret_root = self.root / ".secrets"
        self.secret_root.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.secret_root, 0o700)
        except OSError:
            pass
        self.db_path = database_path_from_runs_root(self.root)
        initialize(self.db_path)
        self._migrate_legacy_json_once()

    @staticmethod
    def _validate_run_id(run_id: str) -> str:
        if not re.fullmatch(r"[A-Za-z0-9._-]+", run_id):
            raise ValueError("invalid run_id")
        return run_id

    def _path(self, run_id: str) -> Path:
        return self.root / f"{self._validate_run_id(run_id)}.json"

    def _secret_path(self, run_id: str) -> Path:
        return self.secret_root / f"{self._validate_run_id(run_id)}.json"

    def _legacy_mirror_enabled(self) -> bool:
        return os.environ.get("VTD_RUNSTORE_LEGACY_MIRROR", "1").lower() not in {"0", "false", "no"}

    @staticmethod
    def _atomic_json_write(path: Path, data: dict, mode: int | None = None) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
        os.close(fd)
        try:
            Path(tmp).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            if mode is not None:
                try:
                    os.chmod(tmp, mode)
                except OSError:
                    pass
            os.replace(tmp, path)
            if mode is not None:
                try:
                    os.chmod(path, mode)
                except OSError:
                    pass
        finally:
            try:
                if Path(tmp).exists():
                    Path(tmp).unlink()
            except OSError:
                pass

    def _migrate_legacy_json_once(self) -> None:
        con = connect(self.db_path)
        try:
            already = con.execute("SELECT value FROM metadata WHERE key='legacy_json_migrated'").fetchone()
            if already and already[0] == "1":
                return
            con.execute("BEGIN IMMEDIATE")
            for p in sorted(self.root.glob("run-*.json")):
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    run_id = self._validate_run_id(str(data.get("run_id") or p.stem))
                except Exception:
                    continue
                if con.execute("SELECT 1 FROM runs WHERE run_id=?", (run_id,)).fetchone():
                    continue
                created = str(data.get("created_at") or data.get("updated_at") or datetime.now(timezone.utc).isoformat())
                updated = str(data.get("updated_at") or created)
                con.execute(
                    "INSERT INTO runs(run_id,revision,created_at,updated_at,state_json,state_hash) VALUES(?,?,?,?,?,?)",
                    (run_id, 1, created, updated, json.dumps(data, ensure_ascii=False), state_hash(data)),
                )
                sp = self._secret_path(run_id)
                if sp.exists():
                    try:
                        secret = json.loads(sp.read_text(encoding="utf-8"))
                    except Exception:
                        secret = None
                    if isinstance(secret, dict):
                        con.execute(
                            "INSERT OR REPLACE INTO secrets(run_id,updated_at,secret_json) VALUES(?,?,?)",
                            (run_id, updated, json.dumps(secret, ensure_ascii=False)),
                        )
            con.execute(
                "INSERT INTO metadata(key,value) VALUES('legacy_json_migrated','1') "
                "ON CONFLICT(key) DO UPDATE SET value='1'"
            )
            con.execute("COMMIT")
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()

    def create(self, payload: dict) -> dict:
        run_id = self._validate_run_id(str(payload.get("run_id") or f"run-{uuid.uuid4().hex[:16]}"))
        now = datetime.now(timezone.utc).isoformat()
        data = {
            "run_id": run_id,
            "created_at": now,
            "updated_at": now,
            "status": "IN_PROGRESS",
            "current_stage": "CREATED",
            "next_stage": "ENGINE_PREFLIGHT",
            "final_label": "検証中",
            "completed_stages": [],
            "fingerprints": {},
            "reused_evidence": [],
            "invalidated_evidence": [],
            "blockers": [],
            "final_gate": {"ok": False, "status": "NOT_RUN"},
            **payload,
            "run_id": run_id,
        }
        con = connect(self.db_path)
        try:
            con.execute("BEGIN IMMEDIATE")
            if con.execute("SELECT 1 FROM runs WHERE run_id=?", (run_id,)).fetchone():
                raise RunAlreadyExists(run_id)
            con.execute(
                "INSERT INTO runs(run_id,revision,created_at,updated_at,state_json,state_hash) VALUES(?,?,?,?,?,?)",
                (run_id, 1, now, now, json.dumps(data, ensure_ascii=False), state_hash(data)),
            )
            con.execute("COMMIT")
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()
        if self._legacy_mirror_enabled():
            self._atomic_json_write(self._path(run_id), data, 0o600)
        return data

    def read(self, run_id: str) -> dict:
        run_id = self._validate_run_id(run_id)
        con = connect(self.db_path)
        try:
            row = con.execute("SELECT state_json FROM runs WHERE run_id=?", (run_id,)).fetchone()
        finally:
            con.close()
        if row is None:
            raise FileNotFoundError(run_id)
        return json.loads(row[0])

    def revision(self, run_id: str) -> int:
        run_id = self._validate_run_id(run_id)
        con = connect(self.db_path)
        try:
            row = con.execute("SELECT revision FROM runs WHERE run_id=?", (run_id,)).fetchone()
        finally:
            con.close()
        if row is None:
            raise FileNotFoundError(run_id)
        return int(row[0])

    def read_with_revision(self, run_id: str) -> tuple[dict, int]:
        run_id = self._validate_run_id(run_id)
        con = connect(self.db_path)
        try:
            row = con.execute("SELECT state_json,revision FROM runs WHERE run_id=?", (run_id,)).fetchone()
        finally:
            con.close()
        if row is None:
            raise FileNotFoundError(run_id)
        return json.loads(row[0]), int(row[1])

    def write(self, run_id: str, data: dict, expected_revision: int | None = None) -> int:
        run_id = self._validate_run_id(run_id)
        data = dict(data)
        data["run_id"] = run_id
        data["updated_at"] = datetime.now(timezone.utc).isoformat()
        con = connect(self.db_path)
        try:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT revision FROM runs WHERE run_id=?", (run_id,)).fetchone()
            if row is None:
                raise FileNotFoundError(run_id)
            current = int(row[0])
            if expected_revision is not None and current != int(expected_revision):
                raise RunRevisionConflict(f"revision conflict for {run_id}: expected {expected_revision}, current {current}")
            new_revision = current + 1
            cur = con.execute(
                "UPDATE runs SET revision=?,updated_at=?,state_json=?,state_hash=? WHERE run_id=? AND revision=?",
                (new_revision, data["updated_at"], json.dumps(data, ensure_ascii=False), state_hash(data), run_id, current),
            )
            if cur.rowcount != 1:
                raise RunRevisionConflict(f"concurrent update for {run_id}")
            con.execute("COMMIT")
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()
        if self._legacy_mirror_enabled():
            self._atomic_json_write(self._path(run_id), data, 0o600)
        return new_revision

    def write_secret(self, run_id: str, data: dict) -> None:
        run_id = self._validate_run_id(run_id)
        now = datetime.now(timezone.utc).isoformat()
        con = connect(self.db_path)
        try:
            con.execute("BEGIN IMMEDIATE")
            if not con.execute("SELECT 1 FROM runs WHERE run_id=?", (run_id,)).fetchone():
                raise FileNotFoundError(run_id)
            con.execute(
                "INSERT INTO secrets(run_id,updated_at,secret_json) VALUES(?,?,?) "
                "ON CONFLICT(run_id) DO UPDATE SET updated_at=excluded.updated_at,secret_json=excluded.secret_json",
                (run_id, now, json.dumps(dict(data), ensure_ascii=False)),
            )
            con.execute("COMMIT")
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()
        if self._legacy_mirror_enabled():
            self._atomic_json_write(self._secret_path(run_id), dict(data), 0o600)

    def read_secret(self, run_id: str) -> dict:
        run_id = self._validate_run_id(run_id)
        con = connect(self.db_path)
        try:
            row = con.execute("SELECT secret_json FROM secrets WHERE run_id=?", (run_id,)).fetchone()
        finally:
            con.close()
        return {} if row is None else json.loads(row[0])

    def find(self, query: str, limit: int = 10) -> list[dict]:
        q = query.casefold().strip()
        con = connect(self.db_path)
        try:
            rows = con.execute("SELECT state_json FROM runs ORDER BY updated_at DESC").fetchall()
        finally:
            con.close()
        out: list[dict] = []
        for row in rows:
            try:
                d = json.loads(row[0])
            except Exception:
                continue
            hay = " ".join(str(d.get(k, "")) for k in ("run_id", "label", "game", "status", "current_stage")).casefold()
            if not q or q in hay:
                out.append(d)
            if len(out) >= max(1, min(limit, 50)):
                break
        return out

    def integrity_check(self) -> dict:
        con = connect(self.db_path)
        try:
            quick = str(con.execute("PRAGMA quick_check").fetchone()[0])
            rows = con.execute("SELECT run_id,state_json,state_hash,revision FROM runs").fetchall()
        finally:
            con.close()
        mismatches = []
        for row in rows:
            try:
                data = json.loads(row[1])
            except Exception:
                mismatches.append({"run_id": row[0], "reason": "INVALID_JSON"})
                continue
            actual = state_hash(data)
            if actual != row[2]:
                mismatches.append({"run_id": row[0], "reason": "STATE_HASH_MISMATCH", "revision": int(row[3])})
        return {"ok": quick == "ok" and not mismatches, "sqlite_quick_check": quick, "run_count": len(rows), "mismatches": mismatches}
