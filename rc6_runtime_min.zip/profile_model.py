from __future__ import annotations
from pydantic import BaseModel, Field

class AuthenticatedProfile(BaseModel):
    id: str = Field(min_length=1, pattern=r"\S", description="Opaque stable profile identifier for the authenticated verifier tenant.")
