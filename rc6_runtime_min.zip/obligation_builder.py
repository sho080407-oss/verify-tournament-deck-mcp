from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from typing import Any

from runtime_restore import sha256_file

CRITICAL_RUNTIME_FILES = [
    "engine/action_templates.py",
    "engine/full_match.py",
    "engine/mechanics.py",
    "engine/plugins/yugioh.py",
    "engine/route_planner.py",
    "engine/rule_kernel.py",
    "engine/state.py",
    "engine/witchcrafter_native.py",
    "engine/ygo_geometry.py",
    "engine/sky_striker_native.py",
    "engine/sky_striker_templates.py",
]
GLOBAL_INVARIANTS = [
    "strict_dsl_validation",
    "effect_count",
    "unique_effect_identity",
    "bounded_and_manual_zero",
    "engine_self_test",
    "rule_coverage_complete",
]


def _jhash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _json(path: Path) -> dict | None:
    try:
        x = json.loads(path.read_text(encoding="utf-8"))
        return x if isinstance(x, dict) else None
    except Exception:
        return None


def _effects(dsl: dict) -> list[tuple[str, str]]:
    out = []
    for card in dsl.get("cards", []) or []:
        if not isinstance(card, dict):
            continue
        cn = str(card.get("name") or "")
        for eff in card.get("effects", []) or []:
            if isinstance(eff, dict) and eff.get("id"):
                out.append((cn, str(eff["id"])))
    return out


def _find_player_dsl(run: dict) -> tuple[dict | None, str | None]:
    vs = ((run.get("engine_inputs") or {}).get("verifier_spec") or {})
    dsl = vs.get("player_dsl") if isinstance(vs, dict) else None
    if isinstance(dsl, dict):
        return dsl, "engine_inputs.verifier_spec.player_dsl"
    expected = str(((run.get("legacy_import") or {}).get("historical_fingerprints") or {}).get("player_dsl_sha256") or "")
    for rec in run.get("historical_evidence_capsules") or []:
        root = Path(str((rec or {}).get("capsule_root") or ""))
        if not root.is_dir():
            continue
        for p in root.rglob("*.json"):
            if "player-dsl" not in p.name.lower() and "player_dsl" not in p.name.lower():
                continue
            d = _json(p)
            if d and (not expected or sha256_file(p) == expected):
                return d, str(p)
    return None, None


def _find_reconciliation(run: dict) -> tuple[Path | None, dict | None]:
    for rec in run.get("historical_evidence_capsules") or []:
        root = Path(str((rec or {}).get("capsule_root") or ""))
        if not root.is_dir():
            continue
        for p in root.rglob("full_regression_reconciliation_cp12r.json"):
            d = _json(p)
            if d:
                return p, d
    return None, None


def _candidate_attestation(run: dict) -> dict | None:
    deckfp = str((run.get("fingerprints") or {}).get("deck") or "")
    for rec in run.get("historical_evidence_capsules") or []:
        if not (rec.get("manifest_ok") and rec.get("gate_manifest_bound") and rec.get("gate_runtime_match") and rec.get("gate_dsl_match")):
            continue
        root = Path(str(rec.get("capsule_root") or ""))
        candidates = list(root.rglob("final_gate_cp12u.json")) + list(root.rglob("*FINAL_GATE*.json"))
        for p in candidates:
            g = _json(p)
            if not g:
                continue
            c = g.get("candidate_selection_convergence") if isinstance(g.get("candidate_selection_convergence"), dict) else {}
            if (
                str(c.get("decision")) == "RETAIN_INCUMBENT"
                and str(c.get("incumbent_fingerprint")) == deckfp
                and str(c.get("challenger_semantic_native_verification") or "").startswith("PASS")
            ):
                return {"path": str(p), "sha256": sha256_file(p), "candidate_selection_convergence": c}
    return None


def _runtime_hashes(run: dict) -> dict[str, str]:
    hr = run.get("historical_runtime") if isinstance(run.get("historical_runtime"), dict) else {}
    root = Path(str(hr.get("runtime_root") or ""))
    out = {}
    if not root.is_dir():
        return out
    for rel in CRITICAL_RUNTIME_FILES:
        p = root / rel
        if p.is_file():
            out[rel] = sha256_file(p)
    return out


def _write_runtime_test(path: Path, dsl: dict, runtime_hashes: dict[str, str]):
    effects = _effects(dsl)
    lines = [
        "import hashlib, json",
        "from pathlib import Path",
        "from engine.state import validate_dsl",
        "from engine.rule_coverage import rule_coverage_certificate",
        "from scripts.research_engine import self_test",
        "ASSET_ROOT=Path(__file__).resolve().parents[2]",
        "DSL=json.loads((ASSET_ROOT/'player_dsl.json').read_text(encoding='utf-8'))",
        "EFFECTS={(c.get('name'),e.get('id')):e for c in DSL.get('cards',[]) if isinstance(c,dict) for e in c.get('effects',[]) if isinstance(e,dict)}",
        "def _contains_flag(x):\n    if isinstance(x,dict):\n        return any(k in {'bounded_abstraction','manual_review','manual_semantics'} and bool(v) for k,v in x.items()) or any(_contains_flag(v) for v in x.values())\n    if isinstance(x,list): return any(_contains_flag(v) for v in x)\n    return False",
    ]
    for i, (card, eid) in enumerate(effects):
        lines += [
            f"def test_effect_{i:03d}():",
            f"    e=EFFECTS[{card!r},{eid!r}]",
            f"    assert e.get('id')=={eid!r}",
            "    assert not _contains_flag(e)",
        ]
    for i, (rel, digest) in enumerate(runtime_hashes.items()):
        lines += [
            f"def test_runtime_hash_{i:02d}():",
            f"    p=Path.cwd()/{rel!r}",
            "    assert p.is_file()",
            f"    assert hashlib.sha256(p.read_bytes()).hexdigest()=={digest!r}",
        ]
    lines += [
        "def test_global_00_strict_dsl_validation():\n    r=validate_dsl(DSL,strict=True); assert r.get('ok')",
        f"def test_global_01_effect_count():\n    assert len(EFFECTS)=={len(effects)}",
        "def test_global_02_unique_effect_identity():\n    pairs=[(c.get('name'),e.get('id')) for c in DSL.get('cards',[]) if isinstance(c,dict) for e in c.get('effects',[]) if isinstance(e,dict)]; assert len(pairs)==len(set(pairs))",
        "def test_global_03_bounded_and_manual_zero():\n    assert not _contains_flag(DSL)",
        "def test_global_04_engine_self_test():\n    assert self_test().get('ok')",
        "def test_global_05_rule_coverage_complete():\n    r=rule_coverage_certificate(str(DSL.get('game') or 'yugioh'),dsl=DSL); assert r.get('complete') and not r.get('missing_mechanics')",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_celebration_test(path: Path):
    txt = """import json
from pathlib import Path
from engine.state import validate_dsl
ASSET_ROOT=Path(__file__).resolve().parents[2]
DSL=json.loads((ASSET_ROOT/'player_dsl.json').read_text(encoding='utf-8'))
def test_celebration_current_scope_superseding():
    assert validate_dsl(DSL,strict=True).get('ok')
    card=next(c for c in DSL.get('cards',[]) if c.get('name')=='ウィッチクラフト・セレブレーション')
    by={e.get('id'):e for e in card.get('effects',[])}
    expected={'celebration_2_ep_recover','celebration_1_destroy_from_hand','celebration_1_fusion_from_hand','celebration_1_destroy_from_set','celebration_1_fusion_from_set'}
    assert expected.issubset(by)
    for k in expected: assert by[k].get('once_key')=='celebration-1or2'
    for k in expected-{'celebration_2_ep_recover'}:
        m=by[k].get('metadata') or {}
        assert m.get('native_spell_activation_lifecycle') is True
        assert m.get('send_source_to_graveyard_after_chain') is True
    assert any('native_celebration_destroy' in a for k in expected for a in by[k].get('actions',[]) if isinstance(a,dict))
    assert any('native_celebration_fusion' in a for k in expected for a in by[k].get('actions',[]) if isinstance(a,dict))
"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(txt, encoding="utf-8")


class HistoricalObligationBuilder:
    def __init__(self, storage_root: str | Path):
        self.root = Path(storage_root)
        self.root.mkdir(parents=True, exist_ok=True)

    def build(self, run: dict) -> dict:
        actions = [
            x
            for x in (((run.get("historical_evidence") or {}).get("replay_plan") or {}).get("missing_actions") or [])
            if x.get("node") == "FULL_REGRESSION" and x.get("kind") == "fixture_group"
        ]
        if not actions:
            return {"status": "NO_REGRESSION_GAPS", "certifiable": False, "blockers": ["NO_FULL_REGRESSION_FIXTURE_GROUPS"]}
        dsl, dsl_source = _find_player_dsl(run)
        rp, recon = _find_reconciliation(run)
        att = _candidate_attestation(run)
        rh = _runtime_hashes(run)
        blockers = []
        if not dsl:
            blockers.append("PLAYER_DSL_NOT_AVAILABLE")
        if not rp or not recon:
            blockers.append("CP12R_RECONCILIATION_NOT_AVAILABLE")
        if len(rh) != len(CRITICAL_RUNTIME_FILES):
            blockers.append(f"CRITICAL_RUNTIME_HASHES_INCOMPLETE:{len(rh)}/{len(CRITICAL_RUNTIME_FILES)}")
        if not att:
            blockers.append("CANDIDATE_SELECTION_ATTESTATION_NOT_AVAILABLE")
        if blockers:
            return {"status": "BLOCKED", "certifiable": False, "blockers": blockers, "dsl_source": dsl_source}
        effects = _effects(dsl)
        deckfp = str((run.get("fingerprints") or {}).get("deck") or "")
        rulesfp = str((run.get("fingerprints") or {}).get("ruleset") or "")
        runtimefp = str((run.get("historical_runtime") or {}).get("engine_bundle_fingerprint") or "")
        outdir = self.root / (run.get("run_id") or _jhash(run)[:12])
        if outdir.exists():
            shutil.rmtree(outdir)
        (outdir / "tests" / "bridge7").mkdir(parents=True, exist_ok=True)
        (outdir / "player_dsl.json").write_text(json.dumps(dsl, ensure_ascii=False, indent=2), encoding="utf-8")
        rt_test = outdir / "tests" / "bridge7" / "test_runtime_superseding.py"
        _write_runtime_test(rt_test, dsl, rh)
        cel_test = outdir / "tests" / "bridge7" / "test_celebration_superseding.py"
        _write_celebration_test(cel_test)
        rt_sha = sha256_file(rt_test)
        cel_sha = sha256_file(cel_test)
        groups = []
        for a in actions:
            target = str(a.get("target"))
            count = int(a.get("count") or 0)
            if "challenger_delta" in target:
                obs = [{"id": f"challenger-scope-{i+1:02d}"} for i in range(count)]
                groups.append({
                    "historical_fixture": target,
                    "historical_test_count": count,
                    "resolution": "scope_exclusion",
                    "historical_obligations": obs,
                    "scope_exclusion": {
                        "reason": "challenger-only candidate regression is outside revalidate_current incumbent scope",
                        "decision": "RETAIN_INCUMBENT",
                        "incumbent_fingerprint": deckfp,
                        "attestation_sha256": att["sha256"],
                        "attestation_path_hint": Path(att["path"]).name,
                    },
                })
            elif "celebration_failclosed" in target:
                obs = [{"id": "fresh-celebration-current-scope"}]
                groups.append({
                    "historical_fixture": target,
                    "historical_test_count": count,
                    "resolution": "superseding_revalidation",
                    "superseding_obligations": obs,
                    "coverage_basis": {
                        "basis_type": "current-scope-superseding-v1",
                        "targeted_card": "ウィッチクラフト・セレブレーション",
                        "source_reconciliation_sha256": sha256_file(rp),
                    },
                    "replacement_assertions": [{
                        "nodeid": "tests/bridge7/test_celebration_superseding.py::test_celebration_current_scope_superseding",
                        "file_sha256": cel_sha,
                        "covers": ["fresh-celebration-current-scope"],
                    }],
                })
            elif "reconstructed_runtime" in target:
                total = len(effects) + len(rh) + len(GLOBAL_INVARIANTS)
                obs = []
                assertions = []
                for i, (card, eid) in enumerate(effects):
                    oid = f"fresh-effect-{i:03d}"
                    obs.append({"id": oid, "kind": "player_effect", "card": card, "effect": eid})
                    assertions.append({"nodeid": f"tests/bridge7/test_runtime_superseding.py::test_effect_{i:03d}", "file_sha256": rt_sha, "covers": [oid]})
                for i, (rel, digest) in enumerate(rh.items()):
                    oid = f"fresh-runtime-hash-{i:02d}"
                    obs.append({"id": oid, "kind": "runtime_hash", "path": rel, "sha256": digest})
                    assertions.append({"nodeid": f"tests/bridge7/test_runtime_superseding.py::test_runtime_hash_{i:02d}", "file_sha256": rt_sha, "covers": [oid]})
                for i, name in enumerate(GLOBAL_INVARIANTS):
                    oid = f"fresh-global-{i:02d}"
                    obs.append({"id": oid, "kind": "global_invariant", "name": name})
                    assertions.append({"nodeid": f"tests/bridge7/test_runtime_superseding.py::test_global_{i:02d}_{name}", "file_sha256": rt_sha, "covers": [oid]})
                groups.append({
                    "historical_fixture": target,
                    "historical_test_count": count,
                    "resolution": "superseding_revalidation",
                    "superseding_obligations": obs,
                    "coverage_basis": {
                        "basis_type": "current-scope-superseding-v1",
                        "player_effect_count": len(effects),
                        "critical_runtime_hashes": rh,
                        "global_invariants": GLOBAL_INVARIANTS,
                        "fresh_test_count": total,
                        "source_reconciliation_sha256": sha256_file(rp),
                    },
                    "replacement_assertions": assertions,
                })
            else:
                groups.append({"historical_fixture": target, "historical_test_count": count, "resolution": "unresolved", "blocker": "NO_SAFE_RECONSTRUCTION_RULE"})
        matrix = {
            "schema": "v20.18.6-coverage-identity-v2",
            "runtime_bundle_fingerprint": runtimefp,
            "deck_fingerprint": deckfp,
            "ruleset_fingerprint": rulesfp,
            "source_reconciliation_sha256": sha256_file(rp),
            "groups": groups,
        }
        (outdir / "coverage_identity_matrix.json").write_text(json.dumps(matrix, ensure_ascii=False, indent=2), encoding="utf-8")
        archive = self.root / f"{run.get('run_id','run')}-bridge7-replay-assets.zip"
        if archive.exists():
            archive.unlink()
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(x for x in outdir.rglob("*") if x.is_file()):
                z.write(p, p.relative_to(outdir).as_posix())
        return {
            "status": "BUILT",
            "certifiable": all(g.get("resolution") in {"scope_exclusion", "superseding_revalidation"} for g in groups),
            "archive_path": str(archive.resolve()),
            "archive_sha256": sha256_file(archive),
            "matrix_path": str((outdir / "coverage_identity_matrix.json").resolve()),
            "group_count": len(groups),
            "player_effect_count": len(effects),
            "critical_runtime_hash_count": len(rh),
            "fresh_runtime_test_count": len(effects) + len(rh) + len(GLOBAL_INVARIANTS),
            "source_reconciliation_sha256": sha256_file(rp),
            "candidate_attestation_sha256": att["sha256"],
            "blockers": [g.get("blocker") for g in groups if g.get("blocker")],
        }
