from __future__ import annotations
import argparse, importlib.util, json, os, sys
from pathlib import Path

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(p,v): Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')

def import_legacy(root:Path):
    sys.path.insert(0,str(root))
    p=root/'scripts'/'research_engine.py'
    spec=importlib.util.spec_from_file_location('vtd_bridge6_legacy_research_engine',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--legacy-root',required=True);ap.add_argument('--player',required=True);ap.add_argument('--manifest',required=True);ap.add_argument('--seed',type=int,required=True);ap.add_argument('--out',required=True);ap.add_argument('--cache-dir',required=True);ap.add_argument('--checkpoint-dir',required=True);a=ap.parse_args()
    re=import_legacy(Path(a.legacy_root).resolve());player=load(a.player);manifest=load(a.manifest)
    out=re.run_reality_calibrated_full_match_suite(player,manifest,'final',a.seed,a.cache_dir,a.checkpoint_dir,2)
    dump(a.out,out);print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()
