from __future__ import annotations
import ipaddress, os, socket, tempfile, urllib.parse, urllib.request
from pathlib import Path

class SafeDownloadError(RuntimeError): pass

_PRIVATE_HOSTS={"localhost","localhost.localdomain"}

def _allowed_host(host:str)->bool:
    raw=os.environ.get("VTD_FILE_HOST_ALLOWLIST","").strip()
    if not raw:return True
    host=host.lower().rstrip('.')
    for pat in [x.strip().lower().rstrip('.') for x in raw.split(',') if x.strip()]:
        if pat.startswith('*.') and (host==pat[2:] or host.endswith(pat[1:])): return True
        if host==pat:return True
    return False

def validate_external_url(url:str)->urllib.parse.ParseResult:
    p=urllib.parse.urlparse(url)
    if p.scheme!="https" and not (p.scheme=="http" and os.environ.get("VTD_ALLOW_HTTP_FILE_URL")=="1"):
        raise SafeDownloadError("file download URL must use HTTPS")
    host=(p.hostname or "").lower().rstrip('.')
    if not host or host in _PRIVATE_HOSTS or not _allowed_host(host): raise SafeDownloadError("file download host is not allowed")
    try:
        literal=ipaddress.ip_address(host)
        if literal.is_private or literal.is_loopback or literal.is_link_local or literal.is_multicast or literal.is_reserved or literal.is_unspecified:
            raise SafeDownloadError("private/local file download address is not allowed")
    except ValueError:
        # DNS rebinding defense: reject a hostname if any currently resolved address is non-public.
        try:addrs={x[4][0] for x in socket.getaddrinfo(host,p.port or 443,type=socket.SOCK_STREAM)}
        except socket.gaierror:addrs=set()
        for addr in addrs:
            try: ip=ipaddress.ip_address(addr)
            except ValueError: continue
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
                raise SafeDownloadError("file download hostname resolves to a private/local address")
    return p

class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_external_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def download_limited(*, url:str, storage_root:str|Path, filename:str, max_bytes:int, user_agent:str)->Path:
    validate_external_url(url)
    root=Path(storage_root);root.mkdir(parents=True,exist_ok=True)
    tmp_dir=Path(tempfile.mkdtemp(prefix="vtd-safe-download-",dir=root));dest=tmp_dir/filename
    opener=urllib.request.build_opener(_SafeRedirect())
    req=urllib.request.Request(url,headers={"User-Agent":user_agent,"Accept":"application/zip,application/octet-stream"})
    total=0
    with opener.open(req,timeout=60) as resp,dest.open("wb") as f:
        final_url=str(getattr(resp,"url",url));validate_external_url(final_url)
        while True:
            chunk=resp.read(1024*1024)
            if not chunk:break
            total+=len(chunk)
            if total>max_bytes: raise SafeDownloadError("download exceeds size limit")
            f.write(chunk)
    return dest
