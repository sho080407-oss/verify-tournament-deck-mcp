from __future__ import annotations
import argparse, json
from urllib.parse import urlparse

p=argparse.ArgumentParser()
p.add_argument('--host', required=True, help='Public hostname, e.g. tournament-deck-verifier.onrender.com')
p.add_argument('--publisher-name', required=True)
p.add_argument('--demo-url', required=True)
p.add_argument('--output', default='FINAL_PUBLIC_RELEASE.json')
a=p.parse_args()
h=a.host.strip().replace('https://','').rstrip('/')
base=f'https://{h}'
for u in (base, a.demo_url):
    q=urlparse(u)
    if q.scheme!='https' or not q.netloc:
        raise SystemExit(f'HTTPS URL required: {u}')
out={
  'publisher_name': a.publisher_name.strip(),
  'category': 'Developer Tools',
  'mcp_url': f'{base}/mcp',
  'website_url': f'{base}/',
  'support_url': f'{base}/support',
  'privacy_url': f'{base}/privacy',
  'terms_url': f'{base}/terms',
  'demo_url': a.demo_url.strip(),
}
with open(a.output,'w',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False,indent=2)
print(json.dumps(out,ensure_ascii=False,indent=2))
