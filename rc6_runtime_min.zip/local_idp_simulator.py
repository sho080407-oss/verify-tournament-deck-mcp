"""Development-only local OAuth/OIDC simulator for Bridge 19 E2E.

This is NOT an authorization server and must never be used in production.
It exists only to exercise the real verifier over HTTP with:
- OIDC Discovery
- JWKS retrieval and key rotation
- RS256 access-token signatures
- exact resource/audience binding
- scope and issuer enforcement
"""
from __future__ import annotations

import base64
import json
import os
import time
from urllib.parse import parse_qs

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route

if os.environ.get("VTD_ENV", "development").lower() == "production":
    raise RuntimeError("local IdP simulator is forbidden in production")
if os.environ.get("VTD_DEV_ALLOW_LOCAL_AUTH_SIM") != "1":
    raise RuntimeError("set VTD_DEV_ALLOW_LOCAL_AUTH_SIM=1 for the local IdP simulator")


def _b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _jwk_from_key(private_key, kid: str) -> dict:
    pub = private_key.public_key().public_numbers()
    return {
        "kty": "RSA",
        "kid": kid,
        "use": "sig",
        "key_ops": ["verify"],
        "alg": "RS256",
        "n": _b64u(pub.n.to_bytes((pub.n.bit_length() + 7) // 8, "big")),
        "e": _b64u(pub.e.to_bytes((pub.e.bit_length() + 7) // 8, "big")),
    }


class _KeyRing:
    def __init__(self):
        self.generation = 0
        self.rotate()

    def rotate(self):
        self.generation += 1
        self.kid = f"bridge19-key-{self.generation}"
        self.private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.jwk = _jwk_from_key(self.private_key, self.kid)

    def sign(self, claims: dict) -> str:
        header = {"alg": "RS256", "kid": self.kid, "typ": "JWT"}
        h = _b64u(json.dumps(header, separators=(",", ":"), sort_keys=True).encode())
        p = _b64u(json.dumps(claims, separators=(",", ":"), sort_keys=True).encode())
        signing = f"{h}.{p}".encode("ascii")
        sig = self.private_key.sign(signing, padding.PKCS1v15(), hashes.SHA256())
        return f"{h}.{p}.{_b64u(sig)}"


KEYS = _KeyRing()
ISSUED_TOKENS: dict[str, dict] = {}


def _issuer(request: Request) -> str:
    configured = os.environ.get("VTD_LOCAL_IDP_ISSUER")
    if configured:
        return configured
    return str(request.base_url).rstrip("/")


async def discovery(request: Request):
    iss = _issuer(request)
    return JSONResponse({
        "issuer": iss,
        "authorization_endpoint": iss + "/authorize",
        "token_endpoint": iss + "/token",
        "jwks_uri": iss + "/jwks",
        "code_challenge_methods_supported": ["S256"],
        "token_endpoint_auth_methods_supported": ["none"],
        "client_id_metadata_document_supported": True,
        "authorization_response_iss_parameter_supported": True,
        "userinfo_endpoint": iss + "/userinfo",
        "scopes_supported": ["openid", "email", "deck:verify"],
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code"],
    })


async def jwks(_request: Request):
    return JSONResponse({"keys": [KEYS.jwk]})


async def authorize(request: Request):
    # Browser authorization is intentionally not implemented. The endpoint only
    # exists so the discovery document is complete for preflight validation.
    return PlainTextResponse("development simulator: browser authorization not implemented", status_code=501)


async def token(request: Request):
    body = (await request.body()).decode("utf-8", "replace")
    d = {k: v[-1] for k, v in parse_qs(body, keep_blank_values=True).items()}
    if d.get("grant_type") != "authorization_code":
        return JSONResponse({"error": "unsupported_grant_type"}, status_code=400)
    if not d.get("code_verifier"):
        return JSONResponse({"error": "invalid_request", "error_description": "code_verifier required"}, status_code=400)
    subject = d.get("code") or "bridge19-user"
    resource = d.get("resource")
    scope = d.get("scope") or "deck:verify"
    now = int(time.time())
    try:
        lifetime = int(d.get("lifetime", "300"))
    except ValueError:
        lifetime = 300
    claims = {
        "iss": d.get("issuer_override") or _issuer(request),
        "sub": subject,
        "client_id": d.get("client_id") or "bridge19-client",
        "scope": scope,
        "iat": now,
        "nbf": now - 1,
        "exp": now + lifetime,
    }
    if resource:
        claims["aud"] = resource
        claims["resource"] = resource
    access_token = KEYS.sign(claims)
    ISSUED_TOKENS[access_token] = {
        "sub": subject,
        "email": f"{subject}@example.test",
        "email_verified": True,
        "scope": scope,
        "exp": claims["exp"],
    }
    return JSONResponse({
        "access_token": access_token,
        "token_type": "Bearer",
        "expires_in": max(0, lifetime),
        "scope": scope,
    })


async def userinfo(request: Request):
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        return JSONResponse({"error": "invalid_token"}, status_code=401)
    token = auth.split(" ", 1)[1].strip()
    row = ISSUED_TOKENS.get(token)
    if not row or int(row.get("exp") or 0) < int(time.time()):
        return JSONResponse({"error": "invalid_token"}, status_code=401)
    scopes = str(row.get("scope") or "").split()
    if "openid" not in scopes or "email" not in scopes:
        return JSONResponse({"error": "insufficient_scope"}, status_code=403)
    return JSONResponse({"sub": row["sub"], "email": row["email"], "email_verified": True})


async def rotate(_request: Request):
    KEYS.rotate()
    return JSONResponse({"kid": KEYS.kid, "generation": KEYS.generation})


async def health(_request: Request):
    return JSONResponse({"ok": True, "kid": KEYS.kid})


app = Starlette(routes=[
    Route("/.well-known/openid-configuration", discovery, methods=["GET"]),
    Route("/.well-known/oauth-authorization-server", discovery, methods=["GET"]),
    Route("/jwks", jwks, methods=["GET"]),
    Route("/authorize", authorize, methods=["GET"]),
    Route("/token", token, methods=["POST"]),
    Route("/userinfo", userinfo, methods=["GET"]),
    Route("/rotate", rotate, methods=["POST"]),
    Route("/healthz", health, methods=["GET"]),
])
