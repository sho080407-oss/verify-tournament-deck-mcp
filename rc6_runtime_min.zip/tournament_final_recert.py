from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from runtime_restore import sha256_file
from replay_resolver import merge_replay_result, unresolved_actions

PASS_PREFIXES=("PASS",)
CANONICAL_NINE=("エルフェンノーツ","光と闇の儀式","閃刀姫","獄神系","破械","三幻魔","M∀LICE","キラーチューン","烙印")
ALIASES={
    "エルフェンノーツ":("elfen","elfennote","elfen_notes"),
    "光と闇の儀式":("lightdark","light_dark","ritual"),
    "閃刀姫":("skystriker","sky_striker","sky"),
    "獄神系":("gokushin","darklord"),
    "破械":("unchained",),
    "三幻魔":("sacred","sacred_beast","sacredbeast"),
    "M∀LICE":("malice",),
    "キラーチューン":("kewltune","killer_tune","killertune"),
    "烙印":("branded",),
}
RUNTIME_ATTESTATION_KEYS={
    "engine_full_match_sha256":"engine/full_match.py",
    "engine_rule_kernel_sha256":"engine/rule_kernel.py",
    "engine_action_templates_sha256":"engine/action_templates.py",
    "engine_route_planner_sha256":"engine/route_planner.py",
    "engine_state_sha256":"engine/state.py",
    "engine_mechanics_sha256":"engine/mechanics.py",
    "engine_ygo_geometry_sha256":"engine/ygo_geometry.py",
    "engine_yugioh_plugin_sha256":"engine/plugins/yugioh.py",
}

class TournamentFinalRecertError(RuntimeError): pass

def _hash(v:Any)->str:
    return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def _json(p:Path)->dict|None:
    try:
        v=json.loads(p.read_text(encoding="utf-8")); return v if isinstance(v,dict) else None
    except Exception:return None

def _date(v:Any)->str|None:
    if isinstance(v,dict):
        v=v.get("effective_date") or v.get("effective_limit") or v.get("current_effective_limit") or v.get("previous_effective_limit")
    m=re.search(r"(20\d{2})[-_/](\d{2})[-_/](\d{2})",str(v or ""));return "-".join(m.groups()) if m else None

def _pass(v:Any)->bool:
    if v is True:return True
    if isinstance(v,dict):
        if v.get("ok") is True:return True
        return str(v.get("status") or "").upper().startswith(PASS_PREFIXES)
    return str(v or "").upper().startswith(PASS_PREFIXES)

def _legacy_deck_fp(run:dict)->str:
    return str(((run.get("legacy_import") or {}).get("declared_deck_fingerprint") or ""))

def _player_dsl_sha(run:dict)->str:
    h=str(((run.get("legacy_import") or {}).get("historical_fingerprints") or {}).get("player_dsl_sha256") or "")
    if h:return h
    dsl=(((run.get("engine_inputs") or {}).get("verifier_spec") or {}).get("player_dsl"))
    if isinstance(dsl,dict):return _hash(dsl)
    return ""

def _runtime_root(run:dict)->Path|None:
    hr=run.get("historical_runtime") if isinstance(run.get("historical_runtime"),dict) else {}
    p=Path(str(hr.get("runtime_root") or ""))
    return p if hr.get("activated") and hr.get("status")=="VERIFIED_EXACT" and p.is_dir() else None

def _lineage_quarantines(run:dict)->list[Path]:
    hr=run.get("historical_runtime") if isinstance(run.get("historical_runtime"),dict) else {}
    rows=list(hr.get("lineage") or [])
    if hr.get("runtime_root"):rows.append(hr)
    out=[];seen=set()
    for row in rows:
        if not isinstance(row,dict):continue
        rr=Path(str(row.get("runtime_root") or ""))
        q=rr.parent/"quarantine"
        if q.is_dir() and str(q.resolve()) not in seen:
            seen.add(str(q.resolve()));out.append(q)
    return out

def _find_gate(run:dict)->tuple[dict|None,dict|None,Path|None]:
    for rec in reversed(run.get("historical_evidence_capsules") or []):
        if not isinstance(rec,dict):continue
        if not (rec.get("manifest_ok") and rec.get("gate_manifest_bound") and rec.get("gate_runtime_match") and rec.get("gate_dsl_match")):continue
        root=Path(str(rec.get("capsule_root") or ""))
        if not root.is_dir():continue
        for p in list(root.rglob("final_gate_cp12u.json"))+list(root.rglob("*FINAL_GATE*.json")):
            g=_json(p)
            if g and _pass(g):return g,rec,p
    return None,None,None

def _candidate_tf_checkpoints(run:dict)->list[tuple[dict,Path]]:
    out=[]
    for q in _lineage_quarantines(run):
        for p in q.rglob("*.json"):
            d=_json(p)
            if not d:continue
            tf=d.get("tournament_final") if isinstance(d.get("tournament_final"),dict) else None
            if tf and _pass(tf) and isinstance(tf.get("matchups"),dict):out.append((d,p))
    out.sort(key=lambda x:(len((x[0].get("tournament_final") or {}).get("matchups") or {}),str(x[0].get("created_at_jst") or "")),reverse=True)
    return out

def _runtime_hash_checks(doc:dict,runtime:Path)->dict:
    fp=doc.get("fingerprints") if isinstance(doc.get("fingerprints"),dict) else {}
    checks={};ok=True;count=0
    for key,rel in RUNTIME_ATTESTATION_KEYS.items():
        want=str(fp.get(key) or doc.get(key) or "").lower()
        if not re.fullmatch(r"[0-9a-f]{64}",want):continue
        count+=1;p=runtime/rel;got=sha256_file(p) if p.is_file() else None;match=(got==want)
        checks[rel]={"expected":want,"actual":got,"match":match};ok=ok and match
    return {"ok":bool(count and ok),"count":count,"files":checks}

def _find_archive_file(run:dict,basename:str)->Path|None:
    for q in _lineage_quarantines(run):
        hits=list(q.rglob(basename))
        if hits:return hits[0]
    return None

def _aggregate_check(run:dict,name:str,row:dict)->dict:
    agg=str(row.get("aggregate") or "").strip()
    if not agg:return {"required":False,"ok":True}
    p=_find_archive_file(run,Path(agg).name)
    # Some historical resume bundles intentionally flattened long evidence paths.
    # Accept only explicit, matchup-specific aliases and still validate the aggregate body.
    if not p:
        aliases={
            "M∀LICE":["malice_final_aggregate.json"],
            "キラーチューン":["kewltune_final_aggregate.json"],
        }
        for alias in aliases.get(name,[]):
            p=_find_archive_file(run,alias)
            if p:break
    if not p:return {"required":True,"ok":False,"reason":"aggregate_missing","declared":agg}
    d=_json(p)
    if not d:return {"required":True,"ok":False,"reason":"aggregate_invalid_json","path":str(p)}
    eff=d.get("effective") if isinstance(d.get("effective"),dict) else d
    cut_ok=all(int(eff.get(k) or 0)==0 for k in ("node_budget_cutoffs","chain_depth_cutoffs","phase_action_cap_hits"))
    term=float(eff.get("terminal_rate") if "terminal_rate" in eff else eff.get("effective_terminal_rate") or 0.0)
    declared_matchup=str(d.get("matchup") or "").strip()
    schema=str(d.get("schema") or "").casefold()
    matchup_ok=(declared_matchup==name) or (name=="キラーチューン" and "kewltune" in schema)
    gate=str(eff.get("gate") or d.get("gate") or "")
    ok=(matchup_ok and _date(d.get("ruleset"))==_date(run.get("ruleset")) and (not _legacy_deck_fp(run) or str(d.get("deck_fingerprint") or "")==_legacy_deck_fp(run)) and term>=0.9 and cut_ok and gate.startswith("PASS"))
    return {"required":True,"ok":ok,"path":str(p),"sha256":sha256_file(p),"terminal_rate":term,"cutoffs_zero":cut_ok,"matchup_identity_ok":matchup_ok}

def cross_attest_tournament_final(run:dict)->dict:
    runtime=_runtime_root(run);gate,gate_rec,gate_path=_find_gate(run);cands=_candidate_tf_checkpoints(run)
    blockers=[]
    if not runtime:blockers.append("VERIFIED_RUNTIME_REQUIRED")
    if not gate:blockers.append("MANIFEST_BOUND_FINAL_GATE_ATTESTATION_REQUIRED")
    if not cands:blockers.append("TOURNAMENT_FINAL_CHECKPOINT_REQUIRED")
    if blockers:return {"status":"BLOCKED","certified":False,"blockers":blockers,"matchups":{}}
    cp,cp_path=cands[0];tf=cp["tournament_final"]
    declared=_legacy_deck_fp(run);rules=_date(run.get("ruleset"));dslsha=_player_dsl_sha(run)
    cp_deck=(cp.get("deck_freeze") or {}).get("deck_fingerprint") if isinstance(cp.get("deck_freeze"),dict) else None
    cp_rules=_date(cp.get("ruleset"));cp_dsl=str((cp.get("fingerprints") or {}).get("player_dsl_sha256") or "")
    gate_deck=str((gate.get("deck") or {}).get("fingerprint") or "") if isinstance(gate.get("deck"),dict) else ""
    gate_rules=_date(gate.get("ruleset"));gate_dsl=str((gate.get("fingerprint_attestation") or {}).get("player_dsl_sha256") or "")
    base_checks={
        "deck_match":bool(declared and cp_deck==declared and gate_deck==declared),
        "ruleset_match":bool(rules and cp_rules==rules and gate_rules==rules),
        "player_dsl_match":bool(dslsha and cp_dsl==dslsha and gate_dsl==dslsha),
        "cp_runtime_hashes":_runtime_hash_checks(cp,runtime),
        "gate_capsule_manifest_bound":bool(gate_rec.get("manifest_ok") and gate_rec.get("gate_manifest_bound")),
        "gate_runtime_match":bool(gate_rec.get("gate_runtime_match")),
        "gate_dsl_match":bool(gate_rec.get("gate_dsl_match")),
    }
    base_ok=all(v if isinstance(v,bool) else v.get("ok") for v in base_checks.values())
    cp_whole=str(((cp.get("reused_without_recompute") or {}).get("whole_dsl_semantic_fidelity") or ""))
    gate_whole=str(((gate.get("evidence") or {}).get("whole_dsl") or "")) if isinstance(gate.get("evidence"),dict) else ""
    whole_dsl_certified=bool(base_ok and "PASS" in cp_whole.upper() and "PASS" in gate_whole.upper() and "bounded=0" in (cp_whole+" "+gate_whole).replace(" ",""))
    gt=((gate.get("evidence") or {}).get("tournament_final") or {}) if isinstance(gate.get("evidence"),dict) else {}
    gm=gt.get("matchups") if isinstance(gt.get("matchups"),dict) else {}
    cm=tf.get("matchups") if isinstance(tf.get("matchups"),dict) else {}
    names=[x for x in CANONICAL_NINE if x in cm or x in gm]
    rows={}
    for name in names:
        a=cm.get(name) if isinstance(cm.get(name),dict) else {};b=gm.get(name) if isinstance(gm.get(name),dict) else {}
        agg=_aggregate_check(run,name,a)
        ok=bool(base_ok and _pass(a) and _pass(b) and agg.get("ok"))
        rows[name]={"certified":ok,"status":"PASS_CROSS_ATTESTED" if ok else "FAIL_CROSS_ATTESTATION","checkpoint_status":a.get("status"),"gate_status":b.get("status"),"aggregate":agg}
    certified=bool(len(rows)==9 and all(x.get("certified") for x in rows.values()))
    payload={"runtime_bundle_fingerprint":((run.get("historical_runtime") or {}).get("engine_bundle_fingerprint")),"checkpoint_sha256":sha256_file(cp_path),"gate_sha256":sha256_file(gate_path),"base_checks":base_checks,"whole_dsl_certified":whole_dsl_certified,"matchups":rows}
    return {"schema":"v20.18.7-tournament-final-cross-attestation-v1","status":"PASS" if certified else "PARTIAL","certified":certified,"whole_dsl_certified":whole_dsl_certified,"historical_final_gate_quarantined":True,"base_checks":base_checks,"matchups":rows,"checkpoint_path":str(cp_path),"checkpoint_sha256":sha256_file(cp_path),"gate_path":str(gate_path),"gate_sha256":sha256_file(gate_path),"certificate_fingerprint":_hash(payload),"blockers":[] if certified else [f"MATCHUP_UNCERTIFIED:{n}" for n,r in rows.items() if not r.get("certified")]+([] if len(rows)==9 else ["NINE_MATCHUP_SET_INCOMPLETE"])}

def apply_cross_attestation(run:dict,cert:dict)->dict:
    out=copy.deepcopy(run)
    prior_certified=set(((out.get("historical_replay") or {}).get("certified_nodes") or []))
    if not isinstance(cert,dict):return out
    for name,row in (cert.get("matchups") or {}).items():
        if not row.get("certified"):continue
        if any(a.get("node")=="TOURNAMENT_FINAL" and str(a.get("target"))==name for a in unresolved_actions(out)):
            result={"suite_pre_holdout_ready":True,"matchups":[{"name":name,"final_ready":True,"source":"historical_cross_attestation","cross_attestation_certificate":cert.get("certificate_fingerprint")}]}
            out["historical_replay"]=merge_replay_result(out,{"node":"TOURNAMENT_FINAL","target":name,"certified":True,"status":"PASS_CROSS_ATTESTED","result":result,"runtime_bundle_fingerprint":((out.get("historical_runtime") or {}).get("engine_bundle_fingerprint"))})
    rr=out.get("historical_replay") if isinstance(out.get("historical_replay"),dict) else {}
    rr["certified_nodes"]=sorted(set(rr.get("certified_nodes") or [])|prior_certified)
    out["historical_replay"]=rr
    out["tournament_final_recertification"]=copy.deepcopy(cert)
    return out

def _extract_inventory(dsl:dict)->tuple[dict,dict]:
    md=dsl.get("metadata") if isinstance(dsl.get("metadata"),dict) else {};inv=md.get("inventory_counts") if isinstance(md.get("inventory_counts"),dict) else {}
    main=inv.get("main") if isinstance(inv.get("main"),dict) else {};extra=inv.get("extra") if isinstance(inv.get("extra"),dict) else {}
    return main,extra

def _deck_dict(rows:list[dict])->dict:
    return {str(x.get("name")):int(x.get("count") or 0) for x in rows or [] if isinstance(x,dict) and x.get("name") and int(x.get("count") or 0)>0}

def _generic_spec(run:dict,opp:dict)->dict|None:
    om,oe=_extract_inventory(opp)
    if not om:return None
    return {"opening_hand_size":5,"first_player":"alternate","game":"yugioh","max_turns":20,"max_actions_per_phase":36,"max_chain_links":14,"adjudicate_horizon":False,"initial_state":{"zones":{"player_deck":_deck_dict((run.get("deck") or {}).get("main",[])),"player_extra":_deck_dict((run.get("deck") or {}).get("extra",[])),"opponent_deck":om,"opponent_extra":oe}},"objective":{"resources":{"draw_pressure":60,"search_lock_pressure":50,"quick_link_pressure":45,"board_value":35,"end_phase_value":25,"hand_disruption":60,"board_wipe_pressure":100,"mass_negate_pressure":100}},"parallel_jobs":0,"parallel_min_trials":1,"parallel_min_chunk":2,"max_parallel_jobs":1,"phase_search_depth":1,"adaptive_phase_search_depth":2,"chain_search_depth":6,"adaptive_chain_search_depth":8,"search_top_k":2,"adaptive_search_top_k":3,"max_policy_search_nodes":128,"critical_policy_search_nodes":256,"information_set_samples":0,"max_information_set_samples":0}

def _asset_candidates(run:dict)->list[Path]:
    roots=_lineage_quarantines(run)
    for rec in run.get("historical_evidence_capsules") or []:
        p=Path(str((rec or {}).get("capsule_root") or ""))
        if p.is_dir():roots.append(p)
    # The packaged Elfen reference is a safe source for fresh execution only, never for historical reuse.
    vendor=Path(__file__).resolve().parent/"vendor"/"v20_17_1"/"references"/"dsl100"/"rokket-elfen-20260921"
    if vendor.is_dir():roots.append(vendor)
    out=[];seen=set()
    for root in roots:
        for p in root.rglob("*.json"):
            s=str(p.resolve())
            if s not in seen:seen.add(s);out.append(p)
    return out

def _match_score(name:str,p:Path,d:dict)->int:
    text=(p.name+" "+str((d.get("metadata") or {}).get("name") if isinstance(d.get("metadata"),dict) else "")+" "+str(d.get("matchup") or "")).casefold()
    score=0
    for hint in ALIASES.get(name,()):
        if hint.casefold() in text:score+=10
    if name.casefold() in text:score+=20
    if isinstance(d.get("cards"),list):score+=5
    if "opponent" in p.name.casefold():score+=4
    return score

def build_executable_suite(run:dict,only_matchups:list[str]|None=None)->dict:
    player=(((run.get("engine_inputs") or {}).get("verifier_spec") or {}).get("player_dsl"))
    if not isinstance(player,dict):return {"status":"BLOCKED","blockers":["PLAYER_DSL_REQUIRED"],"suite_manifest":None,"sources":{}}
    targets=only_matchups or [str(a.get("target")) for a in unresolved_actions(run) if a.get("node")=="TOURNAMENT_FINAL"]
    files=_asset_candidates(run);rows=[];sources={};missing=[]
    existing=(((run.get("engine_inputs") or {}).get("verifier_spec") or {}).get("suite_manifest"))
    existing_rows={str(x.get("name")):copy.deepcopy(x) for x in (existing.get("matchups") if isinstance(existing,dict) else []) or [] if isinstance(x,dict)}
    for name in targets:
        if name in existing_rows:
            rows.append(existing_rows[name]);sources[name]={"mode":"existing_suite_manifest"};continue
        best=None
        for p in files:
            d=_json(p)
            if not d or not isinstance(d.get("cards"),list):continue
            sc=_match_score(name,p,d)
            if sc<=0:continue
            if best is None or sc>best[0]:best=(sc,p,d)
        if not best:
            missing.append(name);continue
        _,p,opp=best;spec=_generic_spec(run,opp)
        if not spec:
            missing.append(name);continue
        cards=[str(c.get("name")) for c in opp.get("cards",[]) if isinstance(c,dict) and c.get("name")]
        rows.append({"name":name,"opponent_dsl":opp,"required_opponent_cards":cards,"passive_opponent_cards":[],"weight":1.0,"spec":spec})
        sources[name]={"mode":"fresh_reconstructed","opponent_dsl_path":str(p),"opponent_dsl_sha256":sha256_file(p),"spec_mode":"inventory_derived_v20.18.7"}
    manifest={"game":"yugioh","require_declared_card_inventory":True,"required_player_cards":[str(c.get("name")) for c in player.get("cards",[]) if isinstance(c,dict) and c.get("name")],"passive_player_cards":[],"declared_mechanics":[],"base_spec":{"opening_hand_size":5,"first_player":"alternate"},"thresholds":{"pathology_trials":2,"screening_trials":12,"final_min_trials":30,"final_max_trials":30,"min_terminal_rate":0.9,"absolute_winrate_target_halfwidth":1.0,"max_phase_action_cap_rate":0.02,"policy_cutoffs_per_game":0.5},"matchups":rows,"metadata":{"bridge8":True,"source":"fresh suite reconstruction; historical PASS is not implied"}}
    return {"status":"READY" if rows and not missing else ("PARTIAL" if rows else "BLOCKED"),"suite_manifest":manifest if rows else None,"sources":sources,"missing_matchups":missing,"suite_manifest_fingerprint":_hash(manifest) if rows else None,"blockers":[f"MATCHUP_ASSET_REQUIRED:{x}" for x in missing]}

def recertify_final_gate(run:dict)->dict:
    cert=run.get("tournament_final_recertification") if isinstance(run.get("tournament_final_recertification"),dict) else {}
    replay=run.get("historical_replay") if isinstance(run.get("historical_replay"),dict) else {}
    he=run.get("historical_evidence") if isinstance(run.get("historical_evidence"),dict) else {};nodes=he.get("nodes") if isinstance(he.get("nodes"),dict) else {}
    rec=run.get("legacy_reconciliation") if isinstance(run.get("legacy_reconciliation"),dict) else {}
    authorized=set(rec.get("authorized_nodes") or [])
    replay_nodes=set(replay.get("certified_nodes") or [])
    checks={
        "legacy_final_gate_quarantined":bool(cert.get("historical_final_gate_quarantined") or ((run.get("legacy_import") or {}).get("final_gate_claim_quarantined"))),
        "whole_dsl_semantic_fidelity":bool(cert.get("whole_dsl_certified") or "WHOLE_DSL_SEMANTIC_FIDELITY" in authorized),
        "full_regression":("FULL_REGRESSION" in replay_nodes or bool((nodes.get("FULL_REGRESSION") or {}).get("certified"))),
        "tournament_final":("TOURNAMENT_FINAL" in replay_nodes or bool(cert.get("certified"))),
        "reality_calibration":bool((nodes.get("REALITY_CALIBRATION") or {}).get("certified")),
        "sealed_holdout":bool((nodes.get("SEALED_HOLDOUT") or {}).get("certified")),
        "final_ci":bool((nodes.get("FINAL_CI") or {}).get("certified")),
        "runtime_exact":bool((run.get("historical_runtime") or {}).get("activated") and (run.get("historical_runtime") or {}).get("status")=="VERIFIED_EXACT"),
        "no_unresolved_replay_actions":len(unresolved_actions(run))==0,
        "no_blockers":not bool(run.get("blockers")),
    }
    ok=all(checks.values())
    payload={"run_id":run.get("run_id"),"deck":(run.get("fingerprints") or {}).get("deck"),"ruleset":(run.get("fingerprints") or {}).get("ruleset"),"runtime":(run.get("historical_runtime") or {}).get("engine_bundle_fingerprint"),"historical_replay":replay.get("certificate_fingerprint"),"tournament_final":cert.get("certificate_fingerprint"),"historical_evidence":he.get("certificate_fingerprint"),"checks":checks}
    return {"schema":"v20.18.7-final-gate-v1","ok":ok,"status":"PASS" if ok else "FAIL_NOT_ELIGIBLE","checks":checks,"certificate_fingerprint":_hash(payload),"historical_final_gate_reused":False,"legacy_claim_quarantined":checks["legacy_final_gate_quarantined"],"final_label":"大会用最終確定" if ok else "未確定","blockers":[] if ok else [k for k,v in checks.items() if not v]}
