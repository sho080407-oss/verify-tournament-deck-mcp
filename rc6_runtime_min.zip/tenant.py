from __future__ import annotations
import hashlib, re
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Principal:
    subject: str
    client_id: str = ""
    issuer: str = ""

    @property
    def stable_key(self) -> str:
        raw = f"{self.issuer}\n{self.subject}".encode("utf-8")
        return hashlib.sha256(raw).hexdigest()[:32]


def principal_from_token(token) -> Principal:
    if token is None:
        raise PermissionError("authenticated MCP principal required")
    claims = getattr(token, "claims", None) or {}
    subject = str(getattr(token, "subject", None) or claims.get("sub") or "").strip()
    client_id = str(getattr(token, "client_id", None) or claims.get("client_id") or "").strip()
    issuer = str(claims.get("iss") or "").strip()
    if not subject:
        # Client-only credentials are still isolated, but never collapse all callers into one bucket.
        subject = client_id
    if not subject:
        raise PermissionError("authenticated token has no subject/client_id")
    return Principal(subject=subject, client_id=client_id, issuer=issuer)


def tenant_root(base: str | Path, principal: Principal) -> Path:
    root = Path(base).resolve() / "tenants" / principal.stable_key
    root.mkdir(parents=True, exist_ok=True)
    return root


def validate_run_id(run_id: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9._-]+", str(run_id or "")):
        raise ValueError("invalid run_id")
    return str(run_id)
