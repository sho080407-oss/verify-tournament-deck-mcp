from __future__ import annotations
import os
from starlette.applications import Starlette
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route, Mount

# Import registers the MCP tools and creates `server` with auth.
from server import server
from telemetry import RawTelemetryMiddleware, metrics
from openai_auth_contract import protected_resource_metadata
from openai_auth_challenge import EnsureWWWAuthenticateMiddleware

VERSION = "20.18.22"

async def health(_):
    return JSONResponse({"ok": True, "service": "verify-tournament-deck", "version": VERSION})

async def ready(_):
    from production_context import BASE_DATA
    ok = BASE_DATA.exists() and os.access(BASE_DATA, os.W_OK)
    return JSONResponse({"ok": ok, "data_dir": str(BASE_DATA), "version": VERSION, "state_backend": "sqlite_wal", "state_schema": 1}, status_code=200 if ok else 503)

async def prom(_):
    return PlainTextResponse(metrics.prometheus(), media_type="text/plain; version=0.0.4")

async def docs_mcp(_):
    return JSONResponse({
        "service": "Tournament Deck Verifier",
        "version": VERSION,
        "transport": "MCP Streamable HTTP",
        "mcp_url": os.environ.get("VTD_PUBLIC_MCP_URL", ""),
        "auth": f"OAuth 2.1 resource server ({os.environ.get('VTD_AUTH_MODE', 'unknown')})",
        "scope": "deck:verify",
        "workspace_identity": "Public OAuth deployment requires OIDC openid/email and UserInfo email_verified=true.",
        "privacy": "Verifier data is tenant-scoped by the validated OAuth subject; historical Final Gate evidence is quarantined and cannot directly certify a v20.18 run.",
    })

async def root(_):
    return JSONResponse({"service": "verify-tournament-deck", "version": VERSION, "mcp": "/mcp", "health": "/healthz", "ready": "/readyz"})


async def openai_apps_challenge(_):
    token = os.environ.get("OPENAI_APPS_CHALLENGE_TOKEN", "").strip()
    if not token:
        return PlainTextResponse("not configured", status_code=404)
    # Plugin Portal requires the exact token as plain text, not JSON.
    return PlainTextResponse(token, media_type="text/plain")

async def oauth_resource_metadata(_):
    try:
        return JSONResponse(protected_resource_metadata())
    except Exception as e:
        if os.environ.get("VTD_ENV", "development").lower() == "production":
            return JSONResponse({"error": "oauth_metadata_misconfigured"}, status_code=503)
        return JSONResponse({"error": "oauth_not_configured", "detail": str(e)}, status_code=404)

mcp_app = server.streamable_http_app()
starlette_app = Starlette(routes=[
    Route('/', root),
    Route('/healthz', health),
    Route('/readyz', ready),
    Route('/metrics', prom),
    Route('/docs/mcp', docs_mcp),
    Route('/.well-known/oauth-protected-resource', oauth_resource_metadata),
    Route('/.well-known/openai-apps-challenge', openai_apps_challenge),
    Mount('/', app=mcp_app),
])
# Add an RFC 9728 WWW-Authenticate challenge to any bare 401 returned by the SDK.
app = EnsureWWWAuthenticateMiddleware(starlette_app)
app = RawTelemetryMiddleware(app)
