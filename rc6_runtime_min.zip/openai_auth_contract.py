from __future__ import annotations
import os
from urllib.parse import urlparse

DEFAULT_SCOPE = "deck:verify"


def _public_origin(resource_url: str) -> str:
    p = urlparse(resource_url)
    if not p.scheme or not p.netloc:
        raise ValueError("resource URL must be absolute")
    return f"{p.scheme}://{p.netloc}"


def protected_resource_metadata(*, resource_url: str | None = None, issuer_url: str | None = None, scopes: list[str] | None = None) -> dict:
    resource = (resource_url or os.environ.get("VTD_PUBLIC_MCP_URL") or "").strip()
    issuer = (issuer_url or os.environ.get("VTD_AUTH_ISSUER_URL") or "").strip()
    if not resource:
        raise RuntimeError("VTD_PUBLIC_MCP_URL is required")
    if not issuer:
        raise RuntimeError("VTD_AUTH_ISSUER_URL is required")
    if os.environ.get("VTD_ENV", "development").lower() == "production" and not resource.startswith("https://"):
        raise RuntimeError("production MCP resource URL must use HTTPS")
    return {
        "resource": resource,
        "authorization_servers": [issuer],
        "scopes_supported": scopes or [DEFAULT_SCOPE],
        "resource_documentation": _public_origin(resource) + "/docs/mcp",
    }


def resource_metadata_url(resource_url: str | None = None) -> str:
    resource = (resource_url or os.environ.get("VTD_PUBLIC_MCP_URL") or "").strip()
    if not resource:
        raise RuntimeError("VTD_PUBLIC_MCP_URL is required")
    return _public_origin(resource) + "/.well-known/oauth-protected-resource"


def www_authenticate(*, resource_url: str | None = None, scope: str = DEFAULT_SCOPE, error: str = "invalid_token", description: str = "Authentication required") -> str:
    meta = resource_metadata_url(resource_url)
    safe_desc = description.replace('"', "'")
    return f'Bearer resource_metadata="{meta}", scope="{scope}", error="{error}", error_description="{safe_desc}"'


def oauth_tool_policy(scopes: list[str] | None = None) -> list[dict]:
    return [{"type": "oauth2", "scopes": list(scopes or [DEFAULT_SCOPE])}]
