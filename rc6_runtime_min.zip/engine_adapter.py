from __future__ import annotations
import copy, hashlib, json, shutil
from pathlib import Path
from typing import Any
from legacy_bridge import LegacyV20171Bridge
from evidence_dag import build_context, plan_reuse, seed_evidence_from_parent
from legacy_importer import parse_legacy_checkpoint, reconcile_legacy_import
from runtime_restore import HistoricalRuntimeRestorer, RuntimeRestoreError
from evidence_capsule import HistoricalEvidenceCapsule, EvidenceCapsuleError
from replay_resolver import MissingEvidenceReplay, ReplayResolverError, merge_replay_result, replay_summary, unresolved_actions
from obligation_builder import HistoricalObligationBuilder
from tournament_final_recert import cross_attest_tournament_final, apply_cross_attestation, build_executable_suite, recertify_final_gate

FINAL_CONFIRMED='TOURNAMENT_FINAL_CONFIRMED'

class EngineAdapter:
    def __init__(self, store):
        self.store=store
        self.bridge=LegacyV20171Bridge()
        self.work_root=Path(store.root)/'_workspaces'
        self.work_root.mkdir(parents=True,exist_ok=True)
        self.runtime_restorer=HistoricalRuntimeRestorer(Path(store.root)/'_historical_runtimes', self.bridge.root)
        self.evidence_capsules=HistoricalEvidenceCapsule(Path(store.root)/'_historical_evidence')
        self.replay_resolver=MissingEvidenceReplay(Path(store.root)/'_historical_replay')
        self.obligation_builder=HistoricalObligationBuilder(Path(store.root)/'_bridge7_assets')

    @staticmethod
    def _hash(value:Any)->str:
        return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

    @staticmethod
    def _normalize_zone(rows:list[dict]|None)->list[dict]:
        merged={}
        for row in rows or []:
            name=str(row.get('name','')).strip(); count=int(row.get('count',0))
            if not name or count<=0: continue
            merged[name]=merged.get(name,0)+count
        return [{'name':k,'count':merged[k]} for k in sorted(merged)]

    @classmethod
    def _normalize_deck(cls,deck:dict)->dict:
        out={'main':cls._normalize_zone(deck.get('main')),'extra':cls._normalize_zone(deck.get('extra')),'side':cls._normalize_zone(deck.get('side'))}
        if sum(x['count'] for x in out['side']): raise ValueError('v20.18 verifier scope is Main+Extra only; side must be empty')
        return out

    @staticmethod
    def _extract_secrets(engine_inputs:dict|None)->tuple[dict,dict]:
        safe=copy.deepcopy(engine_inputs or {}); secrets={}
        vs=safe.get('verifier_spec')
        if isinstance(vs,dict) and 'holdout_secret' in vs:
            secrets['holdout_secret']=vs.pop('holdout_secret')
            vs['holdout_secret_present']=True
        return safe,secrets

    @staticmethod
    def _summary(d: dict) -> dict:
        keys=('run_id','label','status','current_stage','next_stage','final_label','checkpoint_id','fingerprints','reused_evidence','invalidated_evidence','blockers','final_gate','legacy_checkpoint_stage','incremental_plan_summary','legacy_import_summary','legacy_reconciliation_summary','historical_runtime_summary','historical_evidence_summary','historical_replay_summary','replay_asset_builder_summary','tournament_final_recertification_summary','tournament_suite_builder_summary')
        return {k:d.get(k) for k in keys if k in d}

    def _bridge_for_run(self,d:dict)->LegacyV20171Bridge:
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        root=hr.get('runtime_root') if hr.get('activated') and hr.get('status')=='VERIFIED_EXACT' else None
        if root and Path(root).is_dir():
            try:
                return LegacyV20171Bridge(root)
            except Exception:
                pass
        return self.bridge

    @staticmethod
    def _runtime_summary(record:dict|None)->dict:
        record=record if isinstance(record,dict) else {}
        return {k:record.get(k) for k in (
            'status','activated','archive_sha256','runtime_kind','expected_hash_source','expected_hash_count',
            'engine_bundle_fingerprint','self_test_ok','changed_from_parent','unverified_changed_semantic',
            'lineage_stage_id','sealed_read_only','lineage_depth','last_attempt_status','last_attempted_lineage_stage'
        ) if k in record}

    def _attach_historical_runtime_archive(self,run_id:str,archive_path:str|Path,expected_manifest:dict|None=None,source_file:dict|None=None,lineage_stage:str|None=None)->dict:
        d=self.store.read(run_id)
        checkpoint_sets=[]
        if isinstance(d.get('legacy_import'),dict):
            checkpoint_sets=list(d['legacy_import'].get('historical_runtime_hash_sets') or [])
        previous=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        previous_exact=bool(previous.get('activated') and previous.get('status')=='VERIFIED_EXACT' and Path(str(previous.get('runtime_root') or '')).is_dir())
        previous_lineage=list(previous.get('lineage') or [])
        previous_failures=list(previous.get('failed_attempts') or [])

        # Once a base lineage stage has failed, never let a different downstream patch
        # silently start again from the clean runtime. Retrying the same named stage is
        # allowed; a different stage requires a verified parent first.
        if not previous_exact and previous_failures:
            last_failure=previous_failures[-1] if isinstance(previous_failures[-1],dict) else {}
            prior_hint=str(last_failure.get('lineage_stage_hint') or '').strip().casefold()
            next_hint=str(lineage_stage or '').strip().casefold()
            if not next_hint or (prior_hint and next_hint!=prior_hint):
                d['status']='BLOCKED';d['current_stage']='RUNTIME_RESTORATION';d['next_stage']='RUNTIME_RESTORATION'
                d['blockers']=['HISTORICAL_RUNTIME_PARENT_STAGE_NOT_VERIFIED'];d['final_label']='未確定（ブロッカーあり）'
                d['historical_runtime_summary']=self._runtime_summary(previous)
                self.store.write(run_id,d);return self._summary(d)

        base_root=previous.get('runtime_root') if previous_exact else None
        try:
            record=self.runtime_restorer.register_archive_path(
                run_id=run_id,archive_path=archive_path,checkpoint_hash_sets=checkpoint_sets,
                expected_manifest=expected_manifest,source_file=source_file,base_runtime_root=base_root,source_hint=lineage_stage,
            )
        except RuntimeRestoreError as e:
            failure={'status':'REJECTED_ARCHIVE','activated':False,'error':str(e),'lineage_stage_hint':lineage_stage}
            if previous_exact:
                active=copy.deepcopy(previous);active['failed_attempts']=previous_failures+[failure]
                d['historical_runtime']=active
            else:
                failure['lineage']=previous_lineage;failure['failed_attempts']=previous_failures+[failure.copy()]
                d['historical_runtime']=failure
            d['historical_runtime_summary']=self._runtime_summary(d['historical_runtime'])
            d['status']='BLOCKED';d['current_stage']='RUNTIME_RESTORATION';d['next_stage']='RUNTIME_RESTORATION'
            d['blockers']=['HISTORICAL_RUNTIME_ARCHIVE_REJECTED'];d['final_label']='未確定（ブロッカーあり）'
            self.store.write(run_id,d);return self._summary(d)

        record['lineage_stage_hint']=lineage_stage
        if record.get('status')=='HASH_VERIFIED_PENDING_SELF_TEST':
            try:
                candidate=LegacyV20171Bridge(record['runtime_root'])
                health=candidate.health_check(timeout=30)
            except Exception as e:
                health={'ok':False,'error':str(e)}
            record['self_test_ok']=bool(health.get('ok'))
            record['self_test']={k:v for k,v in health.items() if k!='execution'}
            if record['self_test_ok']:
                actual_fp=health.get('bundle_fingerprint') or record.get('engine_bundle_fingerprint')
                if actual_fp != record.get('engine_bundle_fingerprint'):
                    record['status']='QUARANTINED_BUNDLE_FINGERPRINT_DRIFT';record['activated']=False
                else:
                    record['status']='VERIFIED_EXACT';record['activated']=True
                    try:
                        record=self.runtime_restorer.seal_verified_runtime(record)
                    except RuntimeRestoreError as e:
                        record['status']='QUARANTINED_SEAL_FAILED';record['activated']=False;record['seal_error']=str(e)
            else:
                record['status']='QUARANTINED_SELF_TEST_FAILED';record['activated']=False

        lineage_entry={k:record.get(k) for k in (
            'lineage_stage_id','lineage_stage_hint','status','activated','archive_sha256','runtime_kind','expected_hash_source',
            'expected_hash_count','parent_engine_bundle_fingerprint','engine_bundle_fingerprint','self_test_ok',
            'changed_from_parent','unverified_changed_semantic','runtime_root','sealed_read_only'
        )}
        if record.get('activated'):
            # Successful lineage contains successful, executable stages only.
            record['lineage']=previous_lineage+[lineage_entry]
            record['lineage_depth']=len(record['lineage'])
            record['failed_attempts']=previous_failures
            d['historical_runtime']=record
            d['historical_runtime_summary']=self._runtime_summary(record)
            d.setdefault('fingerprints',{})['legacy_engine_bundle']=str(record.get('engine_bundle_fingerprint') or '')
            self._refresh_evidence_context(d)
            self._revalidate_historical_evidence(d)
            if d.get('legacy_import'):
                self._reconcile_legacy_import(d)
            # Exact restoration is an engine provenance operation, not certification.
            d['status']='IN_PROGRESS';d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['blockers']=[];d['final_label']='検証中'
        else:
            # A failed child stage must not erase an already verified parent runtime.
            # Keep the last exact runtime active for safe retry, but block progression.
            failed_entry=dict(lineage_entry)
            if previous_exact:
                active=copy.deepcopy(previous)
                active['failed_attempts']=previous_failures+[failed_entry]
                active['last_attempt_status']=record.get('status')
                active['last_attempted_lineage_stage']=lineage_stage
                d['historical_runtime']=active
            else:
                record['lineage']=previous_lineage
                record['lineage_depth']=len(previous_lineage)
                record['failed_attempts']=previous_failures+[failed_entry]
                d['historical_runtime']=record
            d['historical_runtime_summary']=self._runtime_summary(d['historical_runtime'])
            d['status']='BLOCKED';d['current_stage']='RUNTIME_RESTORATION';d['next_stage']='RUNTIME_RESTORATION'
            d['blockers']=[f"HISTORICAL_RUNTIME_NOT_ACTIVATED:{record.get('status')}"];d['final_label']='未確定（ブロッカーあり）'
        self.store.write(run_id,d);return self._summary(d)

    def attach_historical_runtime_bundle(self,run_id:str,runtime_bundle_file:dict,expected_manifest:dict|None=None,lineage_stage:str|None=None)->dict:
        try:
            path=self.runtime_restorer.download_file(runtime_bundle_file)
        except Exception as e:
            d=self.store.read(run_id)
            previous=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
            failure={'status':'REJECTED_DOWNLOAD','activated':False,'error':str(e),'lineage_stage_hint':lineage_stage}
            if previous.get('activated') and previous.get('status')=='VERIFIED_EXACT':
                active=copy.deepcopy(previous);active['failed_attempts']=list(active.get('failed_attempts') or [])+[failure];d['historical_runtime']=active
            else:
                failure['lineage']=list(previous.get('lineage') or []);failure['failed_attempts']=list(previous.get('failed_attempts') or [])+[failure.copy()];d['historical_runtime']=failure
            d['historical_runtime_summary']=self._runtime_summary(d['historical_runtime']);d['status']='BLOCKED';d['current_stage']='RUNTIME_RESTORATION';d['next_stage']='RUNTIME_RESTORATION';d['blockers']=['HISTORICAL_RUNTIME_DOWNLOAD_FAILED'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        return self._attach_historical_runtime_archive(run_id,path,expected_manifest,source_file=runtime_bundle_file,lineage_stage=lineage_stage)

    @staticmethod
    def _evidence_summary(record:dict|None)->dict:
        record=record if isinstance(record,dict) else {}
        nodes=record.get('nodes') if isinstance(record.get('nodes'),dict) else {}
        return {
            'status':record.get('status'),
            'capsule_sha256':record.get('capsule_sha256'),
            'manifest_ok':record.get('manifest_ok'),
            'certificate_fingerprint':record.get('certificate_fingerprint'),
            'certified_nodes':sorted(k for k,v in nodes.items() if isinstance(v,dict) and v.get('certified')),
            'replay_plan':record.get('replay_plan'),
        }

    def _attach_historical_evidence_archive(self,run_id:str,archive_path:str|Path,source_file:dict|None=None)->dict:
        d=self.store.read(run_id)
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        runtime_root=hr.get('runtime_root') if hr.get('activated') and hr.get('status')=='VERIFIED_EXACT' else None
        if not runtime_root:
            d['status']='BLOCKED';d['current_stage']='EVIDENCE_RESTORATION';d['next_stage']='RUNTIME_RESTORATION'
            d['blockers']=['HISTORICAL_RUNTIME_REQUIRED_BEFORE_EVIDENCE_CAPSULE'];d['final_label']='未確定（ブロッカーあり）'
            self.store.write(run_id,d);return self._summary(d)
        try:
            rec=self.evidence_capsules.inspect_archive(run=d,archive_path=archive_path,runtime_root=runtime_root,source_file=source_file)
        except EvidenceCapsuleError as e:
            d['status']='BLOCKED';d['current_stage']='EVIDENCE_RESTORATION';d['next_stage']='EVIDENCE_RESTORATION'
            d['blockers']=[f'HISTORICAL_EVIDENCE_CAPSULE_REJECTED:{e}'];d['final_label']='未確定（ブロッカーあり）'
            self.store.write(run_id,d);return self._summary(d)
        history=list(d.get('historical_evidence_capsules') or [])
        # Content-addressed dedupe. Keep all distinct capsules because later capsules may
        # close gaps left by earlier ones.
        replaced=False
        for i,x in enumerate(history):
            if isinstance(x,dict) and x.get('capsule_sha256')==rec.get('capsule_sha256'):
                history[i]=rec;replaced=True;break
        if not replaced: history.append(rec)
        d['historical_evidence_capsules']=history
        d['historical_evidence']=self._merge_evidence_certificates(history)
        d['historical_evidence_summary']=self._evidence_summary(d['historical_evidence'])
        if d.get('legacy_import'):
            self._reconcile_legacy_import(d)
        d['status']='IN_PROGRESS';d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['blockers']=[];d['final_label']='検証中'
        self.store.write(run_id,d);return self._summary(d)

    @staticmethod
    def _merge_evidence_certificates(records:list[dict])->dict:
        records=[x for x in records if isinstance(x,dict)]
        nodes={}
        missing=[]
        for rec in records:
            for name,row in (rec.get('nodes') or {}).items():
                if not isinstance(row,dict):continue
                cur=nodes.get(name)
                if cur is None or (row.get('certified') and not cur.get('certified')):
                    nodes[name]=copy.deepcopy(row)
            for action in ((rec.get('replay_plan') or {}).get('missing_actions') or []):
                if action not in missing: missing.append(copy.deepcopy(action))
        # Remove replay actions for nodes that became fully certified by a later capsule.
        missing=[a for a in missing if not ((nodes.get(str(a.get('node'))) or {}).get('certified'))]
        # Prefer precise obligations over a generic fallback emitted by a capsule that did
        # not itself contain the historical reconciliation. When another capsule provides
        # exact missing fixture groups, the generic Full-Regression replay action adds no
        # information and would overstate the work left.
        if any(a.get('node')=='FULL_REGRESSION' and a.get('kind')=='fixture_group' for a in missing):
            missing=[a for a in missing if not (a.get('node')=='FULL_REGRESSION' and a.get('kind')=='certificate_or_replay')]
        payload={'capsules':[x.get('capsule_sha256') for x in records],'certified_nodes':sorted(k for k,v in nodes.items() if v.get('certified'))}
        fp=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        return {
            'schema':'v20.18.4-merged-historical-evidence-v1','status':'VERIFIED_PARTIAL' if records else 'NONE',
            'capsule_sha256':records[-1].get('capsule_sha256') if records else None,
            'manifest_ok':all(bool(x.get('manifest_ok')) for x in records) if records else False,
            'certificate_fingerprint':fp,'nodes':nodes,
            'replay_plan':{'missing_actions':missing,'missing_action_count':len(missing),
                           'missing_regression_test_total':sum(int(a.get('count') or 0) for a in missing if a.get('node')=='FULL_REGRESSION'),
                           'missing_tournament_matchups':[a.get('target') for a in missing if a.get('node')=='TOURNAMENT_FINAL']},
        }

    def attach_historical_evidence_capsule(self,run_id:str,evidence_capsule_file:dict)->dict:
        try:
            path=self.evidence_capsules.download_file(evidence_capsule_file)
        except Exception as e:
            d=self.store.read(run_id);d['status']='BLOCKED';d['current_stage']='EVIDENCE_RESTORATION';d['next_stage']='EVIDENCE_RESTORATION';d['blockers']=[f'HISTORICAL_EVIDENCE_DOWNLOAD_FAILED:{e}'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        return self._attach_historical_evidence_archive(run_id,path,source_file=evidence_capsule_file)

    def _revalidate_historical_evidence(self,d:dict)->None:
        history=list(d.get('historical_evidence_capsules') or [])
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        runtime_root=hr.get('runtime_root') if hr.get('activated') and hr.get('status')=='VERIFIED_EXACT' else None
        if not history or not runtime_root:
            return
        fresh=[]
        for old in history:
            ap=old.get('archive_path') if isinstance(old,dict) else None
            if not ap or not Path(str(ap)).is_file():
                fresh.append(old);continue
            try:
                fresh.append(self.evidence_capsules.inspect_archive(run=d,archive_path=ap,runtime_root=runtime_root,source_file=old.get('source_file')))
            except Exception:
                stale=copy.deepcopy(old);stale['status']='STALE_AFTER_RUNTIME_CHANGE';fresh.append(stale)
        d['historical_evidence_capsules']=fresh
        d['historical_evidence']=self._merge_evidence_certificates(fresh)
        d['historical_evidence_summary']=self._evidence_summary(d['historical_evidence'])

    def create_run(self, *, mode:str, game:str, deck:dict, constraints:dict|None, ruleset:dict, candidate_universe:dict|None, label:str|None, engine_inputs:dict|None=None) -> dict:
        if mode not in {'zero_base','revalidate_current'}: raise ValueError('unsupported mode')
        deck=self._normalize_deck(deck)
        safe_inputs,secrets=self._extract_secrets(engine_inputs)
        payload={'mode':mode,'game':game,'deck':deck,'constraints':constraints or {},'ruleset':ruleset,'candidate_universe':candidate_universe,'label':label,'engine_inputs':safe_inputs}
        d=self.store.create(payload)
        if secrets:self.store.write_secret(d['run_id'],secrets)
        d['fingerprints']={'deck':self._hash(deck),'ruleset':self._hash(ruleset),'request':self._hash({'mode':mode,'game':game,'deck':deck,'constraints':constraints or {},'ruleset':ruleset,'candidate_universe':candidate_universe})}
        self.store.write(d['run_id'],d)
        return self._summary(d)

    def import_legacy_checkpoint(self, *, legacy_checkpoint:dict, related_checkpoints:list[dict]|None=None, game:str="yugioh_ocg", label:str|None=None, deck_override:dict|None=None, ruleset_override:dict|None=None, engine_inputs:dict|None=None) -> dict:
        record=parse_legacy_checkpoint(legacy_checkpoint,related_checkpoints,deck_override=deck_override,ruleset_override=ruleset_override)
        if record.get('integrity_failed'):
            return {
                'status':'BLOCKED_IMPORT','final_label':'未確定（ブロッカーあり）',
                'blockers':['LEGACY_CHECKPOINT_INTEGRITY_FAILED'],
                'legacy_import_summary':{'primary_checkpoint':record.get('primary_checkpoint'),'integrity':record.get('integrity')},
            }
        if not isinstance(record.get('deck'),dict):
            return {
                'status':'BLOCKED_IMPORT',
                'final_label':'未確定（ブロッカーあり）',
                'blockers':['LEGACY_DECK_INVENTORY_REQUIRED'],
                'legacy_import_summary':{
                    'primary_checkpoint':record.get('primary_checkpoint'),
                    'legacy_run_id':record.get('legacy_run_id'),
                    'declared_deck_fingerprint':record.get('declared_deck_fingerprint'),
                    'rejected_related':record.get('rejected_related') or [],
                },
            }
        if not isinstance(record.get('ruleset'),dict) or not record['ruleset'].get('effective_date'):
            return {
                'status':'BLOCKED_IMPORT',
                'final_label':'未確定（ブロッカーあり）',
                'blockers':['LEGACY_RULESET_REQUIRED'],
                'legacy_import_summary':{'primary_checkpoint':record.get('primary_checkpoint')},
            }
        safe_inputs,secrets=self._extract_secrets(engine_inputs)
        deck=self._normalize_deck(record['deck'])
        payload={
            'mode':'revalidate_current','game':game,'deck':deck,'constraints':{},
            'ruleset':record['ruleset'],'candidate_universe':None,
            'label':label or f"legacy:{record.get('primary_checkpoint')}",
            'engine_inputs':safe_inputs,'legacy_import':record,
        }
        d=self.store.create(payload)
        if secrets:self.store.write_secret(d['run_id'],secrets)
        d['fingerprints']={
            'deck':self._hash(deck),'ruleset':self._hash(record['ruleset']),
            'request':self._hash({'mode':'revalidate_current','game':game,'deck':deck,'ruleset':record['ruleset'],'legacy_checkpoint':record.get('primary_checkpoint')}),
        }
        d['legacy_import_summary']={
            'primary_checkpoint':record.get('primary_checkpoint'),
            'legacy_run_id':record.get('legacy_run_id'),
            'legacy_status':record.get('legacy_status'),
            'legacy_final_label':record.get('legacy_final_label'),
            'deck_source':record.get('deck_source'),
            'accepted_sources':[x.get('checkpoint') for x in record.get('accepted_sources',[])],
            'rejected_related':record.get('rejected_related') or [],
            'claimed_pass_nodes':sorted(k for k,v in (record.get('claims') or {}).items() if v.get('pass_claim')),
            'legacy_final_gate_quarantined':bool(record.get('final_gate_claim_quarantined')),
            'integrity':record.get('integrity'),
            'historical_runtime_hash_set_count':len(record.get('historical_runtime_hash_sets') or []),
            'historical_runtime_gap_count':len(record.get('historical_runtime_gaps') or []),
        }
        # A legacy Final Gate PASS is provenance only; v20.18 must recertify.
        d['final_gate']={'ok':False,'status':'NOT_RUN','legacy_claim_quarantined':bool(record.get('final_gate_claim_quarantined'))}
        d['final_label']='検証中'
        self._reconcile_legacy_import(d)
        self.store.write(d['run_id'],d)
        return self._summary(d)

    def _reconcile_legacy_import(self,d:dict)->dict|None:
        if not isinstance(d.get('legacy_import'),dict):
            return None
        bridge=self._bridge_for_run(d)
        engine_fp=(d.get('fingerprints') or {}).get('legacy_engine_bundle') or bridge.bundle_fingerprint()
        rec=reconcile_legacy_import(d,legacy_root=bridge.root,engine_bundle_fingerprint=engine_fp)
        d['legacy_reconciliation']=rec
        d['legacy_reconciliation_summary']={
            'legacy_checkpoint':rec.get('legacy_checkpoint'),
            'authorized_nodes':rec.get('authorized_nodes') or [],
            'denied_nodes':sorted((rec.get('denied_nodes') or {}).keys()),
            'checks':{k:v for k,v in (rec.get('checks') or {}).items() if k in {
                'deck_inventory_match','ruleset_match','player_dsl_hash_match','native_dependency_match',
                'opening_analysis_match','engine_bundle_match','all_declared_engine_components_match',
                'historical_runtime_source_exact','historical_runtime_gap_count','historical_runtime_lineage_complete','historical_regression_evidence_gap_count','historical_regression_evidence_complete'
            }},
            'final_gate_recertification_required':True,
        }
        return rec

    def _prepare_legacy_reuse(self,d:dict,prepared:dict,workspace:Path)->dict:
        rec=self._reconcile_legacy_import(d)
        if not rec:
            return prepared
        seed=copy.deepcopy(rec.get('reuse_seed') or {})
        ev=seed.setdefault('evidence',{})
        # Bridge 5 exact-certified nodes are imported only with their bound evidence.
        he=d.get('historical_evidence') if isinstance(d.get('historical_evidence'),dict) else {}
        nodes=he.get('nodes') if isinstance(he.get('nodes'),dict) else {}
        ho=nodes.get('SEALED_HOLDOUT') if isinstance(nodes.get('SEALED_HOLDOUT'),dict) else {}
        ci=nodes.get('FINAL_CI') if isinstance(nodes.get('FINAL_CI'),dict) else {}
        if ho.get('certified') and isinstance(ho.get('evidence'),dict): ev['sealed_holdout']=copy.deepcopy(ho['evidence'])
        if ci.get('certified') and isinstance(ci.get('evidence'),dict): ev['final_ci']=copy.deepcopy(ci['evidence'])
        # Bridge 6/7 replay results can close only nodes actually rerun or explicitly scope-resolved.
        rr=d.get('historical_replay') if isinstance(d.get('historical_replay'),dict) else {}
        cert=set(rr.get('certified_nodes') or [])
        results=rr.get('results') if isinstance(rr.get('results'),dict) else {}
        if 'FULL_REGRESSION' in cert:
            rows=[v for v in results.values() if isinstance(v,dict) and v.get('node')=='FULL_REGRESSION']
            ev['full_regression']={'schema':'v20.18.6-replay-full-regression-certificate-v2','ok':True,'groups':rows,'certificate_fingerprint':rr.get('certificate_fingerprint')}
        if 'TOURNAMENT_FINAL' in cert:
            parts=[v.get('result') for v in results.values() if isinstance(v,dict) and v.get('node')=='TOURNAMENT_FINAL' and isinstance(v.get('result'),dict)]
            matchups=[]
            for part in parts: matchups.extend(copy.deepcopy(part.get('matchups') or []))
            ev['tournament_final_suite']={'schema':'v20.18.6-replay-tournament-suite-v1','suite_pre_holdout_ready':bool(matchups) and all(bool(x.get('final_ready')) for x in matchups),'matchups':matchups,'replay_certificate_fingerprint':rr.get('certificate_fingerprint')}
        if not ev:
            self.store.write(d['run_id'],d)
            return prepared
        workspace.mkdir(parents=True,exist_ok=True)
        seed_path=workspace/'legacy-evidence-seed.json'
        seed_path.write_text(json.dumps(seed,ensure_ascii=False,indent=2),encoding='utf-8')
        prepared=dict(prepared);prepared['reuse_seed']=str(seed_path)
        d['legacy_import_reuse_seed']=str(seed_path)
        d['reused_evidence']=sorted(set((d.get('reused_evidence') or [])+(rec.get('authorized_nodes') or [])))
        self.store.write(d['run_id'],d)
        return prepared

    def _change_asset_blockers(self,d:dict)->list[str]:
        if not d.get('parent_run_id'):
            return []
        inputs=d.get('engine_inputs') or {};vs=inputs.get('verifier_spec') if isinstance(inputs.get('verifier_spec'),dict) else {}
        dsl=vs.get('player_dsl') if isinstance(vs.get('player_dsl'),dict) else {}
        known={str(x.get('name')) for x in dsl.get('cards',[]) or [] if isinstance(x,dict)}
        cfg=inputs.get('current_config') if isinstance(inputs.get('current_config'),dict) else {}
        cfg_main={str(x.get('name')):x for x in cfg.get('main',[]) or [] if isinstance(x,dict)}
        parent=self.store.read(d['parent_run_id']);pinputs=parent.get('engine_inputs') or {};pcfg=pinputs.get('current_config') if isinstance(pinputs.get('current_config'),dict) else {}
        old_main={str(x.get('name')) for x in pcfg.get('main',[]) or [] if isinstance(x,dict)}
        blockers=[]
        for ch in d.get('change_set') or []:
            if int(ch.get('delta',0))<=0:
                continue
            card=str(ch.get('card',''))
            if card not in known:
                blockers.append(f'UPDATED_PLAYER_DSL_REQUIRED:{card}')
            if ch.get('zone')=='main' and card not in old_main:
                row=cfg_main.get(card)
                if not isinstance(row,dict) or 'roles' not in row:
                    blockers.append(f'UPDATED_CURRENT_CONFIG_REQUIRED:{card}')
        return sorted(set(blockers))


    def build_missing_evidence_assets(self,run_id:str)->dict:
        d=self.store.read(run_id)
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        if not (hr.get('activated') and hr.get('status')=='VERIFIED_EXACT'):
            d['status']='BLOCKED';d['blockers']=['HISTORICAL_RUNTIME_REQUIRED_BEFORE_ASSET_BUILD'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        built=self.obligation_builder.build(d)
        d['replay_asset_builder_summary']={k:v for k,v in built.items() if k not in {'matrix_path'}}
        if not built.get('certifiable'):
            d['status']='BLOCKED';d['blockers']=['REPLAY_ASSET_BUILD_INCOMPLETE']+list(built.get('blockers') or []);d['current_stage']='EVIDENCE_REPLAY';d['next_stage']='EVIDENCE_REPLAY';d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        try:
            rec=self.replay_resolver.inspect_replay_asset_archive(d,built['archive_path'])
        except Exception as e:
            d['status']='BLOCKED';d['blockers']=[f'BUILT_REPLAY_ASSET_REJECTED:{e}'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        d['replay_assets']=rec
        if not (rec.get('coverage_identity_validation') or {}).get('ok'):
            d['status']='BLOCKED';d['blockers']=['BUILT_REPLAY_ASSET_VALIDATION_FAILED'];d['final_label']='未確定（ブロッカーあり）'
        else:
            d['status']='IN_PROGRESS';d['blockers']=[];d['current_stage']='EVIDENCE_REPLAY';d['next_stage']='EVIDENCE_REPLAY';d['final_label']='検証中'
        d['historical_replay_summary']=replay_summary(d);self.store.write(run_id,d);return self._summary(d)

    def attach_replay_assets(self,run_id:str,replay_asset_file:dict)->dict:
        d=self.store.read(run_id)
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        if not (hr.get('activated') and hr.get('status')=='VERIFIED_EXACT'):
            d['status']='BLOCKED';d['blockers']=['HISTORICAL_RUNTIME_REQUIRED_BEFORE_REPLAY_ASSETS'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        try:
            path=self.evidence_capsules.download_file(replay_asset_file)
            rec=self.replay_resolver.inspect_replay_asset_archive(d,path)
        except Exception as e:
            d['status']='BLOCKED';d['blockers']=[f'REPLAY_ASSET_REJECTED:{e}'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        d['replay_assets']=rec;d['historical_replay_summary']=replay_summary(d);d['status']='IN_PROGRESS';d['blockers']=[];d['current_stage']='EVIDENCE_REPLAY';d['next_stage']='EVIDENCE_REPLAY';d['final_label']='検証中';self.store.write(run_id,d);return self._summary(d)

    def execute_missing_evidence(self,run_id:str,work_budget:str='standard',max_obligations:int=1)->dict:
        d=self.store.read(run_id);hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        runtime_root=hr.get('runtime_root') if hr.get('activated') and hr.get('status')=='VERIFIED_EXACT' else None
        if not runtime_root:
            d['status']='BLOCKED';d['blockers']=['HISTORICAL_RUNTIME_REQUIRED_BEFORE_EVIDENCE_REPLAY'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        actions=unresolved_actions(d)
        if not actions:
            d['historical_replay_summary']=replay_summary(d);d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['status']='IN_PROGRESS';d['blockers']=[];self.store.write(run_id,d);return self._summary(d)
        timeout=self._timeout(work_budget);limit=max(1,min(int(max_obligations),4));executed=[]
        for action in actions[:limit]:
            if action.get('node')=='FULL_REGRESSION':
                assets=d.get('replay_assets') if isinstance(d.get('replay_assets'),dict) else None
                if not assets:
                    row={'certified':False,'status':'REPLAY_ASSET_REQUIRED','node':'FULL_REGRESSION','target':action.get('target'),'count':action.get('count')}
                else:
                    row=self.replay_resolver.execute_regression_group(d,action,assets,runtime_root,timeout)
            elif action.get('node')=='TOURNAMENT_FINAL':
                wd=self._workspace(run_id)/'bridge6-replay'/hashlib.sha256(str(action.get('target')).encode()).hexdigest()[:12]
                row=self.replay_resolver.execute_matchup(d,action,runtime_root,wd,timeout)
            else:
                row={'certified':False,'status':'UNSUPPORTED_REPLAY_NODE','node':action.get('node'),'target':action.get('target')}
            d['historical_replay']=merge_replay_result(d,row);executed.append(row)
            # A timeout or missing required assets should stop this chunk rather than spin.
            if not row.get('certified'):
                break
        d['historical_replay_summary']=replay_summary(d)
        remaining=unresolved_actions(d)
        if remaining:
            blockers=[]
            last=executed[-1] if executed else {}
            if last.get('status') in {'REPLAY_ASSET_REQUIRED','VERIFIER_ASSETS_REQUIRED','MATCHUP_NOT_IN_SUITE_MANIFEST','REPLACEMENT_TEST_MISSING','REPLACEMENT_TEST_HASH_MISMATCH'}:
                blockers=[str(last.get('status')) + (':' + str(last.get('target')) if last.get('target') else '')]
            d['status']='BLOCKED' if blockers else 'IN_PROGRESS';d['blockers']=blockers;d['current_stage']='EVIDENCE_REPLAY';d['next_stage']='EVIDENCE_REPLAY';d['final_label']='未確定（ブロッカーあり）' if blockers else '検証中'
        else:
            d['status']='IN_PROGRESS';d['blockers']=[];d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['final_label']='検証中'
        self.store.write(run_id,d);return self._summary(d)


    def build_tournament_final_suite(self,run_id:str)->dict:
        d=self.store.read(run_id)
        hr=d.get('historical_runtime') if isinstance(d.get('historical_runtime'),dict) else {}
        if not (hr.get('activated') and hr.get('status')=='VERIFIED_EXACT'):
            d['status']='BLOCKED';d['blockers']=['HISTORICAL_RUNTIME_REQUIRED_BEFORE_TOURNAMENT_SUITE'];d['final_label']='未確定（ブロッカーあり）';self.store.write(run_id,d);return self._summary(d)
        cert=cross_attest_tournament_final(d)
        d=apply_cross_attestation(d,cert)
        d['tournament_final_recertification_summary']={k:v for k,v in cert.items() if k not in {'matchups','base_checks'}}
        remaining=[str(a.get('target')) for a in unresolved_actions(d) if a.get('node')=='TOURNAMENT_FINAL']
        built=build_executable_suite(d,remaining) if remaining else {'status':'NOT_NEEDED','missing_matchups':[],'sources':{},'suite_manifest':None,'blockers':[]}
        d['tournament_suite_builder_summary']={k:v for k,v in built.items() if k!='suite_manifest'}
        if built.get('suite_manifest'):
            ei=copy.deepcopy(d.get('engine_inputs') or {});vs=ei.get('verifier_spec') if isinstance(ei.get('verifier_spec'),dict) else {};vs=copy.deepcopy(vs);vs['suite_manifest']=built['suite_manifest'];ei['verifier_spec']=vs;d['engine_inputs']=ei
        remaining=[a for a in unresolved_actions(d) if a.get('node')=='TOURNAMENT_FINAL']
        if remaining:
            blockers=list(built.get('blockers') or [])
            d['status']='BLOCKED' if blockers else 'IN_PROGRESS';d['blockers']=blockers;d['current_stage']='EVIDENCE_REPLAY';d['next_stage']='EVIDENCE_REPLAY';d['final_label']='未確定（ブロッカーあり）' if blockers else '検証中'
        else:
            d['status']='IN_PROGRESS';d['blockers']=[];d['current_stage']='FINAL_GATE_RECERTIFICATION';d['next_stage']='FINAL_GATE_RECERTIFICATION';d['final_label']='検証中'
        d['historical_replay_summary']=replay_summary(d);self.store.write(run_id,d);return self._summary(d)

    def recertify_final_gate(self,run_id:str)->dict:
        d=self.store.read(run_id)
        # Refresh cross-attestation after any replayed matchup or runtime/evidence change.
        cert=cross_attest_tournament_final(d)
        d=apply_cross_attestation(d,cert)
        d['tournament_final_recertification_summary']={k:v for k,v in cert.items() if k not in {'matchups','base_checks'}}
        gate=recertify_final_gate(d);d['final_gate']=gate
        if gate.get('ok'):
            d['status']=FINAL_CONFIRMED;d['current_stage']='FINAL_GATE';d['next_stage']=None;d['final_label']='大会用最終確定';d['blockers']=[]
            d['completed_stages']=sorted(set(d.get('completed_stages',[])+['v20.18_final_gate_recertified']))
        else:
            d['status']='BLOCKED';d['current_stage']='FINAL_GATE_RECERTIFICATION';d['next_stage']='FINAL_GATE_RECERTIFICATION';d['blockers']=['FINAL_GATE_NOT_ELIGIBLE:'+x for x in gate.get('blockers',[])];d['final_label']='未確定（ブロッカーあり）'
        d['historical_replay_summary']=replay_summary(d);self.store.write(run_id,d);return self._summary(d)

    def attach_assets(self,run_id:str,engine_inputs:dict,replace:bool=False)->dict:
        d=self.store.read(run_id);safe,secrets=self._extract_secrets(engine_inputs)
        if replace:d['engine_inputs']=safe
        else:
            cur=copy.deepcopy(d.get('engine_inputs') or {})
            for k,v in safe.items():
                if isinstance(cur.get(k),dict) and isinstance(v,dict):cur[k].update(v)
                else:cur[k]=v
            d['engine_inputs']=cur
        if secrets:
            old=self.store.read_secret(run_id);old.update(secrets);self.store.write_secret(run_id,old)
        if d.get('parent_run_id'):
            # Recompute exact invalidation after replacement DSL/config assets arrive.
            self._compute_incremental_plan(d)
        if d.get('legacy_import'):
            self._reconcile_legacy_import(d)
        change_blockers=self._change_asset_blockers(d)
        if change_blockers:
            d['status']='BLOCKED';d['current_stage']='ASSET_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['blockers']=change_blockers;d['final_label']='未確定（ブロッカーあり）'
        elif d.get('status')=='BLOCKED' and any(str(x).startswith(('MISSING_ENGINE_ASSET','UPDATED_PLAYER_DSL_REQUIRED','UPDATED_CURRENT_CONFIG_REQUIRED')) for x in d.get('blockers',[])):
            d['status']='IN_PROGRESS';d['blockers']=[];d['final_label']='検証中';d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT'
        self.store.write(run_id,d);return self._summary(d)

    def status(self, run_id:str) -> dict: return self._summary(self.store.read(run_id))
    def find(self, query:str, limit:int=10) -> list[dict]: return [self._summary(x) for x in self.store.find(query,limit)]

    def _workspace(self,run_id:str)->Path:
        p=self.work_root/run_id;p.mkdir(parents=True,exist_ok=True);return p

    @staticmethod
    def _timeout(work_budget:str)->int:
        return {'small':15,'standard':45,'deep':90}.get(work_budget,45)

    def _apply_engine_result(self,d:dict,packet:dict)->dict:
        result=packet.get('result');cp=packet.get('checkpoint');execution=packet.get('execution') or {}
        d['last_engine_execution']={k:v for k,v in execution.items() if k not in {'stdout_tail','stderr_tail'}}
        if cp:
            d['legacy_checkpoint_stage']=cp.get('stage')
            d['checkpoint_id']=self._hash(cp)[:24]
        if execution.get('timed_out'):
            d['status']='IN_PROGRESS';d['current_stage']='ENGINE_EXECUTION';d['next_stage']='ENGINE_EXECUTION';d['final_label']='検証中';d['blockers']=[]
            self.store.write(d['run_id'],d);return self._summary(d)
        if not isinstance(result,dict):
            d['status']='HARD_BLOCKER';d['current_stage']='ENGINE_EXECUTION';d['next_stage']=None;d['blockers']=['LEGACY_ENGINE_NO_RESULT'];d['final_label']='未確定（裁定/実装/証拠のhard blocker）'
            d['engine_diagnostics']={'stdout_tail':execution.get('stdout_tail',''),'stderr_tail':execution.get('stderr_tail','')}
            self.store.write(d['run_id'],d);return self._summary(d)
        d['engine_result']=result
        if result.get('input_fingerprint'):d['fingerprints']['legacy_input']=str(result['input_fingerprint'])
        if result.get('deck_freeze_candidate_fingerprint'):d['fingerprints']['deck_freeze']=str(result['deck_freeze_candidate_fingerprint'])
        elif result.get('deck_fingerprint'):d['fingerprints']['deck_freeze']=str(result['deck_fingerprint'])
        self._refresh_evidence_context(d)
        stages=result.get('stages') or {};d['completed_stages']=sorted(k for k,v in stages.items() if str(v).startswith('PASS'))
        engine_reuse=list((result.get('resume') or {}).get('reused_stages') or [])
        d['reused_evidence']=sorted(set((d.get('reused_evidence') or [])+engine_reuse))
        gate=result.get('final_gate') or {'ok':False,'status':'NOT_RUN'};d['final_gate']=gate
        blockers=list(gate.get('blockers') or [])
        if result.get('status')==FINAL_CONFIRMED and gate.get('ok'):
            d['status']=FINAL_CONFIRMED;d['current_stage']='FINAL_GATE';d['next_stage']=None;d['blockers']=[];d['final_label']='大会用最終確定'
        else:
            d['status']='BLOCKED' if blockers or 'BLOCKED' in str(result.get('status','')) or 'REQUIRED' in str(result.get('status','')) else 'IN_PROGRESS'
            d['current_stage']=d.get('legacy_checkpoint_stage') or 'ENGINE_EXECUTION';d['next_stage']=None if d['status']=='BLOCKED' else 'ENGINE_EXECUTION';d['blockers']=blockers or [str(result.get('status','ENGINE_NOT_FINAL'))];d['final_label']='未確定（ブロッカーあり）' if d['status']=='BLOCKED' else '検証中'
        self.store.write(d['run_id'],d);return self._summary(d)

    def _refresh_evidence_context(self,d:dict)->None:
        engine_fp=(d.get('fingerprints') or {}).get('legacy_engine_bundle')
        if not engine_fp:
            return
        bridge=self._bridge_for_run(d)
        ctx=build_context(d,legacy_root=bridge.root,engine_bundle_fingerprint=engine_fp)
        d['evidence_context_snapshot']=ctx
        d.setdefault('fingerprints',{})['evidence_context']=self._hash(ctx)

    def _compute_incremental_plan(self, d: dict) -> dict | None:
        parent_id=d.get('parent_run_id')
        if not parent_id:
            return None
        parent=self.store.read(parent_id)
        parent_engine_fp=(parent.get('fingerprints') or {}).get('legacy_engine_bundle') or ''
        child_bridge=self._bridge_for_run(d)
        child_engine_fp=(d.get('fingerprints') or {}).get('legacy_engine_bundle') or child_bridge.bundle_fingerprint()
        plan=plan_reuse(parent,d,legacy_root=child_bridge.root,parent_engine_bundle_fingerprint=parent_engine_fp,child_engine_bundle_fingerprint=child_engine_fp)
        d['incremental_plan']=plan
        er=plan.get('effect_reuse') or {}
        d['incremental_plan_summary']={
            'parent_run_id':parent_id,
            'no_op':bool(plan.get('no_op')),
            'changed_components':plan.get('changed_components') or [],
            'reusable_nodes':plan.get('reusable_nodes') or [],
            'invalidated_nodes':plan.get('invalidated_nodes') or [],
            'effect_reuse':{k:er.get(k,0) for k in ('parent_effects','child_effects','reused_exact','changed','added','removed')},
        }
        d['reused_evidence']=list(plan.get('reusable_nodes') or [])
        d['invalidated_evidence']=list(plan.get('invalidated_nodes') or [])
        d.setdefault('fingerprints',{})['parent_evidence_context']=str(plan.get('parent_context_fingerprint',''))
        d['fingerprints']['evidence_context']=str(plan.get('child_context_fingerprint',''))
        return plan

    def _copy_content_addressed_caches(self,parent_run_id:str,child_run_id:str)->list[str]:
        src=self._workspace(parent_run_id);dst=self._workspace(child_run_id);copied=[]
        # Only content-addressed caches are inherited. Checkpoints are never copied wholesale.
        for name in ('cache','native-cache'):
            a=src/name;b=dst/name
            if not a.exists():
                continue
            b.mkdir(parents=True,exist_ok=True)
            shutil.copytree(a,b,dirs_exist_ok=True)
            copied.append(name)
        return copied

    def _prepare_parent_reuse(self,d:dict,prepared:dict,workspace:Path)->dict:
        parent_id=d.get('parent_run_id')
        if not parent_id:
            return prepared
        plan=self._compute_incremental_plan(d)
        parent=self.store.read(parent_id)
        copied=self._copy_content_addressed_caches(parent_id,d['run_id'])
        seed=seed_evidence_from_parent(parent,plan or {})
        seed_path=workspace/'parent-evidence-seed.json'
        seed_path.write_text(json.dumps(seed,ensure_ascii=False,indent=2),encoding='utf-8')
        prepared=dict(prepared);prepared['reuse_seed']=str(seed_path)
        d['parent_cache_reuse']=copied
        self.store.write(d['run_id'],d)
        return prepared

    def advance(self, run_id:str, work_budget:str='standard', stop_after:str|None=None) -> dict:
        d=self.store.read(run_id);stage=d.get('current_stage','CREATED');workspace=self._workspace(run_id)
        if d.get('status')==FINAL_CONFIRMED:return self._summary(d)
        if stage=='CREATED':
            bridge=self._bridge_for_run(d)
            health=bridge.health_check(timeout=min(30,self._timeout(work_budget)))
            d['engine_health']=health;d['fingerprints']['legacy_engine_bundle']=health.get('bundle_fingerprint','')
            self._refresh_evidence_context(d)
            if d.get('legacy_import'):
                self._reconcile_legacy_import(d)
            if not health.get('ok'):
                d['status']='HARD_BLOCKER';d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']=None;d['blockers']=['LEGACY_ENGINE_SELF_TEST_FAILED'];d['final_label']='未確定（裁定/実装/証拠のhard blocker）'
            else:
                d['current_stage']='ENGINE_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['completed_stages']=sorted(set(d.get('completed_stages',[])+['engine_preflight']));d['blockers']=[]
            self.store.write(run_id,d);return self._summary(d)
        if stage=='ENGINE_PREFLIGHT':
            bridge=self._bridge_for_run(d)
            inputs=d.get('engine_inputs') or {};secret=self.store.read_secret(run_id)
            prepared=bridge.prepare_zero_base(workspace,inputs,secret) if d['mode']=='zero_base' else bridge.prepare_revalidate(workspace,inputs,secret)
            if not prepared.get('ok'):
                d['status']='BLOCKED';d['current_stage']='ASSET_PREFLIGHT';d['next_stage']='ASSET_PREFLIGHT';d['blockers']=[f'MISSING_ENGINE_ASSET:{x}' for x in prepared.get('missing',[])];d['final_label']='未確定（ブロッカーあり）'
            else:
                prepared=self._prepare_legacy_reuse(d,prepared,workspace)
                prepared=self._prepare_parent_reuse(d,prepared,workspace)
                d['prepared_engine_inputs']=prepared;d['current_stage']='ASSETS_READY';d['next_stage']='ENGINE_EXECUTION';d['status']='IN_PROGRESS';d['blockers']=[];d['completed_stages']=sorted(set(d.get('completed_stages',[])+['asset_preflight']))
            self.store.write(run_id,d);return self._summary(d)
        if stage=='ASSET_PREFLIGHT':
            # Assets may have been attached after a blocked preflight.
            d['current_stage']='ENGINE_PREFLIGHT';self.store.write(run_id,d);return self.advance(run_id,work_budget,stop_after)
        if stage in {'ASSETS_READY','ENGINE_EXECUTION'}:
            bridge=self._bridge_for_run(d)
            prepared=d.get('prepared_engine_inputs') or {};timeout=self._timeout(work_budget)
            cache=workspace/'cache';cp=workspace/'checkpoints';out=workspace/'output'
            packet=bridge.run_zero_base(workspace,prepared,cache,cp,out,timeout) if d['mode']=='zero_base' else bridge.run_revalidate(workspace,prepared,cache,cp,out,timeout)
            return self._apply_engine_result(d,packet)
        d['status']='HARD_BLOCKER';d['blockers']=[f'UNKNOWN_STATE:{stage}'];d['final_label']='未確定（裁定/実装/証拠のhard blocker）';d['next_stage']=None;self.store.write(run_id,d);return self._summary(d)

    @staticmethod
    def _apply_changes_to_zone(rows:list[dict],changes:list[dict],zone:str)->list[dict]:
        # Preserve config metadata (roles, tags, etc.) for unchanged/existing cards.
        m={}
        for x in rows or []:
            if not isinstance(x,dict):
                continue
            name=str(x.get('name','')).strip()
            if not name:
                continue
            m[name]=copy.deepcopy(x);m[name]['name']=name;m[name]['count']=int(x.get('count',0))
        for ch in changes:
            if ch.get('zone')!=zone:continue
            name=str(ch.get('card','')).strip();delta=int(ch.get('delta',0))
            if not name:raise ValueError('change card name is required')
            row=m.get(name,{'name':name,'count':0})
            row['count']=int(row.get('count',0))+delta
            if row['count']<0:raise ValueError(f'negative card count for {name}')
            if row['count']==0:m.pop(name,None)
            else:m[name]=row
        return [m[k] for k in sorted(m)]

    def verify_change(self, run_id:str, changes:list[dict], reason:str|None=None) -> dict:
        parent=self.store.read(run_id);newdeck=copy.deepcopy(parent['deck'])
        newdeck['main']=self._apply_changes_to_zone(newdeck.get('main',[]),changes,'main');newdeck['extra']=self._apply_changes_to_zone(newdeck.get('extra',[]),changes,'extra')
        child_inputs=copy.deepcopy(parent.get('engine_inputs') or {})
        cfg=child_inputs.get('current_config')
        if isinstance(cfg,dict):
            for zone in ('main','extra'):
                if isinstance(cfg.get(zone),list):cfg[zone]=self._apply_changes_to_zone(cfg[zone],changes,zone)
        payload={k:v for k,v in parent.items() if k not in {'run_id','created_at','updated_at','completed_stages','reused_evidence','invalidated_evidence','blockers','final_gate','status','current_stage','next_stage','final_label','engine_result','prepared_engine_inputs','last_engine_execution','checkpoint_id','legacy_checkpoint_stage','incremental_plan','incremental_plan_summary','parent_cache_reuse','legacy_import','legacy_import_summary','legacy_reconciliation','legacy_reconciliation_summary','legacy_import_reuse_seed'}}
        payload.update({'mode':'revalidate_current','deck':newdeck,'engine_inputs':child_inputs,'parent_run_id':run_id,'change_set':changes,'change_reason':reason})
        child=self.store.create(payload);parent_secret=self.store.read_secret(run_id)
        if parent_secret:self.store.write_secret(child['run_id'],parent_secret)
        phr=parent.get('historical_runtime') if isinstance(parent.get('historical_runtime'),dict) else {}
        if phr.get('activated') and phr.get('status')=='VERIFIED_EXACT':
            inherited_engine_fp=(parent.get('fingerprints') or {}).get('legacy_engine_bundle') or self._bridge_for_run(parent).bundle_fingerprint()
        else:
            # A naked historical fingerprint is provenance, not an executable child runtime.
            # Without a restored exact runtime, the child executes on the packaged current bridge.
            inherited_engine_fp=self.bridge.bundle_fingerprint()
        child['fingerprints']={'deck':self._hash(newdeck),'ruleset':self._hash(child.get('ruleset') or {}),'parent_deck':parent.get('fingerprints',{}).get('deck',''),'legacy_engine_bundle':inherited_engine_fp}
        blockers=self._change_asset_blockers(child)
        if blockers:
            child['status']='BLOCKED';child['current_stage']='ASSET_PREFLIGHT';child['next_stage']='ASSET_PREFLIGHT';child['blockers']=blockers;child['final_label']='未確定（ブロッカーあり）'
        self._compute_incremental_plan(child)
        self.store.write(child['run_id'],child);return self._summary(child)

    def submit_reality_log(self, run_id:str, matches:list[dict], provenance:dict|None=None) -> dict:
        d=self.store.read(run_id);logs=list(d.get('reality_logs') or []);logs.append({'matches':matches,'provenance':provenance or {}});d['reality_logs']=logs
        for name in ('REALITY_CALIBRATION','SEALED_HOLDOUT','FINAL_CI','FINAL_GATE'):
            if name not in d['invalidated_evidence']: d['invalidated_evidence'].append(name)
        d['status']='IN_PROGRESS';d['final_label']='検証中';d['next_stage']='REALITY_CALIBRATION';self.store.write(run_id,d);return self._summary(d)

    @classmethod
    def _sanitize(cls,value:Any)->Any:
        if isinstance(value,dict):return {k:cls._sanitize(v) for k,v in value.items() if k.lower() not in {'holdout_secret','credentials','tokens','token','secret','password'}}
        if isinstance(value,list):return [cls._sanitize(x) for x in value]
        return value

    def report(self, run_id:str, detail:str='summary') -> dict:
        d=self.store.read(run_id)
        if detail=='summary': return self._summary(d)
        if detail not in {'full','notion_payload'}: raise ValueError('invalid detail')
        clean=self._sanitize(d)
        if detail=='notion_payload':
            return {'run_id':d['run_id'],'final_label':d['final_label'],'ruleset':d.get('ruleset'),'deck':d.get('deck'),'final_gate':d.get('final_gate'),'completed_stages':d.get('completed_stages'),'engine_result':self._sanitize(d.get('engine_result',{}))}
        return clean

    def export_checkpoint(self, run_id:str) -> dict: return self._sanitize(self.store.read(run_id))
