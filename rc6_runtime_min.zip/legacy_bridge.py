from __future__ import annotations
import copy, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
from typing import Any

class LegacyBridgeError(RuntimeError):
    pass

class LegacyV20171Bridge:
    """Narrow process boundary around the unmodified v20.17.1 package.

    The legacy engine remains authoritative for DSL/native/simulation/regression semantics.
    v20.18 only materializes inputs, invokes supported CLI/coordinator entrypoints, and maps
    checkpoint/result state into the MCP run state.
    """
    def __init__(self, legacy_root: str | Path | None = None):
        self.root = Path(legacy_root or os.environ.get('VTD_ENGINE_ROOT') or (Path(__file__).resolve().parent / 'vendor' / 'v20_17_1')).resolve()
        self.cli = self.root / 'scripts' / 'research_engine.py'
        if not self.cli.is_file():
            raise LegacyBridgeError(f'v20.17.1 CLI not found: {self.cli}')

    @staticmethod
    def _json_hash(value: Any) -> str:
        raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
        return hashlib.sha256(raw).hexdigest()

    def bundle_fingerprint(self) -> str:
        # Bind the bridge to the executable semantic surface, not runtime/cache/checkpoint data.
        rows=[]
        for rel_root in ('engine','scripts','references'):
            base=self.root/rel_root
            if not base.exists(): continue
            for p in sorted(x for x in base.rglob('*') if x.is_file() and x.suffix in {'.py','.json','.md','.yaml','.yml'}):
                data=p.read_bytes()
                rows.append([str(p.relative_to(self.root)),hashlib.sha256(data).hexdigest(),len(data)])
        return self._json_hash(rows)

    def _run(self, args: list[str], *, timeout: int = 30, env: dict[str,str] | None = None) -> dict:
        cmd=[sys.executable, str(self.cli), *args]
        e=os.environ.copy(); e['PYTHONPATH']=str(self.root)+(os.pathsep+e['PYTHONPATH'] if e.get('PYTHONPATH') else '')
        if env: e.update(env)
        started=time.monotonic()
        proc=subprocess.Popen(cmd,cwd=self.root,env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=(os.name!='nt'))
        try:
            stdout,stderr=proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name!='nt':
                try: os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError: pass
            else:
                proc.terminate()
            try: stdout,stderr=proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                if os.name!='nt':
                    try: os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                else: proc.kill()
                stdout,stderr=proc.communicate()
            return {
                'ok':False,'timed_out':True,'command':cmd,'timeout_seconds':timeout,
                'elapsed_seconds':round(time.monotonic()-started,3),
                'stdout_tail':(stdout or '')[-12000:],
                'stderr_tail':(stderr or '')[-12000:],
            }
        stdout=stdout or ''; stderr=stderr or ''
        parsed=None
        if stdout.strip():
            try: parsed=json.loads(stdout)
            except Exception: parsed=None
        return {
            'ok':proc.returncode==0,
            'returncode':proc.returncode,
            'command':cmd,
            'elapsed_seconds':round(time.monotonic()-started,3),
            'stdout_tail':stdout[-12000:],
            'stderr_tail':stderr[-12000:],
            'json':parsed,
        }

    def health_check(self, timeout: int = 30) -> dict:
        out=self._run(['self-test'],timeout=timeout)
        payload=out.get('json') if isinstance(out.get('json'),dict) else {}
        return {
            'ok':bool(out.get('ok') and payload.get('ok')),
            'engine_version':payload.get('engine_version'),
            'checks':payload.get('checks',{}),
            'bundle_fingerprint':self.bundle_fingerprint(),
            'execution':{k:v for k,v in out.items() if k!='json'},
        }

    @staticmethod
    def _dump(path: Path, value: Any) -> str:
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
        return str(path)

    def materialize_verifier_spec(self, workspace: Path, verifier_spec: dict, secret_payload: dict | None=None) -> Path:
        spec=copy.deepcopy(verifier_spec or {})
        secret_payload=secret_payload or {}
        # These legacy functions require file paths, not inline dicts.
        path_keys=('golden_manifest','source_lock','engine_certificate','holdout_commit')
        for key in path_keys:
            if isinstance(spec.get(key),(dict,list)):
                spec[key]=self._dump(workspace/f'{key}.json',spec[key])
        if secret_payload.get('holdout_secret') is not None:
            spec['holdout_secret']=self._dump(workspace/'holdout_secret.json',secret_payload['holdout_secret'])
        elif isinstance(spec.get('holdout_secret'),(dict,list)):
            spec['holdout_secret']=self._dump(workspace/'holdout_secret.json',spec['holdout_secret'])
        if spec.get('holdout_commit') and not spec.get('holdout_marker'):
            spec['holdout_marker']=str(workspace/'sealed-holdout.used.json')
        # Keep cache inside the run workspace unless the caller intentionally supplied one.
        spec.setdefault('native_cache_dir',str(workspace/'native-cache'))
        return Path(self._dump(workspace/'verifier-spec.json',spec))

    def prepare_zero_base(self, workspace: Path, engine_inputs: dict, secret_payload: dict | None=None) -> dict:
        workspace.mkdir(parents=True,exist_ok=True)
        required=('base_config','candidate_pool','verifier_spec')
        missing=[k for k in required if not isinstance(engine_inputs.get(k),dict)]
        if missing: return {'ok':False,'missing':missing}
        vs=engine_inputs['verifier_spec']
        verifier_missing=[k for k in ('player_dsl','suite_manifest') if not isinstance(vs.get(k),dict)]
        if verifier_missing: return {'ok':False,'missing':[f'verifier_spec.{x}' for x in verifier_missing]}
        base=self._dump(workspace/'base.json',engine_inputs['base_config'])
        pool=self._dump(workspace/'candidate-pool.json',engine_inputs['candidate_pool'])
        bspec=self._dump(workspace/'builder-spec.json',engine_inputs.get('builder_spec') or {})
        vs_path=str(self.materialize_verifier_spec(workspace,vs,secret_payload))
        return {'ok':True,'base':base,'pool':pool,'builder_spec':bspec,'verifier_spec':vs_path,'seed':int(engine_inputs.get('seed',20260920))}

    def run_zero_base(self, workspace: Path, prepared: dict, cache_dir: Path, checkpoint_dir: Path, outdir: Path, timeout: int) -> dict:
        out_path=outdir/'auto-complete-result.json'; outdir.mkdir(parents=True,exist_ok=True); checkpoint_dir.mkdir(parents=True,exist_ok=True); cache_dir.mkdir(parents=True,exist_ok=True)
        args=['optimize-and-verify',prepared['base'],prepared['pool'],'--spec',prepared['builder_spec'],'--verifier-spec',prepared['verifier_spec'],
              '--seed',str(prepared['seed']),'--checkpoint-dir',str(checkpoint_dir),'--cache-dir',str(cache_dir),'--outdir',str(outdir),'--out',str(out_path)]
        exec_result=self._run(args,timeout=timeout)
        result=None
        if out_path.exists():
            try: result=json.loads(out_path.read_text(encoding='utf-8'))
            except Exception: result=None
        cp_path=checkpoint_dir/'auto-complete-checkpoint.json'; cp=None
        if cp_path.exists():
            try: cp=json.loads(cp_path.read_text(encoding='utf-8'))
            except Exception: cp=None
        return {'execution':exec_result,'result':result,'checkpoint':cp,'out_path':str(out_path),'checkpoint_path':str(cp_path)}

    def prepare_revalidate(self, workspace: Path, engine_inputs: dict, secret_payload: dict | None=None) -> dict:
        workspace.mkdir(parents=True,exist_ok=True)
        required=('current_config','verifier_spec')
        missing=[k for k in required if not isinstance(engine_inputs.get(k),dict)]
        if missing:return {'ok':False,'missing':missing}
        vs=engine_inputs['verifier_spec']
        verifier_missing=[k for k in ('player_dsl','suite_manifest') if not isinstance(vs.get(k),dict)]
        if verifier_missing:return {'ok':False,'missing':[f'verifier_spec.{x}' for x in verifier_missing]}
        cfg=self._dump(workspace/'current-config.json',engine_inputs['current_config'])
        vs_path=str(self.materialize_verifier_spec(workspace,vs,secret_payload))
        return {'ok':True,'current_config':cfg,'verifier_spec':vs_path,'seed':int(engine_inputs.get('seed',20260920))}

    def run_revalidate(self, workspace: Path, prepared: dict, cache_dir: Path, checkpoint_dir: Path, outdir: Path, timeout: int) -> dict:
        helper=Path(__file__).resolve().parent/'v20171_revalidate.py'
        out_path=outdir/'revalidate-result.json'; outdir.mkdir(parents=True,exist_ok=True);checkpoint_dir.mkdir(parents=True,exist_ok=True);cache_dir.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,str(helper),'--legacy-root',str(self.root),'--config',prepared['current_config'],'--verifier-spec',prepared['verifier_spec'],
             '--seed',str(prepared['seed']),'--checkpoint-dir',str(checkpoint_dir),'--cache-dir',str(cache_dir),'--out',str(out_path)]
        if prepared.get('reuse_seed'):
            cmd.extend(['--reuse-seed',str(prepared['reuse_seed'])])
        env=os.environ.copy(); env['PYTHONPATH']=str(self.root)+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
        started=time.monotonic()
        proc=subprocess.Popen(cmd,cwd=self.root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=(os.name!='nt'))
        try:
            stdout,stderr=proc.communicate(timeout=timeout)
            exec_result={'ok':proc.returncode==0,'returncode':proc.returncode,'command':cmd,'elapsed_seconds':round(time.monotonic()-started,3),'stdout_tail':(stdout or '')[-12000:],'stderr_tail':(stderr or '')[-12000:]}
        except subprocess.TimeoutExpired:
            if os.name!='nt':
                try: os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError: pass
            else: proc.terminate()
            try: stdout,stderr=proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                if os.name!='nt':
                    try: os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                else: proc.kill()
                stdout,stderr=proc.communicate()
            exec_result={'ok':False,'timed_out':True,'command':cmd,'timeout_seconds':timeout,'elapsed_seconds':round(time.monotonic()-started,3),'stdout_tail':(stdout or '')[-12000:],'stderr_tail':(stderr or '')[-12000:]}
        result=None
        if out_path.exists():
            try:result=json.loads(out_path.read_text(encoding='utf-8'))
            except Exception:pass
        cp_path=checkpoint_dir/'revalidate-checkpoint.json';cp=None
        if cp_path.exists():
            try:cp=json.loads(cp_path.read_text(encoding='utf-8'))
            except Exception:pass
        return {'execution':exec_result,'result':result,'checkpoint':cp,'out_path':str(out_path),'checkpoint_path':str(cp_path)}
