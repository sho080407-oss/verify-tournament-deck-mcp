from __future__ import annotations
import os

# Render exposes the public hostname automatically. Derive the canonical MCP URL
# before importing the RC6 production app, because RC6 auth binds tokens to it.
host = (os.environ.get("RENDER_EXTERNAL_HOSTNAME") or "").strip()
if host and not os.environ.get("VTD_PUBLIC_MCP_URL"):
    os.environ["VTD_PUBLIC_MCP_URL"] = f"https://{host}/mcp"

from production_server import app as rc6_app
from public_site import wrap_app

app = wrap_app(rc6_app)
