from __future__ import annotations
import os
from pathlib import Path
from mcp.server.auth.middleware.auth_context import get_access_token
from engine_adapter import EngineAdapter
from run_store import RunStore
from tenant import Principal, principal_from_token, tenant_root

BASE_DATA=Path(os.environ.get("VTD_DATA_DIR","./runtime/production")).resolve()
BASE_DATA.mkdir(parents=True,exist_ok=True)

def current_principal()->Principal:
    token=get_access_token()
    if token is not None:return principal_from_token(token)
    if os.environ.get("VTD_ENV","development").lower()!="production" and os.environ.get("VTD_AUTH_MODE","disabled").lower()=="disabled":
        return Principal(subject=os.environ.get("VTD_DEV_PRINCIPAL","local-dev"),client_id="local-dev",issuer="local")
    raise PermissionError("authenticated principal required")

def current_tenant_root()->Path:return tenant_root(BASE_DATA,current_principal())
def current_adapter()->EngineAdapter:return EngineAdapter(RunStore(current_tenant_root()/"runs"))
