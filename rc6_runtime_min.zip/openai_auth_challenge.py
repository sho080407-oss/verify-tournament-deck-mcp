from __future__ import annotations
from openai_auth_contract import www_authenticate


class EnsureWWWAuthenticateMiddleware:
    """Add an RFC 9728 discovery challenge to bare 401 responses.

    The MCP SDK normally emits the auth challenge itself. This middleware is a final
    production guard: it never overwrites an existing WWW-Authenticate header.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            return await self.app(scope, receive, send)

        async def wrapped(message):
            if message.get("type") == "http.response.start" and int(message.get("status", 0)) == 401:
                headers = list(message.get("headers") or [])
                if not any(k.lower() == b"www-authenticate" for k, _ in headers):
                    try:
                        challenge = www_authenticate().encode("latin-1")
                        headers.append((b"www-authenticate", challenge))
                        message = dict(message)
                        message["headers"] = headers
                    except Exception:
                        # Never turn an auth failure into a server failure merely because metadata
                        # is misconfigured; deployment readiness catches that separately.
                        pass
            await send(message)

        await self.app(scope, receive, wrapped)
