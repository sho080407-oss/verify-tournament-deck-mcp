from __future__ import annotations
from copy import deepcopy
from typing import Any

OAUTH_SCOPE = "deck:verify"
OAUTH_ONLY_SECURITY_SCHEMES = [{"type": "oauth2", "scopes": [OAUTH_SCOPE]}]

READ_ONLY_TOOLS = {
    "get_profile",
    "find_verification_runs",
    "get_verification_status",
    "get_verification_report",
    "export_checkpoint",
}

# These tools dereference externally supplied HTTPS download URLs and therefore
# interact with open-world resources under the current production policy.
OPEN_WORLD_TOOLS = {
    "attach_historical_runtime_bundle",
    "attach_historical_evidence_capsule",
    "attach_replay_assets",
}

DESTRUCTIVE_TOOLS = {
    "attach_verification_assets",
}

# These mutate verifier state but are designed to be non-destructive: they create runs,
# attach/derive evidence, advance checkpoints, or append logs. The replace-capable
# attach_verification_assets tool is intentionally excluded and classified above.
NON_DESTRUCTIVE_WRITE_TOOLS = {
    "create_verification_run",
    "import_legacy_checkpoint",
    "attach_historical_runtime_bundle",
    "attach_historical_evidence_capsule",
    "build_missing_evidence_assets",
    "attach_replay_assets",
    "execute_missing_evidence",
    "build_tournament_final_suite",
    "recertify_final_gate",
    "recover_interrupted_run",
    "advance_verification",
    "verify_change",
    "submit_reality_log",
}


def _annotations_for(name: str) -> dict[str, Any]:
    read_only = name in READ_ONLY_TOOLS
    return {
        "readOnlyHint": read_only,
        # OpenAI requires destructiveHint=true when a tool can overwrite data in
        # any supported mode. attach_verification_assets(replace=True) replaces
        # the run's current engine_inputs, so the whole tool is classified destructive.
        "destructiveHint": name in DESTRUCTIVE_TOOLS,
        # File-attachment tools dereference an HTTPS download_url supplied through
        # the file parameter. The current server validates SSRF hazards but does not
        # require a bounded production host allowlist, so those calls are open-world.
        "openWorldHint": name in OPEN_WORLD_TOOLS,
        # Read operations are naturally idempotent. Mutating operations may create
        # journals/checkpoints, so don't overclaim idempotence to the client.
        "idempotentHint": read_only,
    }


def _tool_meta(name: str, existing: dict[str, Any] | None = None) -> dict[str, Any]:
    meta = deepcopy(existing or {})
    # OpenAI documents this compatibility mirror for clients that inspect _meta.
    meta["securitySchemes"] = deepcopy(OAUTH_ONLY_SECURITY_SCHEMES)
    # All tools remain model-callable. No UI-only private tools are declared.
    ui = dict(meta.get("ui") or {})
    ui.setdefault("visibility", ["model", "app"])
    meta["ui"] = ui
    if name == "get_profile":
        meta["openai/profile"] = True
    return meta


def decorate_wire_tool(tool: Any) -> Any:
    """Return an MCP Tool with OpenAI auth metadata on both standard and _meta fields.

    The function intentionally works from model_dump(by_alias=True) so it stays compatible
    with the v1.30 Pydantic wire model while also matching the current MCP/OpenAI JSON names.
    It is imported only when the MCP SDK is installed.
    """
    import mcp.types as types

    payload = tool.model_dump(by_alias=True, exclude_none=True)
    name = str(payload.get("name") or getattr(tool, "name", ""))
    existing_meta = payload.get("_meta") or payload.get("meta") or {}
    payload["_meta"] = _tool_meta(name, existing_meta)
    payload["securitySchemes"] = deepcopy(OAUTH_ONLY_SECURITY_SCHEMES)
    # Use actual behavior hints rather than relying on generic defaults.
    payload["annotations"] = _annotations_for(name)
    return types.Tool(**payload)


def install_openai_tool_descriptor_overlay(mcp: Any) -> None:
    """Patch tools/list so ChatGPT sees explicit OAuth schemes and annotations.

    FastMCP v1 exposes a low-level server hook. The high-level `mcp.list_tools()` still
    reads the registered decorator tools; this wrapper only changes their wire descriptor.
    """
    base_list_tools = mcp.list_tools

    @mcp._mcp_server.list_tools()
    async def _list_tools():
        tools = await base_list_tools()
        return [decorate_wire_tool(t) for t in tools]
