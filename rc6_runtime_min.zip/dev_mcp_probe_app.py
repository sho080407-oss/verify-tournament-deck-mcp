"""ASGI entry point for the development-only MCP wire probe."""
from dev_mcp_probe_runtime import install_fake_mcp_modules
install_fake_mcp_modules()
from production_server import app  # noqa: E402,F401
