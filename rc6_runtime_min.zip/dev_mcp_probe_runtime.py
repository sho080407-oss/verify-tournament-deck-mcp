"""Development-only MCP wire probe runtime.

This module is deliberately NOT a production replacement for the official MCP SDK.
It installs a minimal in-process compatibility surface so the actual verifier tool
functions in server.py can be exercised over JSON-RPC/HTTP when the official SDK is
unavailable in an isolated CI/container environment.

Safety: production use is forbidden and raises immediately.
"""
from __future__ import annotations

import asyncio
import contextvars
import inspect
import json
import os
import sys
import types as pytypes
import uuid
from dataclasses import dataclass
from typing import Any, get_type_hints

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, create_model
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

if os.environ.get("VTD_ENV", "development").lower() == "production":
    raise RuntimeError("development MCP protocol probe is forbidden in production")

_access_token_ctx: contextvars.ContextVar[Any | None] = contextvars.ContextVar("vtd_probe_access_token", default=None)


class AccessToken(BaseModel):
    token: str
    client_id: str
    scopes: list[str] = Field(default_factory=list)
    resource: str | None = None
    subject: str | None = None
    expires_at: int | None = None
    claims: dict[str, Any] = Field(default_factory=dict)


class TokenVerifier:
    async def verify_token(self, token: str):
        raise NotImplementedError


class AuthSettings(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    issuer_url: Any
    resource_server_url: Any
    required_scopes: list[str] = Field(default_factory=list)
    validate_token_resource: bool = True


def get_access_token():
    return _access_token_ctx.get()


class Tool(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="allow")
    name: str
    description: str | None = None
    inputSchema: dict[str, Any] = Field(default_factory=lambda: {"type": "object", "properties": {}})
    outputSchema: dict[str, Any] | None = None
    annotations: dict[str, Any] | None = None
    securitySchemes: list[dict[str, Any]] | None = None
    meta: dict[str, Any] | None = Field(default=None, alias="_meta")


@dataclass
class _RegisteredTool:
    fn: Any
    meta: dict[str, Any]


def _json_schema_for_callable(fn) -> dict[str, Any]:
    sig = inspect.signature(fn)
    hints = get_type_hints(fn)
    fields: dict[str, tuple[Any, Any]] = {}
    for name, p in sig.parameters.items():
        annotation = hints.get(name, Any)
        default = ... if p.default is inspect._empty else p.default
        fields[name] = (annotation, default)
    if not fields:
        return {"type": "object", "properties": {}}
    model = create_model(f"Probe_{fn.__name__}_Input", **fields)
    return model.model_json_schema()


def _to_jsonable(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json", by_alias=True, exclude_none=True)
    if isinstance(value, dict):
        return {str(k): _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(v) for v in value]
    return value


class _LowLevelServer:
    def __init__(self, owner: "FastMCP"):
        self.owner = owner
        self._list_tools_cb = None

    def list_tools(self):
        def deco(fn):
            self._list_tools_cb = fn
            return fn
        return deco


class FastMCP:
    def __init__(self, name: str, *, host="0.0.0.0", port=8000, stateless_http=True, auth=None, token_verifier=None, **_):
        self.name = name
        self.host = host
        self.port = port
        self.stateless_http = stateless_http
        self.auth = auth
        self.token_verifier = token_verifier
        self._tools: dict[str, _RegisteredTool] = {}
        self._mcp_server = _LowLevelServer(self)

    def tool(self, meta: dict[str, Any] | None = None, **_kwargs):
        def deco(fn):
            self._tools[fn.__name__] = _RegisteredTool(fn=fn, meta=dict(meta or {}))
            return fn
        return deco

    async def list_tools(self):
        rows=[]
        for name, reg in self._tools.items():
            rows.append(Tool(name=name, description=(inspect.getdoc(reg.fn) or ""), inputSchema=_json_schema_for_callable(reg.fn), _meta=reg.meta or None))
        return rows

    async def _wire_tools(self):
        cb = self._mcp_server._list_tools_cb
        return await cb() if cb is not None else await self.list_tools()

    async def _authenticate(self, request: Request):
        if self.token_verifier is None:
            return None
        header = request.headers.get("authorization", "")
        if not header.lower().startswith("bearer "):
            return False
        token = header.split(" ",1)[1].strip()
        verified = await self.token_verifier.verify_token(token)
        if verified is None:
            return False
        required = set(getattr(self.auth, "required_scopes", []) or [])
        if required and not required.issubset(set(getattr(verified, "scopes", []) or [])):
            return False
        return verified

    def streamable_http_app(self):
        async def endpoint(request: Request):
            principal = await self._authenticate(request)
            if principal is False:
                return Response(status_code=401)
            token = _access_token_ctx.set(principal)
            try:
                try:
                    body = await request.json()
                except Exception:
                    return JSONResponse({"jsonrpc":"2.0","id":None,"error":{"code":-32700,"message":"Parse error"}}, status_code=400)
                method = body.get("method")
                req_id = body.get("id")
                params = body.get("params") or {}
                if method == "initialize":
                    result={
                        "protocolVersion":"2025-06-18",
                        "capabilities":{"tools":{"listChanged":False}},
                        "serverInfo":{"name":self.name,"version":"probe"},
                    }
                    resp=JSONResponse({"jsonrpc":"2.0","id":req_id,"result":result})
                    resp.headers["Mcp-Session-Id"] = request.headers.get("Mcp-Session-Id") or uuid.uuid4().hex
                    return resp
                if method == "notifications/initialized":
                    return Response(status_code=202)
                if method == "ping":
                    return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{}})
                if method == "tools/list":
                    tools=await self._wire_tools()
                    return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{"tools":[t.model_dump(mode="json", by_alias=True, exclude_none=True) for t in tools]}})
                if method == "tools/call":
                    name=str(params.get("name") or "")
                    reg=self._tools.get(name)
                    if reg is None:
                        return JSONResponse({"jsonrpc":"2.0","id":req_id,"error":{"code":-32601,"message":f"unknown tool: {name}"}}, status_code=404)
                    args=params.get("arguments") or {}
                    try:
                        out=reg.fn(**args)
                        if inspect.isawaitable(out): out=await out
                        payload=_to_jsonable(out)
                    except Exception as e:
                        return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{"content":[{"type":"text","text":repr(e)}],"isError":True}}, status_code=200)
                    text=json.dumps(payload,ensure_ascii=False,separators=(",",":"))
                    return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{"content":[{"type":"text","text":text}],"structuredContent":payload,"isError":False}})
                return JSONResponse({"jsonrpc":"2.0","id":req_id,"error":{"code":-32601,"message":f"Method not found: {method}"}}, status_code=404)
            finally:
                _access_token_ctx.reset(token)

        return Starlette(routes=[Route('/mcp', endpoint, methods=['POST'])])

    def run(self, transport="streamable-http"):
        if transport != "streamable-http":
            raise RuntimeError("probe supports streamable-http only")
        import uvicorn
        uvicorn.run(self.streamable_http_app(), host=self.host, port=self.port)


def install_fake_mcp_modules() -> None:
    """Install only the import surface used by this project, before importing server.py."""
    mcp = pytypes.ModuleType("mcp")
    server = pytypes.ModuleType("mcp.server")
    fastmcp = pytypes.ModuleType("mcp.server.fastmcp")
    auth = pytypes.ModuleType("mcp.server.auth")
    provider = pytypes.ModuleType("mcp.server.auth.provider")
    settings = pytypes.ModuleType("mcp.server.auth.settings")
    middleware = pytypes.ModuleType("mcp.server.auth.middleware")
    auth_context = pytypes.ModuleType("mcp.server.auth.middleware.auth_context")
    types_mod = pytypes.ModuleType("mcp.types")

    fastmcp.FastMCP = FastMCP
    provider.AccessToken = AccessToken
    provider.TokenVerifier = TokenVerifier
    settings.AuthSettings = AuthSettings
    auth_context.get_access_token = get_access_token
    types_mod.Tool = Tool

    sys.modules.update({
        "mcp": mcp,
        "mcp.server": server,
        "mcp.server.fastmcp": fastmcp,
        "mcp.server.auth": auth,
        "mcp.server.auth.provider": provider,
        "mcp.server.auth.settings": settings,
        "mcp.server.auth.middleware": middleware,
        "mcp.server.auth.middleware.auth_context": auth_context,
        "mcp.types": types_mod,
    })
