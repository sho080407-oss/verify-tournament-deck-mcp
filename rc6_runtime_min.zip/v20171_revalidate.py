#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, hashlib, importlib.util, json, sys
from pathlib import Path

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def dump(path,obj): Path(path).parent.mkdir(parents=True,exist_ok=True);Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def h(obj): return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def import_legacy(root:Path):
    target=root/'scripts'/'research_engine.py'
    sys.path.insert(0,str(root))
    spec=importlib.util.spec_from_file_location('vtd_v20171_research_engine',target)
    mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod); return mod

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--legacy-root',required=True);ap.add_argument('--config',required=True);ap.add_argument('--verifier-spec',required=True);ap.add_argument('--seed',type=int,default=20260920);ap.add_argument('--checkpoint-dir',required=True);ap.add_argument('--cache-dir',required=True);ap.add_argument('--reuse-seed');ap.add_argument('--out',required=True);a=ap.parse_args()
    re=import_legacy(Path(a.legacy_root).resolve());cfg=load(a.config);vs=load(a.verifier_spec);cpdir=Path(a.checkpoint_dir);cpdir.mkdir(parents=True,exist_ok=True);cp=cpdir/'revalidate-checkpoint.json'
    semantic_vs={}
    for k,v in vs.items():
        if k=='holdout_secret':continue
        semantic_vs[k]=re._resume_identity(v) if k in {'golden_manifest','source_lock','engine_certificate','holdout_commit'} else v
    input_fp=h({'engine':re.ENGINE_VERSION,'engine_source_digest':re.engine_source_manifest()['source_digest'],'mode':'revalidate_current','config':cfg,'verifier_spec_semantic':semantic_vs,'regression_scope':re._regression_scope_identity(vs)})
    prior=None;prior_source=None;seed_meta={}
    if cp.exists():
        try:
            d=load(cp)
            if d.get('input_fingerprint')==input_fp and isinstance(d.get('result'),dict):
                if d.get('stage')=='complete':
                    out=copy.deepcopy(d['result']);out.setdefault('resume',{})['reused_complete_checkpoint']=True;dump(a.out,out);print(json.dumps(out,ensure_ascii=False));return
                prior=d['result'];prior_source='same_run_checkpoint'
        except Exception:pass
    if prior is None and a.reuse_seed:
        try:
            seed_meta=load(a.reuse_seed)
            ev=seed_meta.get('evidence') if isinstance(seed_meta,dict) else None
            if isinstance(ev,dict):prior=ev;prior_source='parent_exact_invalidation_seed'
        except Exception:pass
    result={'schema':'current-deck-revalidation-v20.18-over-v20.17.1','engine_version':re.ENGINE_VERSION,'input_fingerprint':input_fp,'deck_fingerprint':re.fingerprint(cfg),'stages':{},'resume':{'reused_complete_checkpoint':False,'reused_stages':[],'reuse_source':prior_source,'parent_run_id':seed_meta.get('parent_run_id') if isinstance(seed_meta,dict) else None,'effect_reuse':seed_meta.get('effect_reuse') if isinstance(seed_meta,dict) else None}}
    def reuse(name,predicate=None):
        if not isinstance(prior,dict) or name not in prior:return None
        x=copy.deepcopy(prior[name])
        if predicate and not predicate(x):return None
        result['resume']['reused_stages'].append(name);return x
    def checkpoint(stage): dump(cp,{'schema':'v20.18-revalidate-checkpoint-v1','input_fingerprint':input_fp,'stage':stage,'result':result})
    player=vs.get('player_dsl');manifest=vs.get('suite_manifest')
    if not isinstance(player,dict) or not isinstance(manifest,dict):
        result.update({'status':'BLOCKED_VERIFIER_ASSETS','final_gate':{'ok':False,'status':'BLOCKED','blockers':['player_dsl_or_suite_manifest_missing']}});checkpoint('assets_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    ncache=vs.get('native_cache_dir') or a.cache_dir
    try:
        nr=re.apply_native_cache(player,str(ncache),vs.get('ruleset'));player=nr['dsl'];result['native_cache_apply']={k:v for k,v in nr.items() if k!='dsl'}
    except Exception as exc: result['native_cache_apply']={'error':str(exc)}
    sem_bundle=reuse('whole_dsl_semantic_fidelity',lambda x:isinstance(x,dict) and bool(x.get('ok')) and bool((x.get('player') or {}).get('ok')))
    if sem_bundle is not None:
        result['whole_dsl_semantic_fidelity']=sem_bundle;sem=sem_bundle.get('player') or {}
    else:
        sem=re._semantic_fidelity_report(player);result['whole_dsl_semantic_fidelity']={'player':sem,'ok':bool(sem.get('ok'))}
    if not sem.get('ok'):
        result.update({'status':'BLOCKED_SEMANTIC_FIDELITY','final_gate':{'ok':False,'status':'BLOCKED','blockers':['player_semantic_fidelity_bounded_abstraction']}});checkpoint('semantic_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    result['stages']['whole_dsl_semantic_fidelity']='PASS'
    reg=reuse('full_regression',lambda x:isinstance(x,dict) and x.get('ok')) or re._run_full_regression(vs);result['full_regression']=reg
    if not reg.get('ok'):
        result.update({'status':'BLOCKED_FULL_REGRESSION','final_gate':{'ok':False,'status':'BLOCKED','blockers':['full_regression']}});checkpoint('full_regression_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    result['stages']['full_regression']='PASS';checkpoint('full_regression_pass')
    bound=re._patch_suite_for_candidate(manifest,cfg);suite=reuse('tournament_final_suite',lambda x:isinstance(x,dict) and x.get('suite_pre_holdout_ready'))
    if suite is None:
        try:
            suite=re.run_reality_calibrated_full_match_suite(player,bound,'final',a.seed,str(Path(a.cache_dir)/'revalidate-suite'),str(cpdir/'full-match'),int(vs.get('max_refinement_rounds',2)))
        except Exception as exc:
            result.update({'status':'BLOCKED_TOURNAMENT_FINAL','tournament_final_error':{'type':type(exc).__name__,'message':str(exc)},'final_gate':{'ok':False,'status':'BLOCKED','blockers':['tournament_final_suite_engine_error']}});checkpoint('tournament_final_error');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    result['tournament_final_suite']=suite
    if not suite.get('suite_pre_holdout_ready'):
        result.update({'status':'BLOCKED_TOURNAMENT_FINAL','final_gate':{'ok':False,'status':'BLOCKED','blockers':['tournament_final_suite']}});checkpoint('tournament_final_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    result['stages']['tournament_final']='PASS';result['stages']['reality_calibration']='PASS';checkpoint('pre_holdout_ready')
    golden=vs.get('golden_manifest');source=vs.get('source_lock');commit=vs.get('holdout_commit');secret=vs.get('holdout_secret')
    seeded_ci=bool(isinstance(prior,dict) and isinstance(prior.get('final_ci'),dict) and prior['final_ci'].get('ok'))
    seeded_holdout=bool(isinstance(prior,dict) and isinstance(prior.get('sealed_holdout'),dict) and prior['sealed_holdout'].get('verified'))
    if (not golden or not source) and not seeded_ci:
        result.update({'status':'PRE_HOLDOUT_READY_FINAL_CI_ASSETS_REQUIRED','final_gate':{'ok':False,'status':'BLOCKED','blockers':['golden_manifest_or_source_lock_missing']}});checkpoint('ci_assets_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    if (not commit or not secret) and not seeded_holdout:
        result.update({'status':'PRE_HOLDOUT_READY_SEALED_HOLDOUT_REQUIRED','final_gate':{'ok':False,'status':'BLOCKED','blockers':['sealed_holdout_commit_or_secret_missing']}});checkpoint('holdout_assets_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    marker=Path(vs.get('holdout_marker') or ((str(commit)+'.used.json') if commit else (str(cpdir/'historical-holdout-reuse.used.json'))));ho=reuse('sealed_holdout',lambda x:isinstance(x,dict) and x.get('verified'))
    if ho is None:
        if marker.exists():
            result.update({'status':'BLOCKED_HOLDOUT_ALREADY_CONSUMED','final_gate':{'ok':False,'status':'BLOCKED','blockers':['sealed_holdout_already_consumed']}});checkpoint('holdout_consumed_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
        ho=re.run_sealed(cfg,commit,secret,int(vs.get('holdout_trials',500)));dump(marker,{'engine_version':re.ENGINE_VERSION,'config_fingerprint':re.fingerprint(cfg),'commit':str(commit),'trials':int(vs.get('holdout_trials',500)),'holdout_result_hash':h(ho),'independent_final_holdout':True,'mode':'revalidate_current'})
    result['sealed_holdout']=ho;result['stages']['sealed_holdout']='PASS';checkpoint('sealed_holdout_pass')
    ci=reuse('final_ci',lambda x:isinstance(x,dict) and x.get('ok')) or re.final_ci(cfg,golden,vs.get('golden_base'),source,vs.get('source_base','.'),int(vs.get('fuzz_iterations',100)),a.seed,int(vs.get('final_ci_jobs',0)),vs.get('engine_certificate'),a.cache_dir)
    result['final_ci']=ci
    if not ci.get('ok'):
        result.update({'status':'BLOCKED_FINAL_CI','final_gate':{'ok':False,'status':'BLOCKED','blockers':['final_ci']}});checkpoint('final_ci_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False));return
    result['stages']['final_ci']='PASS';checkpoint('final_ci_pass')
    validation=re.validate_config(cfg);opp_sem=all(bool(((r.get('semantic_fidelity') or {}).get('opponent') or {}).get('ok')) for r in suite.get('matchups',[]));coverage=all(bool((r.get('coverage') or {}).get('ok')) for r in suite.get('matchups',[]));blockers=[]
    if not validation.get('ok'):blockers.append('deck_validation')
    if not sem.get('ok') or not opp_sem:blockers.append('whole_dsl_semantic_fidelity')
    if not coverage:blockers.append('dsl_coverage_100')
    if not reg.get('ok'):blockers.append('full_regression')
    if not suite.get('suite_pre_holdout_ready'):blockers.append('tournament_final_suite')
    if not ci.get('ok'):blockers.append('final_ci')
    if not ho.get('verified'):blockers.append('sealed_holdout')
    gate={'schema':'tournament-final-gate-v20.18-revalidate','ok':not blockers,'status':'PASS' if not blockers else 'BLOCKED','blockers':blockers,'requirements':{'baseline_revalidation':True,'dsl_coverage_100':coverage,'whole_dsl_semantic_fidelity':bool(sem.get('ok') and opp_sem),'full_regression':bool(reg.get('ok')),'tournament_final':bool(suite.get('suite_pre_holdout_ready')),'reality_calibration':all(bool((r.get('calibration') or {}).get('ok')) for r in suite.get('matchups',[])),'independent_sealed_holdout':bool(ho.get('verified')),'final_ci':bool(ci.get('ok'))},'scope':'Main + Extra only; side optimization excluded'}
    result['final_gate']=gate;result['stages']['final_gate']='PASS' if gate['ok'] else 'BLOCKED';result['status']='TOURNAMENT_FINAL_CONFIRMED' if gate['ok'] else 'BLOCKED_FINAL_GATE';checkpoint('complete' if gate['ok'] else 'final_gate_blocked');dump(a.out,result);print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
