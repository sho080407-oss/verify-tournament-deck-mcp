from __future__ import annotations

"""Exact/conservative evidence invalidation for v20.18.

The graph is deliberately fail-closed: evidence is reusable only when every declared
semantic dependency fingerprint is identical *and* the parent actually contains passing
evidence for that node. Unchanged per-effect native semantics are tracked independently
from aggregate stages so a deck-count change can reuse all effect-level verification.
"""

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any


def _canon(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(_canon(obj).encode("utf-8")).hexdigest()


def _identity(value: Any) -> Any:
    """Content identity for inline verifier assets.

    v20.18's MCP contract transports JSON assets inline. If a caller supplies a path-like
    string, we intentionally treat the literal string as the identity here. The legacy
    bridge later materializes inline assets into a run-local workspace.
    """
    return value


def _entries(cfg: dict, key: str) -> list[dict]:
    out = []
    for row in cfg.get(key, []) or []:
        if not isinstance(row, dict):
            continue
        q = dict(row)
        q["name"] = str(q.get("name", ""))
        q["count"] = int(q.get("count", 0))
        if q["count"] > 0 and q["name"]:
            out.append(q)
    return sorted(out, key=lambda x: x["name"])


def config_fingerprint(cfg: dict | None) -> str:
    return sha256_obj(cfg or {})


def deck_fingerprint(deck: dict | None) -> str:
    deck = deck or {}
    return sha256_obj({"main": _entries(deck, "main"), "extra": _entries(deck, "extra")})


def _normalized_classifier_spec(cfg: dict) -> tuple[dict, set[str], set[str]]:
    rules = []
    rel_roles: set[str] = set()
    rel_names: set[str] = set()
    for r in cfg.get("classification_rules", []) or []:
        if not isinstance(r, dict):
            continue
        q = dict(r)
        for k in ("any_roles", "all_roles", "any_names", "all_names"):
            if k in q:
                q[k] = sorted(map(str, q.get(k, []) or []))
        for k in ("min_role_counts", "max_role_counts", "min_name_counts", "max_name_counts"):
            if k in q:
                q[k] = {str(a): int(b) for a, b in sorted((q.get(k, {}) or {}).items())}
        rel_roles.update(q.get("any_roles", []) or [])
        rel_roles.update(q.get("all_roles", []) or [])
        rel_names.update(q.get("any_names", []) or [])
        rel_names.update(q.get("all_names", []) or [])
        rel_roles.update((q.get("min_role_counts", {}) or {}).keys())
        rel_roles.update((q.get("max_role_counts", {}) or {}).keys())
        rel_names.update((q.get("min_name_counts", {}) or {}).keys())
        rel_names.update((q.get("max_name_counts", {}) or {}).keys())
        rules.append(q)
    obj = {
        "hand_size": int(cfg.get("hand_size", 5)),
        "classification_rules": rules,
        "default_class": str(cfg.get("default_class", "unclassified")),
        "success_classes": sorted(map(str, cfg.get("success_classes", []) or [])),
    }
    return obj, set(map(str, rel_roles)), set(map(str, rel_names))


def opening_analysis_fingerprint(cfg: dict | None) -> str:
    """Mirror v20.17.1 core.analysis_fingerprint semantics, but keep full SHA-256."""
    cfg = cfg or {}
    spec, rel_roles, rel_names = _normalized_classifier_spec(cfg)
    grouped: Counter[tuple[Any, tuple[str, ...]]] = Counter()
    for e in cfg.get("main", []) or []:
        if not isinstance(e, dict):
            continue
        name = str(e.get("name", ""))
        visible_name = name if name in rel_names else None
        visible_roles = tuple(sorted(set(map(str, e.get("roles", []) or [])) & rel_roles))
        grouped[(visible_name, visible_roles)] += int(e.get("count", 0))
    main = [
        {"name": k[0], "roles": list(k[1]), "count": v}
        for k, v in sorted(grouped.items(), key=lambda z: (str(z[0][0]), z[0][1]))
        if v
    ]
    return sha256_obj({"classifier": spec, "main_signatures": main})


def ruleset_fingerprint(dsl: dict | None, declared_ruleset: Any = None) -> str:
    dsl = dsl or {}
    md = dsl.get("metadata") or {}
    declared = declared_ruleset if declared_ruleset is not None else {
        "ruleset": md.get("ruleset"),
        "format": md.get("format"),
        "effective_date": md.get("effective_date"),
        "banlist": md.get("banlist"),
    }
    return sha256_obj({
        "game": dsl.get("game", "generic"),
        "schema_version": dsl.get("schema_version"),
        "declared": declared,
    })


def _plugin_relpath(game: str) -> str | None:
    g = str(game or "generic").lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "ygo": "yugioh", "yu_gi_oh": "yugioh", "yu-gi-oh": "yugioh",
        "ocg": "yugioh", "tcg": "yugioh", "duelmasters": "duel_masters",
        "duel_masters": "duel_masters", "dm": "duel_masters",
    }
    g = aliases.get(g, g)
    return f"engine/plugins/{g}.py" if g not in {"", "generic"} else None


def native_dependency_fingerprint(dsl: dict | None, legacy_root: str | Path) -> str:
    """Mirror v20.17.1 native_accel.native_dependency_manifest()."""
    dsl = dsl or {}
    root = Path(legacy_root)
    game = str(dsl.get("game", "generic"))
    rels = [
        "engine/state.py",
        "engine/faststate.py",
        "engine/mechanics.py",
        "engine/dsl_compiler.py",
        "engine/plugins/__init__.py",
        "engine/plugins/base.py",
    ]
    p = _plugin_relpath(game)
    if p:
        rels.append(p)
    files = []
    for rel in sorted(set(rels)):
        f = root / rel
        if not f.exists():
            continue
        data = f.read_bytes()
        files.append({"path": rel, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
    payload = {
        "schema": "native-runtime-dependencies-v1",
        "game": game,
        "dsl_schema_version": dsl.get("schema_version"),
        "files": files,
    }
    return sha256_obj(payload)


def effect_fingerprint_manifest(dsl: dict | None) -> dict[str, str]:
    """Exact source-effect identities compatible with v20.17.1 native cache keys."""
    dsl = dsl or {}
    out: dict[str, str] = {}
    for card in dsl.get("cards", []) or []:
        if not isinstance(card, dict):
            continue
        cname = str(card.get("name", ""))
        for idx, effect in enumerate(card.get("effects", []) or []):
            if not isinstance(effect, dict):
                continue
            eid = str(effect.get("id", ""))
            key = f"{cname}::{eid or '#'+str(idx)}"
            out[key] = sha256_obj({"identity": {"card": cname, "effect_id": eid}, "effect": effect})
    return dict(sorted(out.items()))


def _asset(vs: dict, name: str) -> Any:
    return _identity((vs or {}).get(name))


def _regression_scope(vs: dict) -> dict:
    paths = vs.get("regression_paths", ["tests"])
    if isinstance(paths, str):
        paths = [paths]
    extra = vs.get("regression_pytest_args", [])
    if isinstance(extra, str):
        extra = [extra]
    return {
        "paths": [str(x) for x in (paths or ["tests"])],
        "pytest_args": [str(x) for x in (extra or [])],
    }


def build_context(run: dict, *, legacy_root: str | Path, engine_bundle_fingerprint: str) -> dict:
    inputs = run.get("engine_inputs") or {}
    vs = inputs.get("verifier_spec") if isinstance(inputs.get("verifier_spec"), dict) else {}
    dsl = vs.get("player_dsl") if isinstance(vs.get("player_dsl"), dict) else {}
    cfg = inputs.get("current_config") if isinstance(inputs.get("current_config"), dict) else {}
    if not cfg and isinstance(inputs.get("base_config"), dict):
        cfg = inputs.get("base_config") or {}
    ruleset = run.get("ruleset") or {}
    effects = effect_fingerprint_manifest(dsl)
    native_dep = native_dependency_fingerprint(dsl, legacy_root)
    rs_fp = ruleset_fingerprint(dsl, ruleset)
    player_dsl_fp = sha256_obj(dsl)
    suite_fp = sha256_obj(_asset(vs, "suite_manifest"))
    regression_fp = sha256_obj(_regression_scope(vs))
    cfg_fp = config_fingerprint(cfg)
    opening_fp = opening_analysis_fingerprint(cfg)
    reality_fp = sha256_obj(run.get("reality_logs") or [])
    golden_fp = sha256_obj(_asset(vs, "golden_manifest"))
    source_fp = sha256_obj(_asset(vs, "source_lock"))
    engine_cert_fp = sha256_obj(_asset(vs, "engine_certificate"))
    holdout_commit_fp = sha256_obj(_asset(vs, "holdout_commit"))
    deck_fp = deck_fingerprint(run.get("deck") or {})

    effect_nodes = {
        k: sha256_obj({"source_effect_fingerprint": v, "ruleset": rs_fp, "native_dependency": native_dep})
        for k, v in effects.items()
    }

    node = {}
    node["DECK_LEGALITY"] = sha256_obj({"config": cfg_fp, "ruleset": rs_fp})
    node["OPENING_EXACT"] = sha256_obj({"opening_analysis": opening_fp})
    node["WHOLE_DSL_SEMANTIC_FIDELITY"] = sha256_obj({
        "player_dsl": player_dsl_fp, "ruleset": rs_fp, "native_dependency": native_dep
    })
    node["FULL_REGRESSION"] = sha256_obj({
        "engine_bundle": engine_bundle_fingerprint, "regression_scope": regression_fp, "ruleset": rs_fp
    })
    node["TOURNAMENT_FINAL"] = sha256_obj({
        "config": cfg_fp,
        "player_dsl": player_dsl_fp,
        "suite_manifest": suite_fp,
        "ruleset": rs_fp,
        "engine_bundle": engine_bundle_fingerprint,
    })
    node["REALITY_CALIBRATION"] = sha256_obj({
        "tournament_final": node["TOURNAMENT_FINAL"], "reality_logs": reality_fp
    })
    node["SEALED_HOLDOUT"] = sha256_obj({
        "config": cfg_fp,
        "holdout_commit": holdout_commit_fp,
        "ruleset": rs_fp,
        "engine_bundle": engine_bundle_fingerprint,
    })
    node["FINAL_CI"] = sha256_obj({
        "config": cfg_fp,
        "golden_manifest": golden_fp,
        "source_lock": source_fp,
        "engine_certificate": engine_cert_fp,
        "ruleset": rs_fp,
        "engine_bundle": engine_bundle_fingerprint,
        "regression_scope": regression_fp,
    })
    node["FINAL_GATE"] = sha256_obj({
        "deck_legality": node["DECK_LEGALITY"],
        "semantic": node["WHOLE_DSL_SEMANTIC_FIDELITY"],
        "regression": node["FULL_REGRESSION"],
        "tournament_final": node["TOURNAMENT_FINAL"],
        "reality_calibration": node["REALITY_CALIBRATION"],
        "sealed_holdout": node["SEALED_HOLDOUT"],
        "final_ci": node["FINAL_CI"],
    })
    return {
        "schema": "v20.18-evidence-context-v1",
        "deck": deck_fp,
        "config": cfg_fp,
        "opening_analysis": opening_fp,
        "ruleset": rs_fp,
        "player_dsl": player_dsl_fp,
        "suite_manifest": suite_fp,
        "regression_scope": regression_fp,
        "native_dependency": native_dep,
        "engine_bundle": engine_bundle_fingerprint,
        "effects": effects,
        "effect_nodes": effect_nodes,
        "nodes": node,
        "assets": {
            "golden_manifest": golden_fp,
            "source_lock": source_fp,
            "engine_certificate": engine_cert_fp,
            "holdout_commit": holdout_commit_fp,
            "reality_logs": reality_fp,
        },
    }


def _parent_has_passing_evidence(parent: dict, node: str) -> bool:
    result = parent.get("engine_result") or {}
    stages = result.get("stages") or {}
    if node == "WHOLE_DSL_SEMANTIC_FIDELITY":
        x = result.get("whole_dsl_semantic_fidelity")
        return bool(isinstance(x, dict) and x.get("ok", (x.get("player") or {}).get("ok"))) or str(stages.get("whole_dsl_semantic_fidelity", "")).startswith("PASS")
    if node == "FULL_REGRESSION":
        return bool((result.get("full_regression") or {}).get("ok")) or str(stages.get("full_regression", "")).startswith("PASS")
    if node == "TOURNAMENT_FINAL":
        return bool((result.get("tournament_final_suite") or {}).get("suite_pre_holdout_ready")) or str(stages.get("tournament_final", "")).startswith("PASS")
    if node == "REALITY_CALIBRATION":
        return str(stages.get("reality_calibration", "")).startswith("PASS")
    if node == "SEALED_HOLDOUT":
        return bool((result.get("sealed_holdout") or {}).get("verified")) or str(stages.get("sealed_holdout", "")).startswith("PASS")
    if node == "FINAL_CI":
        return bool((result.get("final_ci") or {}).get("ok")) or str(stages.get("final_ci", "")).startswith("PASS")
    if node == "FINAL_GATE":
        return bool((result.get("final_gate") or {}).get("ok"))
    if node == "OPENING_EXACT":
        # Zero-base results use varying keys across historical packages. Reuse is reported
        # only when an actual exact/opening artifact is present.
        return any(k in result for k in ("opening_exact", "exact", "opening_analysis"))
    if node == "DECK_LEGALITY":
        return True
    return False


def plan_reuse(parent: dict, child: dict, *, legacy_root: str | Path, parent_engine_bundle_fingerprint: str, child_engine_bundle_fingerprint: str) -> dict:
    stored_parent=parent.get('evidence_context_snapshot')
    if isinstance(stored_parent,dict) and stored_parent.get('schema')=='v20.18-evidence-context-v1':
        p=stored_parent
    else:
        p=build_context(parent, legacy_root=legacy_root, engine_bundle_fingerprint=parent_engine_bundle_fingerprint)
        # For imported/older runs we do not know the historical native dependency digest.
        # If the whole engine bundle changed, invalidate effect/native semantic reuse rather
        # than accidentally fingerprinting the parent with today's source tree.
        if parent_engine_bundle_fingerprint and parent_engine_bundle_fingerprint != child_engine_bundle_fingerprint:
            unknown=sha256_obj({'historical_native_dependency':'unknown','parent_engine_bundle':parent_engine_bundle_fingerprint})
            p['native_dependency']=unknown
            p['effect_nodes']={k:sha256_obj({'source_effect_fingerprint':v,'ruleset':p['ruleset'],'native_dependency':unknown}) for k,v in (p.get('effects') or {}).items()}
            p['nodes']['WHOLE_DSL_SEMANTIC_FIDELITY']=sha256_obj({'player_dsl':p['player_dsl'],'ruleset':p['ruleset'],'native_dependency':unknown})
    c = build_context(child, legacy_root=legacy_root, engine_bundle_fingerprint=child_engine_bundle_fingerprint)

    pfx, cfx = p["effect_nodes"], c["effect_nodes"]
    reused_effects = sorted(k for k in set(pfx) & set(cfx) if pfx[k] == cfx[k])
    changed_effects = sorted(k for k in set(pfx) & set(cfx) if pfx[k] != cfx[k])
    added_effects = sorted(set(cfx) - set(pfx))
    removed_effects = sorted(set(pfx) - set(cfx))

    ordered_nodes = [
        "DECK_LEGALITY",
        "OPENING_EXACT",
        "WHOLE_DSL_SEMANTIC_FIDELITY",
        "FULL_REGRESSION",
        "TOURNAMENT_FINAL",
        "REALITY_CALIBRATION",
        "SEALED_HOLDOUT",
        "FINAL_CI",
        "FINAL_GATE",
    ]
    reusable = []
    invalidated = []
    reasons: dict[str, list[str]] = {}

    component_names = [
        "deck", "config", "opening_analysis", "ruleset", "player_dsl", "suite_manifest",
        "regression_scope", "native_dependency", "engine_bundle",
    ]
    changed_components = [k for k in component_names if p.get(k) != c.get(k)]
    for k in ("golden_manifest", "source_lock", "engine_certificate", "holdout_commit", "reality_logs"):
        if p["assets"].get(k) != c["assets"].get(k):
            changed_components.append(k)

    for node in ordered_nodes:
        same = p["nodes"].get(node) == c["nodes"].get(node)
        has = _parent_has_passing_evidence(parent, node)
        if same and has:
            reusable.append(node)
        else:
            invalidated.append(node)
            rs = []
            if not same:
                # Report direct context differences without pretending to know a smaller
                # dependency than the node signature actually declares.
                rs.append("dependency_fingerprint_changed")
            if not has:
                rs.append("parent_passing_evidence_absent")
            reasons[node] = rs

    no_op = p["deck"] == c["deck"] and p["config"] == c["config"] and p["player_dsl"] == c["player_dsl"] and p["ruleset"] == c["ruleset"]
    return {
        "schema": "v20.18-exact-invalidation-plan-v1",
        "parent_run_id": parent.get("run_id"),
        "child_run_id": child.get("run_id"),
        "no_op": no_op,
        "changed_components": sorted(set(changed_components)),
        "effect_reuse": {
            "parent_effects": len(pfx),
            "child_effects": len(cfx),
            "reused_exact": len(reused_effects),
            "changed": len(changed_effects),
            "added": len(added_effects),
            "removed": len(removed_effects),
            "reused_effect_keys": reused_effects,
            "changed_effect_keys": changed_effects,
            "added_effect_keys": added_effects,
            "removed_effect_keys": removed_effects,
        },
        "reusable_nodes": reusable,
        "invalidated_nodes": invalidated,
        "invalidation_reasons": reasons,
        "parent_context_fingerprint": sha256_obj(p),
        "child_context_fingerprint": sha256_obj(c),
        "parent_context": p,
        "child_context": c,
    }


def seed_evidence_from_parent(parent: dict, plan: dict) -> dict:
    """Return only fields explicitly authorized by the exact invalidation plan."""
    result = parent.get("engine_result") or {}
    reusable = set(plan.get("reusable_nodes") or [])
    evidence: dict[str, Any] = {}
    node_to_field = {
        "WHOLE_DSL_SEMANTIC_FIDELITY": "whole_dsl_semantic_fidelity",
        "FULL_REGRESSION": "full_regression",
        "TOURNAMENT_FINAL": "tournament_final_suite",
        "SEALED_HOLDOUT": "sealed_holdout",
        "FINAL_CI": "final_ci",
    }
    for node, field in node_to_field.items():
        if node in reusable and field in result:
            evidence[field] = result[field]
    # Stage-only reality calibration is safe to mark only when the entire Tournament Final
    # suite is being reused. The helper derives the stage again from the reused suite.
    return {
        "schema": "v20.18-parent-evidence-seed-v1",
        "parent_run_id": parent.get("run_id"),
        "authorized_nodes": sorted(reusable),
        "effect_reuse": plan.get("effect_reuse") or {},
        "evidence": evidence,
    }
