from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from runtime_restore import safe_extract_zip, sha256_file

MAX_REPLAY_ARCHIVE_BYTES = 256 * 1024 * 1024


class ReplayResolverError(RuntimeError):
    pass


def _hash(value: Any) -> str:
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _json(path: Path) -> dict | None:
    try:
        v=json.loads(path.read_text(encoding='utf-8'))
        return v if isinstance(v,dict) else None
    except Exception:
        return None


def _all_files(root: Path) -> list[Path]:
    return sorted(x for x in root.rglob('*') if x.is_file())


def _find_by_name(root: Path,name:str)->list[Path]:
    return [x for x in _all_files(root) if x.name==name]



def _player_dsl_for_run(run:dict)->dict|None:
    vs=((run.get('engine_inputs') or {}).get('verifier_spec') or {})
    dsl=vs.get('player_dsl') if isinstance(vs,dict) else None
    if isinstance(dsl,dict): return dsl
    expected=str(((run.get('legacy_import') or {}).get('historical_fingerprints') or {}).get('player_dsl_sha256') or '')
    for rec in run.get('historical_evidence_capsules') or []:
        root=Path(str((rec or {}).get('capsule_root') or ''))
        if not root.is_dir(): continue
        for p in root.rglob('*.json'):
            if 'player-dsl' not in p.name.lower() and 'player_dsl' not in p.name.lower(): continue
            d=_json(p)
            if d and (not expected or sha256_file(p)==expected): return d
    return None

def _runtime_fp(run:dict)->str|None:
    hr=run.get('historical_runtime') if isinstance(run.get('historical_runtime'),dict) else {}
    return hr.get('engine_bundle_fingerprint') or (run.get('fingerprints') or {}).get('legacy_engine_bundle')


def unresolved_actions(run:dict)->list[dict]:
    he=run.get('historical_evidence') if isinstance(run.get('historical_evidence'),dict) else {}
    actions=copy.deepcopy(((he.get('replay_plan') or {}).get('missing_actions') or []))
    completed=run.get('historical_replay') if isinstance(run.get('historical_replay'),dict) else {}
    results=completed.get('results') if isinstance(completed.get('results'),dict) else {}
    out=[]
    for a in actions:
        key=obligation_key(a)
        row=results.get(key)
        if isinstance(row,dict) and row.get('certified'):
            continue
        out.append(a)
    priority={'FULL_REGRESSION':10,'TOURNAMENT_FINAL':20,'REALITY_CALIBRATION':30,'SEALED_HOLDOUT':40,'FINAL_CI':50,'FINAL_GATE':60}
    return sorted(out,key=lambda a:(priority.get(str(a.get('node')),99),str(a.get('target') or '')))


def obligation_key(action:dict)->str:
    return f"{action.get('node')}::{action.get('kind')}::{action.get('target')}"


def replay_summary(run:dict)->dict:
    actions=unresolved_actions(run)
    rr=run.get('historical_replay') if isinstance(run.get('historical_replay'),dict) else {}
    return {
        'status':rr.get('status','NOT_STARTED'),
        'certificate_fingerprint':rr.get('certificate_fingerprint'),
        'certified_nodes':rr.get('certified_nodes',[]),
        'unresolved_action_count':len(actions),
        'unresolved_regression_test_total':sum(int(x.get('count') or 0) for x in actions if x.get('node')=='FULL_REGRESSION'),
        'unresolved_tournament_matchups':[x.get('target') for x in actions if x.get('node')=='TOURNAMENT_FINAL'],
        'blockers':rr.get('blockers',[]),
    }


def _validate_binding(run:dict,doc:dict,*,require_dsl:bool=False)->dict:
    expected_runtime=_runtime_fp(run)
    expected_deck=(run.get('fingerprints') or {}).get('deck')
    expected_rules=(run.get('fingerprints') or {}).get('ruleset')
    checks={}
    if doc.get('runtime_bundle_fingerprint') is not None:
        checks['runtime']={'expected':expected_runtime,'actual':doc.get('runtime_bundle_fingerprint'),'match':doc.get('runtime_bundle_fingerprint')==expected_runtime}
    if doc.get('deck_fingerprint') is not None:
        checks['deck']={'expected':expected_deck,'actual':doc.get('deck_fingerprint'),'match':doc.get('deck_fingerprint')==expected_deck}
    if doc.get('ruleset_fingerprint') is not None:
        checks['ruleset']={'expected':expected_rules,'actual':doc.get('ruleset_fingerprint'),'match':doc.get('ruleset_fingerprint')==expected_rules}
    if require_dsl:
        player=(run.get('engine_inputs') or {}).get('verifier_spec',{}).get('player_dsl')
        actual=_hash(player) if isinstance(player,dict) else None
        expected=doc.get('player_dsl_fingerprint')
        checks['player_dsl']={'expected':actual,'actual':expected,'match':bool(expected and expected==actual)}
    ok=bool(checks) and all(v['match'] for v in checks.values())
    return {'ok':ok,'checks':checks}


def validate_coverage_identity_matrix(run:dict,matrix:dict)->dict:
    """Validate a strict replacement-coverage map without trusting test counts alone.

    A missing historical generated fixture may only be closed when every declared historical
    obligation has a replacement assertion bound to concrete test bytes + node ids.  The
    resolver does not infer semantic equivalence from arithmetic test counts.
    """
    if not isinstance(matrix,dict):
        raise ReplayResolverError('coverage identity matrix must be an object')
    if str(matrix.get('schema') or '') not in {'v20.18.5-coverage-identity-v1','coverage-identity-v1','v20.18.6-coverage-identity-v2'}:
        raise ReplayResolverError('unsupported coverage identity schema')
    binding=_validate_binding(run,matrix)
    if not binding['ok']:
        return {'ok':False,'status':'BINDING_MISMATCH','binding':binding,'groups':{}}
    required=[x for x in unresolved_actions(run) if x.get('node')=='FULL_REGRESSION' and x.get('kind')=='fixture_group']
    rows=matrix.get('groups') if isinstance(matrix.get('groups'),list) else []
    by_target={str(x.get('historical_fixture')):x for x in rows if isinstance(x,dict)}
    groups={};all_ok=True
    for action in required:
        target=str(action.get('target'));count=int(action.get('count') or 0);row=by_target.get(target)
        problems=[]
        if not row:
            problems.append('group_missing')
            groups[target]={'ok':False,'problems':problems};all_ok=False;continue
        if int(row.get('historical_test_count') or -1)!=count:
            problems.append('historical_test_count_mismatch')
        resolution=str(row.get('resolution') or 'coverage_identity')
        repl=row.get('replacement_assertions') if isinstance(row.get('replacement_assertions'),list) else []
        obligation_ids=set();covered=set()
        if resolution=='scope_exclusion':
            sx=row.get('scope_exclusion') if isinstance(row.get('scope_exclusion'),dict) else {}
            obligations=row.get('historical_obligations') if isinstance(row.get('historical_obligations'),list) else []
            obligation_ids={str(x.get('id')) for x in obligations if isinstance(x,dict) and x.get('id')}
            if len(obligation_ids)!=count: problems.append('scope_exclusion_obligation_count_mismatch')
            if str((run.get('mode') or ''))!='revalidate_current': problems.append('scope_exclusion_requires_revalidate_current')
            if str(sx.get('decision') or '')!='RETAIN_INCUMBENT': problems.append('scope_exclusion_decision_invalid')
            if str(sx.get('incumbent_fingerprint') or '')!=str((run.get('fingerprints') or {}).get('deck') or ''): problems.append('scope_exclusion_incumbent_mismatch')
            att_ok=False
            expected_sha=str(sx.get('attestation_sha256') or '').lower()
            for rec in run.get('historical_evidence_capsules') or []:
                if not (rec.get('manifest_ok') and rec.get('gate_manifest_bound') and rec.get('gate_runtime_match') and rec.get('gate_dsl_match')): continue
                root=Path(str(rec.get('capsule_root') or ''))
                if not root.is_dir(): continue
                for gp in list(root.rglob('final_gate_cp12u.json'))+list(root.rglob('*FINAL_GATE*.json')):
                    if expected_sha and sha256_file(gp)!=expected_sha: continue
                    gd=_json(gp) or {};c=gd.get('candidate_selection_convergence') if isinstance(gd.get('candidate_selection_convergence'),dict) else {}
                    if str(c.get('decision'))=='RETAIN_INCUMBENT' and str(c.get('incumbent_fingerprint'))==str((run.get('fingerprints') or {}).get('deck') or '') and str(c.get('challenger_semantic_native_verification') or '').startswith('PASS'):
                        att_ok=True;break
                if att_ok: break
            if not att_ok: problems.append('scope_exclusion_attestation_unverified')
        elif resolution=='superseding_revalidation':
            obligations=row.get('superseding_obligations') if isinstance(row.get('superseding_obligations'),list) else []
            obligation_ids={str(x.get('id')) for x in obligations if isinstance(x,dict) and x.get('id')}
            basis=row.get('coverage_basis') if isinstance(row.get('coverage_basis'),dict) else {}
            if str(basis.get('basis_type') or '')!='current-scope-superseding-v1': problems.append('superseding_basis_invalid')
            if len(obligation_ids)!=count: problems.append('superseding_obligation_count_mismatch')
            player=_player_dsl_for_run(run)
            actual_effects=sum(len(c.get('effects',[]) or []) for c in (player.get('cards',[]) if isinstance(player,dict) else []) if isinstance(c,dict))
            declared_effects=basis.get('player_effect_count')
            if declared_effects is not None and int(declared_effects)!=actual_effects: problems.append('superseding_effect_count_mismatch')
            critical=basis.get('critical_runtime_hashes') if isinstance(basis.get('critical_runtime_hashes'),dict) else {}
            hr=run.get('historical_runtime') if isinstance(run.get('historical_runtime'),dict) else {};rr=Path(str(hr.get('runtime_root') or ''))
            for rel,dig in critical.items():
                fp=rr/str(rel)
                if not fp.is_file() or sha256_file(fp)!=str(dig): problems.append('superseding_runtime_hash_mismatch');break
            fresh=basis.get('fresh_test_count')
            if fresh is not None and int(fresh)!=count: problems.append('superseding_fresh_test_count_mismatch')
            if len(repl)!=count: problems.append('superseding_assertion_count_mismatch')
        else:
            obligations=row.get('historical_obligations') if isinstance(row.get('historical_obligations'),list) else []
            obligation_ids={str(x.get('id')) for x in obligations if isinstance(x,dict) and x.get('id')}
            if not obligations: problems.append('historical_obligations_missing')
        if resolution!='scope_exclusion':
            if not repl: problems.append('replacement_assertions_missing')
            for a in repl:
                if not isinstance(a,dict):continue
                if not a.get('nodeid'): problems.append('replacement_nodeid_missing');continue
                digest=str(a.get('file_sha256') or '').lower()
                if not re.fullmatch(r'[0-9a-f]{64}',digest): problems.append('replacement_file_sha256_missing')
                for oid in a.get('covers') or []:covered.add(str(oid))
            if obligation_ids and covered!=obligation_ids: problems.append('coverage_not_exact')
        groups[target]={'ok':not problems,'problems':sorted(set(problems)),'resolution':resolution,'historical_obligation_count':len(obligation_ids),'replacement_assertion_count':len(repl)}
        if problems:all_ok=False
    return {'ok':all_ok and bool(required),'status':'PASS' if all_ok and required else 'INCOMPLETE','binding':binding,'groups':groups,'matrix_fingerprint':_hash(matrix)}


def _pytest_file_from_nodeid(nodeid:str)->str:
    return nodeid.split('::',1)[0]


def _run_subprocess(cmd:list[str],cwd:Path,timeout:int,env:dict|None=None)->dict:
    e=os.environ.copy();
    if env:e.update(env)
    started=time.monotonic()
    proc=subprocess.Popen(cmd,cwd=str(cwd),env=e,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=(os.name!='nt'))
    try:
        out,err=proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name!='nt':
            try:os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError:pass
        else:proc.terminate()
        try:out,err=proc.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            if os.name!='nt':
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError:pass
            else:proc.kill()
            out,err=proc.communicate()
        return {'ok':False,'timed_out':True,'elapsed_seconds':round(time.monotonic()-started,3),'stdout_tail':(out or '')[-12000:],'stderr_tail':(err or '')[-12000:]}
    return {'ok':proc.returncode==0,'returncode':proc.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'stdout_tail':(out or '')[-12000:],'stderr_tail':(err or '')[-12000:]}


class MissingEvidenceReplay:
    def __init__(self,storage_root:str|Path):
        self.root=Path(storage_root);self.root.mkdir(parents=True,exist_ok=True)

    def inspect_replay_asset_archive(self,run:dict,archive_path:str|Path)->dict:
        p=Path(archive_path)
        if not p.is_file():raise ReplayResolverError('replay asset archive not found')
        if p.stat().st_size>MAX_REPLAY_ARCHIVE_BYTES:raise ReplayResolverError('replay asset archive too large')
        digest=sha256_file(p);dest=self.root/digest
        if dest.exists():shutil.rmtree(dest)
        dest.mkdir(parents=True)
        safe_extract_zip(p,dest)
        matrix_files=_find_by_name(dest,'coverage_identity_matrix.json')
        matrix=_json(matrix_files[0]) if len(matrix_files)==1 else None
        matrix_validation=validate_coverage_identity_matrix(run,matrix) if matrix else {'ok':False,'status':'NOT_PRESENT'}
        exact={}
        for action in unresolved_actions(run):
            if action.get('node')!='FULL_REGRESSION':continue
            target=str(action.get('target'));cands=_find_by_name(dest,target)
            exact[target]=[]
            for q in cands:
                exact[target].append({'path':str(q),'sha256':sha256_file(q),'bytes':q.stat().st_size})
        return {'archive_path':str(p.resolve()),'archive_sha256':digest,'extracted_root':str(dest.resolve()),'coverage_identity_matrix':matrix,'coverage_identity_validation':matrix_validation,'exact_fixture_candidates':exact}

    def execute_regression_group(self,run:dict,action:dict,asset_record:dict,runtime_root:str|Path,timeout:int)->dict:
        target=str(action.get('target'));expected_count=int(action.get('count') or 0);root=Path(runtime_root);asset_root=Path(asset_record['extracted_root'])
        exact=[Path(x['path']) for x in (asset_record.get('exact_fixture_candidates') or {}).get(target,[]) if Path(x['path']).is_file()]
        mode=None;nodeids=[];file_bindings=[]
        if len(exact)==1:
            mode='exact_historical_fixture';nodeids=[str(exact[0])];file_bindings=[{'path':str(exact[0]),'sha256':sha256_file(exact[0])}]
        else:
            mv=asset_record.get('coverage_identity_validation') or {};matrix=asset_record.get('coverage_identity_matrix') or {}
            if not mv.get('ok') or not ((mv.get('groups') or {}).get(target) or {}).get('ok'):
                return {'certified':False,'status':'REPLAY_ASSET_REQUIRED','node':'FULL_REGRESSION','target':target,'count':expected_count}
            row=next((x for x in matrix.get('groups',[]) if isinstance(x,dict) and str(x.get('historical_fixture'))==target),None)
            resolution=str((row or {}).get('resolution') or 'coverage_identity')
            if resolution=='scope_exclusion':
                return {'certified':True,'status':'PASS','node':'FULL_REGRESSION','target':target,'historical_test_count':expected_count,'execution_mode':'scope_exclusion','executed_assertions':0,'scope_exclusion':copy.deepcopy(row.get('scope_exclusion') or {}),'runtime_bundle_fingerprint':_runtime_fp(run)}
            mode='superseding_revalidation' if resolution=='superseding_revalidation' else 'coverage_identity_replacement'
            for a in row.get('replacement_assertions') or []:
                nid=str(a.get('nodeid'));rel=_pytest_file_from_nodeid(nid);fp=(asset_root/rel).resolve()
                try:fp.relative_to(asset_root.resolve())
                except Exception:return {'certified':False,'status':'UNSAFE_REPLACEMENT_PATH','target':target}
                if not fp.is_file():return {'certified':False,'status':'REPLACEMENT_TEST_MISSING','target':target,'missing':rel}
                actual=sha256_file(fp);expected=str(a.get('file_sha256') or '').lower()
                if actual!=expected:return {'certified':False,'status':'REPLACEMENT_TEST_HASH_MISMATCH','target':target,'file':rel,'expected':expected,'actual':actual}
                nodeids.append(str(fp)+nid[len(rel):]);file_bindings.append({'path':str(fp),'sha256':actual})
        env={'PYTHONPATH':str(root)+(os.pathsep+str(asset_root))}
        cmd=[sys.executable,'-m','pytest','-q',*nodeids]
        ex=_run_subprocess(cmd,root,timeout,env)
        collected=None
        m=re.search(r'(\d+) passed',ex.get('stdout_tail',''))
        if m:collected=int(m.group(1))
        # Exact historical fixture group must preserve historical count. Coverage replacement
        # may have a different number of executable assertions, because semantic obligations
        # are mapped one-to-one explicitly rather than by arithmetic count.
        count_ok=(collected==expected_count) if mode in {'exact_historical_fixture','superseding_revalidation'} else bool(collected and collected>0)
        return {
            'certified':bool(ex.get('ok') and count_ok),'status':'PASS' if ex.get('ok') and count_ok else 'FAIL',
            'node':'FULL_REGRESSION','target':target,'historical_test_count':expected_count,'execution_mode':mode,
            'executed_assertions':collected,'file_bindings':file_bindings,'execution':ex,
            'runtime_bundle_fingerprint':_runtime_fp(run),
        }

    def execute_matchup(self,run:dict,action:dict,runtime_root:str|Path,workspace:str|Path,timeout:int)->dict:
        target=str(action.get('target'));inputs=run.get('engine_inputs') or {};vs=inputs.get('verifier_spec') if isinstance(inputs.get('verifier_spec'),dict) else {}
        player=vs.get('player_dsl');manifest=vs.get('suite_manifest')
        if not isinstance(player,dict) or not isinstance(manifest,dict):
            return {'certified':False,'status':'VERIFIER_ASSETS_REQUIRED','node':'TOURNAMENT_FINAL','target':target}
        rows=[copy.deepcopy(x) for x in manifest.get('matchups',[]) or [] if isinstance(x,dict) and str(x.get('name'))==target]
        if len(rows)!=1:
            return {'certified':False,'status':'MATCHUP_NOT_IN_SUITE_MANIFEST','node':'TOURNAMENT_FINAL','target':target}
        filtered=copy.deepcopy(manifest);filtered['matchups']=rows
        wd=Path(workspace);wd.mkdir(parents=True,exist_ok=True)
        p_player=wd/'player.json';p_manifest=wd/'manifest.json';p_out=wd/'matchup-result.json'
        p_player.write_text(json.dumps(player,ensure_ascii=False),encoding='utf-8');p_manifest.write_text(json.dumps(filtered,ensure_ascii=False),encoding='utf-8')
        helper=Path(__file__).resolve().parent/'bridge6_replay_worker.py'
        cmd=[sys.executable,str(helper),'--legacy-root',str(Path(runtime_root)),'--player',str(p_player),'--manifest',str(p_manifest),'--seed',str(int(inputs.get('seed',20260920))),'--out',str(p_out),'--cache-dir',str(wd/'cache'),'--checkpoint-dir',str(wd/'checkpoints')]
        ex=_run_subprocess(cmd,Path(runtime_root),timeout,{'PYTHONPATH':str(runtime_root)})
        result=_json(p_out) if p_out.exists() else None
        ready=bool(isinstance(result,dict) and result.get('suite_pre_holdout_ready') and len(result.get('matchups',[]) or [])==1)
        return {'certified':bool(ex.get('ok') and ready),'status':'PASS' if ex.get('ok') and ready else 'FAIL','node':'TOURNAMENT_FINAL','target':target,'result':result,'execution':ex,'runtime_bundle_fingerprint':_runtime_fp(run)}


def merge_replay_result(run:dict,row:dict)->dict:
    rr=copy.deepcopy(run.get('historical_replay') or {})
    results=rr.get('results') if isinstance(rr.get('results'),dict) else {}
    key=f"{row.get('node')}::{('fixture_group' if row.get('node')=='FULL_REGRESSION' else 'matchup')}::{row.get('target')}"
    results[key]=copy.deepcopy(row);rr['results']=results
    original=((run.get('historical_evidence') or {}).get('replay_plan') or {}).get('missing_actions') or []
    def done(a):
        k=obligation_key(a);r=results.get(k);return bool(isinstance(r,dict) and r.get('certified'))
    reg=[a for a in original if a.get('node')=='FULL_REGRESSION'];tf=[a for a in original if a.get('node')=='TOURNAMENT_FINAL']
    cert=[]
    if reg and all(done(a) for a in reg):cert.append('FULL_REGRESSION')
    if tf and all(done(a) for a in tf):cert.append('TOURNAMENT_FINAL')
    rr['certified_nodes']=cert
    missing=[copy.deepcopy(a) for a in original if not done(a)]
    rr['replay_plan']={'missing_actions':missing,'missing_action_count':len(missing),'missing_regression_test_total':sum(int(a.get('count') or 0) for a in missing if a.get('node')=='FULL_REGRESSION'),'missing_tournament_matchups':[a.get('target') for a in missing if a.get('node')=='TOURNAMENT_FINAL']}
    payload={'runtime':_runtime_fp(run),'results':{k:{'certified':v.get('certified'),'status':v.get('status'),'target':v.get('target'),'node':v.get('node'),'execution_mode':v.get('execution_mode'),'runtime_bundle_fingerprint':v.get('runtime_bundle_fingerprint')} for k,v in sorted(results.items())}}
    rr['certificate_fingerprint']=_hash(payload);rr['status']='PASS_COMPLETE' if not missing else ('PASS_PARTIAL' if any(v.get('certified') for v in results.values()) else 'IN_PROGRESS')
    return rr
