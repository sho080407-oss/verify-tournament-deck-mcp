from __future__ import annotations

import json
import os
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from transactional_state import connect, database_path_from_tenant_root, initialize

TERMINAL = {"COMPLETED", "FAILED"}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class OperationJournal:
    """Durable operation journal stored in the same SQLite database as run state."""

    def __init__(self, tenant_root: str | Path):
        self.tenant_root = Path(tenant_root)
        self.db_path = database_path_from_tenant_root(self.tenant_root)
        initialize(self.db_path)
        self.legacy_root = self.tenant_root / "_operation_journal"
        self.legacy_root.mkdir(parents=True, exist_ok=True)
        self._migrate_legacy_once()

    def _path(self, op_id: str) -> Path:
        """Legacy compatibility mirror path. SQLite remains canonical."""
        return self.legacy_root / f"{op_id}.json"

    def _mirror(self, rec: dict) -> None:
        p=self._path(rec["op_id"])
        tmp=p.with_name(p.name+f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(rec,ensure_ascii=False,indent=2),encoding="utf-8")
        os.replace(tmp,p)

    def _migrate_legacy_once(self) -> None:
        con = connect(self.db_path)
        try:
            already = con.execute("SELECT value FROM metadata WHERE key='legacy_journal_migrated'").fetchone()
            if already and already[0] == "1":
                return
            con.execute("BEGIN IMMEDIATE")
            if self.legacy_root.exists():
                for p in self.legacy_root.glob("op-*.json"):
                    try:
                        d = json.loads(p.read_text(encoding="utf-8"))
                    except Exception:
                        continue
                    if not d.get("op_id") or not d.get("run_id") or not d.get("operation"):
                        continue
                    try:
                        started_ts = datetime.fromisoformat(str(d.get("started_at")).replace("Z", "+00:00")).timestamp()
                    except Exception:
                        try:
                            started_ts = p.stat().st_mtime
                        except OSError:
                            started_ts = time.time()
                    con.execute(
                        "INSERT OR IGNORE INTO operations(op_id,run_id,operation,request_id,status,started_at,started_ts,finished_at,pid,error) "
                        "VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (
                            d["op_id"], d["run_id"], d["operation"], d.get("request_id"), d.get("status", "STARTED"),
                            d.get("started_at") or _now(), started_ts, d.get("finished_at"), d.get("pid"), d.get("error"),
                        ),
                    )
            con.execute(
                "INSERT INTO metadata(key,value) VALUES('legacy_journal_migrated','1') "
                "ON CONFLICT(key) DO UPDATE SET value='1'"
            )
            con.execute("COMMIT")
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()

    def begin(self, run_id: str, operation: str, request_id: str | None = None) -> dict:
        now = _now()
        rec = {
            "op_id": f"op-{uuid.uuid4().hex}",
            "run_id": run_id,
            "operation": operation,
            "request_id": request_id,
            "status": "STARTED",
            "started_at": now,
            "pid": os.getpid(),
        }
        con = connect(self.db_path)
        try:
            con.execute(
                "INSERT INTO operations(op_id,run_id,operation,request_id,status,started_at,started_ts,pid) VALUES(?,?,?,?,?,?,?,?)",
                (rec["op_id"], run_id, operation, request_id, "STARTED", now, time.time(), rec["pid"]),
            )
        finally:
            con.close()
        self._mirror(rec)
        return rec

    def finish(self, rec: dict, *, ok: bool, error: str | None = None) -> dict:
        out = dict(rec)
        out["status"] = "COMPLETED" if ok else "FAILED"
        out["finished_at"] = _now()
        if error:
            out["error"] = error[:2000]
        con = connect(self.db_path)
        try:
            con.execute(
                "UPDATE operations SET status=?,finished_at=?,error=? WHERE op_id=?",
                (out["status"], out["finished_at"], out.get("error"), out["op_id"]),
            )
        finally:
            con.close()
        self._mirror(out)
        return out

    def stale_for_run(self, run_id: str, min_age_seconds: int = 5) -> list[dict]:
        cutoff = time.time() - max(0, min_age_seconds)
        con = connect(self.db_path)
        try:
            rows = con.execute(
                "SELECT * FROM operations WHERE run_id=? AND status NOT IN ('COMPLETED','FAILED') ORDER BY started_ts",
                (run_id,),
            ).fetchall()
        finally:
            con.close()
        out=[]
        for row in rows:
            d=dict(row); effective_ts=float(d.get("started_ts") or time.time())
            p=self._path(str(d["op_id"]))
            if p.exists():
                try: effective_ts=min(effective_ts,p.stat().st_mtime)
                except OSError: pass
            if effective_ts<=cutoff: out.append(d)
        return out

    def mark_recovered(self, run_id: str) -> int:
        con = connect(self.db_path)
        now = _now()
        try:
            con.execute("BEGIN IMMEDIATE")
            rows=con.execute("SELECT * FROM operations WHERE run_id=? AND status NOT IN ('COMPLETED','FAILED')",(run_id,)).fetchall()
            cur = con.execute(
                "UPDATE operations SET status='FAILED',finished_at=?,error='SERVER_INTERRUPTED_OPERATION_RECOVERED' "
                "WHERE run_id=? AND status NOT IN ('COMPLETED','FAILED')",
                (now, run_id),
            )
            n = int(cur.rowcount)
            con.execute("COMMIT")
            for row in rows:
                d=dict(row);d["status"]="FAILED";d["finished_at"]=now;d["error"]="SERVER_INTERRUPTED_OPERATION_RECOVERED";self._mirror(d)
            return n
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()
