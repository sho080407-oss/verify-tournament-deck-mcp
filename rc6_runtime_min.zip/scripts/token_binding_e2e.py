#!/usr/bin/env python3
"""Bridge 19 development-only local IdP -> MCP token-binding E2E.

Exercises the real OIDC/JWKS verifier with an actual local HTTP discovery/JWKS
server and RS256-signed JWTs. Production safety is preserved because local HTTP
auth is accepted only behind VTD_DEV_ALLOW_LOCAL_AUTH_SIM=1 and never when
VTD_ENV=production.
"""
from __future__ import annotations

import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def boot_idp(server_dir: Path, port: int):
    env = os.environ.copy(); env.update({
        "PYTHONPATH": str(server_dir),
        "VTD_ENV": "development",
        "VTD_DEV_ALLOW_LOCAL_AUTH_SIM": "1",
        "VTD_LOCAL_IDP_ISSUER": f"http://127.0.0.1:{port}",
    })
    return subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "local_idp_simulator:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"],
        cwd=server_dir, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )


def boot_mcp(server_dir: Path, port: int, idp_port: int, data_dir: Path):
    issuer = f"http://127.0.0.1:{idp_port}"
    resource = f"http://127.0.0.1:{port}/mcp"
    env = os.environ.copy(); env.update({
        "PYTHONPATH": str(server_dir),
        "VTD_ENV": "development",
        "VTD_AUTH_MODE": "oidc",
        "VTD_AUTH_ISSUER_URL": issuer,
        "VTD_OIDC_DISCOVERY_URL": issuer + "/.well-known/openid-configuration",
        "VTD_PUBLIC_MCP_URL": resource,
        "VTD_JWT_ALGORITHMS": "RS256",
        "VTD_JWKS_CACHE_TTL": "300",
        "VTD_JWT_CLOCK_SKEW": "0",
        "VTD_DEV_ALLOW_LOCAL_AUTH_SIM": "1",
        "VTD_DATA_DIR": str(data_dir),
        "MCP_PORT": str(port),
        "OPENAI_APPS_CHALLENGE_TOKEN": "bridge19-probe-token",
    })
    return subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "dev_mcp_probe_app:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"],
        cwd=server_dir, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )


def stop(p):
    if p is None: return
    if p.poll() is None:
        p.terminate()
        try: p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill(); p.wait(5)


def wait_ok(url: str, timeout=20):
    deadline = time.time() + timeout
    with httpx.Client(timeout=2) as c:
        while time.time() < deadline:
            try:
                if c.get(url).status_code == 200:
                    return
            except Exception:
                pass
            time.sleep(.15)
    raise RuntimeError(f"endpoint did not become ready: {url}")


def token(client: httpx.Client, idp: str, *, resource: str | None, sub: str, scope="openid email deck:verify", lifetime=300, issuer_override=None):
    data = {
        "grant_type": "authorization_code",
        "code": sub,
        "code_verifier": "bridge19-code-verifier",
        "client_id": "bridge19-chatgpt",
        "scope": scope,
        "lifetime": str(lifetime),
    }
    if resource is not None:
        data["resource"] = resource
    if issuer_override:
        data["issuer_override"] = issuer_override
    r = client.post(idp + "/token", data=data)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def rpc(client, url, bearer, method, params=None, rid=1, session=None):
    h = {"Authorization": f"Bearer {bearer}", "Accept": "application/json, text/event-stream", "Content-Type": "application/json"}
    if session: h["Mcp-Session-Id"] = session
    return client.post(url, headers=h, json={"jsonrpc": "2.0", "id": rid, "method": method, "params": params or {}})


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--server-dir", type=Path, default=Path(__file__).resolve().parents[1]); args = ap.parse_args()
    server_dir = args.server_dir.resolve(); idp_port = free_port(); mcp_port = free_port()
    idp = f"http://127.0.0.1:{idp_port}"; base = f"http://127.0.0.1:{mcp_port}"; mcp = base + "/mcp"
    idp_proc = mcp_proc = None
    with tempfile.TemporaryDirectory(prefix="vtd-bridge19-") as td:
        data_dir = Path(td) / "data"
        try:
            idp_proc = boot_idp(server_dir, idp_port); wait_ok(idp + "/healthz")
            mcp_proc = boot_mcp(server_dir, mcp_port, idp_port, data_dir); wait_ok(base + "/healthz")
            with httpx.Client(timeout=12) as c:
                good_a = token(c, idp, resource=mcp, sub="user-a")
                good_b = token(c, idp, resource=mcp, sub="user-b")
                wrong_resource = token(c, idp, resource="https://wrong.example.test/mcp", sub="user-a")
                missing_resource = token(c, idp, resource=None, sub="user-a")
                missing_scope = token(c, idp, resource=mcp, sub="user-a", scope="openid email profile:read")
                bad_issuer = token(c, idp, resource=mcp, sub="user-a", issuer_override="https://evil.example.test")
                expired = token(c, idp, resource=mcp, sub="user-a", lifetime=-10)

                for bad in (wrong_resource, missing_resource, missing_scope, bad_issuer, expired):
                    r = rpc(c, mcp, bad, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "bridge19-negative", "version": "1"}})
                    assert r.status_code == 401, (r.status_code, r.text)

                init = rpc(c, mcp, good_a, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "bridge19", "version": "1"}}, 1)
                assert init.status_code == 200, init.text
                session = init.headers.get("Mcp-Session-Id")
                tools = rpc(c, mcp, good_a, "tools/list", {}, 2, session).json()["result"]["tools"]
                names = {x["name"] for x in tools}; assert {"get_profile", "create_verification_run", "get_verification_status", "recover_interrupted_run"} <= names

                pa = rpc(c, mcp, good_a, "tools/call", {"name": "get_profile", "arguments": {}}, 3, session).json()["result"]["structuredContent"]
                pb = rpc(c, mcp, good_b, "tools/call", {"name": "get_profile", "arguments": {}}, 4, session).json()["result"]["structuredContent"]
                assert pa["id"] != pb["id"], (pa, pb)

                ui = c.get(idp + "/userinfo", headers={"Authorization": f"Bearer {good_a}", "Accept": "application/json"})
                assert ui.status_code == 200, ui.text
                ui_doc = ui.json()
                assert ui_doc.get("email") == "user-a@example.test" and ui_doc.get("email_verified") is True, ui_doc

                create_args = {"mode": "revalidate_current", "game": "yugioh_ocg", "deck": {"main": [{"name": "Probe Card", "count": 40}], "extra": [], "side": []}, "ruleset": {"jurisdiction": "Japan OCG", "effective_date": "2026-07-01"}, "constraints": {"side_deck": False}, "label": "bridge19-token-binding"}
                cr = rpc(c, mcp, good_a, "tools/call", {"name": "create_verification_run", "arguments": create_args}, 5, session).json()["result"]
                assert not cr.get("isError"), cr
                run_id = cr["structuredContent"]["run_id"]
                hidden = rpc(c, mcp, good_b, "tools/call", {"name": "get_verification_status", "arguments": {"run_id": run_id}}, 6, session).json()["result"]
                assert hidden.get("isError") is True, hidden

                # Real HTTP JWKS rotation: the verifier starts with a cached old key.
                rot = c.post(idp + "/rotate"); assert rot.status_code == 200, rot.text
                rotated = token(c, idp, resource=mcp, sub="user-a")
                init2 = rpc(c, mcp, rotated, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "bridge19-rotation", "version": "1"}}, 7)
                assert init2.status_code == 200, init2.text

            # Restart only the MCP process; durable tenant data must survive.
            stop(mcp_proc); mcp_proc = boot_mcp(server_dir, mcp_port, idp_port, data_dir); wait_ok(base + "/healthz")
            with httpx.Client(timeout=12) as c:
                resumed_token = token(c, idp, resource=mcp, sub="user-a")
                init = rpc(c, mcp, resumed_token, "initialize", {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "bridge19-restart", "version": "1"}}, 8)
                session = init.headers.get("Mcp-Session-Id")
                st = rpc(c, mcp, resumed_token, "tools/call", {"name": "get_verification_status", "arguments": {"run_id": run_id}}, 9, session).json()["result"]["structuredContent"]
                assert st["run_id"] == run_id, st
                rec = rpc(c, mcp, resumed_token, "tools/call", {"name": "recover_interrupted_run", "arguments": {"run_id": run_id}}, 10, session).json()["result"]["structuredContent"]
                assert rec["run_id"] == run_id and rec["resume_policy"] == "DURABLE_CHECKPOINT_ONLY_NO_COMPLETED_STAGE_RERUN", rec

            print(json.dumps({
                "status": "LOCAL_IDP_TOKEN_BINDING_E2E_PASS",
                "protocol": "2025-06-18",
                "tools": len(names),
                "resource_binding": "PASS",
                "issuer_scope_expiry_negative_cases": "PASS",
                "workspace_identity_userinfo": "PASS",
                "jwks_rotation": "PASS",
                "tenant_isolation": "PASS",
                "restart_resume": "PASS",
                "official_external_idp_used": False,
                "official_mcp_sdk_used": False,
                "run_id": run_id,
            }, ensure_ascii=False))
        finally:
            stop(mcp_proc); stop(idp_proc)
            for p in (mcp_proc, idp_proc):
                if p and p.stdout:
                    out = p.stdout.read()
                    if out.strip(): print(out, file=sys.stderr)
                if p and p.stderr:
                    err = p.stderr.read()
                    if err.strip(): print(err, file=sys.stderr)


if __name__ == "__main__":
    main()
