#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path
import httpx


def free_port():
    s=socket.socket(); s.bind(('127.0.0.1',0)); p=s.getsockname()[1]; s.close(); return p


def rpc(client, url, token, method, params=None, rid=1, session=None):
    h={"Authorization":f"Bearer {token}","Accept":"application/json, text/event-stream","Content-Type":"application/json"}
    if session: h["Mcp-Session-Id"]=session
    r=client.post(url,headers=h,json={"jsonrpc":"2.0","id":rid,"method":method,"params":params or {}})
    return r


def boot(server_dir:Path, port:int, data_dir:Path):
    env=os.environ.copy(); env.update({
        "PYTHONPATH":str(server_dir), "VTD_ENV":"development", "VTD_AUTH_MODE":"static",
        "VTD_AUTH_ISSUER_URL":"https://issuer.example.test", "VTD_PUBLIC_MCP_URL":f"http://127.0.0.1:{port}/mcp",
        "VTD_STATIC_TOKENS_JSON":json.dumps({
            "token-a":{"sub":"user-a","client_id":"client-a","scopes":["deck:verify"],"iss":"https://issuer.example.test"},
            "token-b":{"sub":"user-b","client_id":"client-b","scopes":["deck:verify"],"iss":"https://issuer.example.test"},
        }), "VTD_DATA_DIR":str(data_dir), "MCP_PORT":str(port), "OPENAI_APPS_CHALLENGE_TOKEN":"probe-token",
    })
    cmd=[sys.executable,"-m","uvicorn","dev_mcp_probe_app:app","--host","127.0.0.1","--port",str(port),"--log-level","warning"]
    return subprocess.Popen(cmd,cwd=server_dir,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)


def wait_ready(base, timeout=15):
    deadline=time.time()+timeout
    with httpx.Client(timeout=2) as c:
        while time.time()<deadline:
            try:
                if c.get(base+"/healthz").status_code==200:return
            except Exception: pass
            time.sleep(.15)
    raise RuntimeError("probe server did not become ready")


def stop(p):
    if p.poll() is None:
        p.terminate()
        try:p.wait(5)
        except subprocess.TimeoutExpired:
            p.kill(); p.wait(5)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--server-dir",type=Path,default=Path(__file__).resolve().parents[1]); args=ap.parse_args()
    server_dir=args.server_dir.resolve(); port=free_port(); base=f"http://127.0.0.1:{port}"; url=base+"/mcp"
    with tempfile.TemporaryDirectory(prefix="vtd-bridge14-") as td:
        data=Path(td)/"data"; p=boot(server_dir,port,data)
        try:
            wait_ready(base)
            with httpx.Client(timeout=10) as c:
                unauth=c.post(url,json={"jsonrpc":"2.0","id":1,"method":"initialize","params":{}})
                assert unauth.status_code==401, unauth.text
                assert "resource_metadata=" in unauth.headers.get("www-authenticate",""), unauth.headers

                init=rpc(c,url,"token-a","initialize",{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"bridge14","version":"1"}},1)
                assert init.status_code==200, init.text
                j=init.json(); assert j["result"]["protocolVersion"]=="2025-06-18",j
                session=init.headers.get("Mcp-Session-Id")

                tools=rpc(c,url,"token-a","tools/list",{},2,session); assert tools.status_code==200,tools.text
                rows=tools.json()["result"]["tools"]; names={x["name"] for x in rows}
                required={"get_profile","create_verification_run","get_verification_status","recover_interrupted_run"}
                assert required<=names, sorted(required-names)
                for row in rows:
                    assert isinstance(row.get("description"),str) and row["description"].strip(), row
                    assert row.get("securitySchemes")==[{"type":"oauth2","scopes":["deck:verify"]}], row
                    assert row.get("_meta",{}).get("securitySchemes")==[{"type":"oauth2","scopes":["deck:verify"]}], row
                    annotations=row.get("annotations") or {}
                    for key in ("readOnlyHint","destructiveHint","openWorldHint"):
                        assert isinstance(annotations.get(key),bool), (row.get("name"),annotations)

                pa=rpc(c,url,"token-a","tools/call",{"name":"get_profile","arguments":{}},3,session).json()["result"]["structuredContent"]
                pb=rpc(c,url,"token-b","tools/call",{"name":"get_profile","arguments":{}},4,session).json()["result"]["structuredContent"]
                assert pa["id"]!=pb["id"],(pa,pb)

                create_args={"mode":"revalidate_current","game":"yugioh_ocg","deck":{"main":[{"name":"Probe Card","count":40}],"extra":[],"side":[]},"ruleset":{"jurisdiction":"Japan OCG","effective_date":"2026-07-01"},"constraints":{"side_deck":False},"label":"bridge14-e2e"}
                cr=rpc(c,url,"token-a","tools/call",{"name":"create_verification_run","arguments":create_args},5,session).json()["result"]
                assert not cr.get("isError"),cr
                run=cr["structuredContent"]["run_id"]
                st=rpc(c,url,"token-a","tools/call",{"name":"get_verification_status","arguments":{"run_id":run}},6,session).json()["result"]["structuredContent"]
                assert st["run_id"]==run,st
                hidden=rpc(c,url,"token-b","tools/call",{"name":"get_verification_status","arguments":{"run_id":run}},7,session).json()["result"]
                assert hidden.get("isError") is True,hidden

            stop(p)
            p=boot(server_dir,port,data); wait_ready(base)
            with httpx.Client(timeout=10) as c:
                init=rpc(c,url,"token-a","initialize",{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"bridge14-restart","version":"1"}},8); session=init.headers.get("Mcp-Session-Id")
                st2=rpc(c,url,"token-a","tools/call",{"name":"get_verification_status","arguments":{"run_id":run}},9,session).json()["result"]["structuredContent"]
                assert st2["run_id"]==run,st2
                rec=rpc(c,url,"token-a","tools/call",{"name":"recover_interrupted_run","arguments":{"run_id":run}},10,session).json()["result"]["structuredContent"]
                assert rec["run_id"]==run and rec["resume_policy"]=="DURABLE_CHECKPOINT_ONLY_NO_COMPLETED_STAGE_RERUN",rec

            print(json.dumps({"status":"PROTOCOL_WIRE_E2E_PASS","protocol":"2025-06-18","tools":len(names),"run_id":run,"tenant_isolation":"PASS","restart_resume":"PASS","official_sdk_used":False},ensure_ascii=False))
        finally:
            stop(p)
            if p.stdout:
                out=p.stdout.read()
                if out.strip(): print(out,file=sys.stderr)
            if p.stderr:
                err=p.stderr.read()
                if err.strip(): print(err,file=sys.stderr)

if __name__=="__main__": main()
