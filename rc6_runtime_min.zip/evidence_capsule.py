from __future__ import annotations
from safe_download import download_limited, SafeDownloadError

import copy
import hashlib
import json
import os
import re
import shutil
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from runtime_restore import safe_extract_zip, sha256_file, semantic_runtime_manifest

MAX_EVIDENCE_ARCHIVE_BYTES = 256 * 1024 * 1024


class EvidenceCapsuleError(RuntimeError):
    pass


def _json(path: Path) -> dict | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _ruleset_date(value: Any) -> str | None:
    if isinstance(value, dict):
        for k in ("effective_date", "effective_limit", "current_effective_limit"):
            v = value.get(k)
            if v:
                return str(v)
        value = json.dumps(value, ensure_ascii=False)
    s = str(value or "")
    m = re.search(r"20\d{2}-\d{2}-\d{2}", s)
    return m.group(0) if m else None


def _manifest_entries(doc: dict) -> list[dict[str, Any]]:
    # Historical bundles used both {path: sha256} and {files:[{path,sha256,bytes}]}.
    if isinstance(doc.get("files"), list):
        out = []
        for row in doc["files"]:
            if not isinstance(row, dict):
                continue
            path = str(row.get("path") or "").strip()
            digest = str(row.get("sha256") or "").lower().strip()
            if path and re.fullmatch(r"[0-9a-f]{64}", digest):
                out.append({"path": path.replace("\\", "/"), "sha256": digest, "bytes": row.get("bytes")})
        return out
    out = []
    for k, v in doc.items():
        if isinstance(v, str) and re.fullmatch(r"[0-9a-fA-F]{64}", v):
            out.append({"path": str(k).replace("\\", "/"), "sha256": v.lower(), "bytes": None})
    return out


def _all_files(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*") if p.is_file())


def _resolve_manifest_file(root: Path, rel: str, digest: str, digest_index: dict[str, list[Path]]) -> tuple[Path | None, str]:
    direct = root / rel
    if direct.is_file() and sha256_file(direct) == digest:
        return direct, "exact_path"
    # Some archived final bundles were intentionally flattened after creation. Content
    # identity is still accepted only when the SHA-256 target is unique in the capsule.
    matches = digest_index.get(digest, [])
    if len(matches) == 1:
        return matches[0], "unique_content_relocation"
    basename = Path(rel).name
    named = [p for p in matches if p.name == basename]
    if len(named) == 1:
        return named[0], "unique_basename_and_content_relocation"
    return None, "missing_or_ambiguous"


def _runtime_hashes(root: Path) -> dict[str, str]:
    return semantic_runtime_manifest(root)


def _attested_runtime_matches(attestation: dict, runtime_root: Path) -> tuple[bool, dict[str, Any]]:
    mapping = {
        "engine_full_match_sha256": "engine/full_match.py",
        "engine_rule_kernel_sha256": "engine/rule_kernel.py",
        "engine_action_templates_sha256": "engine/action_templates.py",
        "engine_route_planner_sha256": "engine/route_planner.py",
    }
    checks = {}
    for key, rel in mapping.items():
        expected = attestation.get(key)
        p = runtime_root / rel
        if expected:
            actual = sha256_file(p) if p.is_file() else None
            checks[rel] = {"expected": expected, "actual": actual, "match": actual == expected}
    return bool(checks) and all(x["match"] for x in checks.values()), checks


def _commit_runtime_matches(commit: dict, runtime_root: Path, player_dsl_sha256: str | None) -> tuple[bool, dict[str, Any]]:
    declared = commit.get("runtime_fingerprints") if isinstance(commit.get("runtime_fingerprints"), dict) else {}
    checks = {}
    for key, expected in declared.items():
        if key == "player_dsl_105":
            actual = player_dsl_sha256
        elif str(key).startswith("engine/"):
            p = runtime_root / str(key)
            actual = sha256_file(p) if p.is_file() else None
        else:
            continue
        checks[str(key)] = {"expected": expected, "actual": actual, "match": actual == expected}
    return bool(checks) and all(x["match"] for x in checks.values()), checks


def _find_json_by_schema(root: Path, prefix: str) -> list[tuple[Path, dict]]:
    out = []
    for p in _all_files(root):
        if p.suffix.lower() != ".json":
            continue
        d = _json(p)
        if d and str(d.get("schema") or "").startswith(prefix):
            out.append((p, d))
    return out


def _find_by_name(root: Path, name: str) -> list[Path]:
    return [p for p in _all_files(root) if p.name == name]


def _verified_path_set(manifest_records: list[dict]) -> set[str]:
    out = set()
    for m in manifest_records:
        for row in m.get("entries", []):
            if row.get("match"):
                out.add(str(row.get("actual_path")))
    return out


def _is_manifest_verified_file(path: Path, verified_paths: set[str]) -> bool:
    return str(path.resolve()) in verified_paths


def _regression_replay_plan(root: Path, verified_paths: set[str]) -> dict[str, Any]:
    missing_groups = []
    total = 0
    recon_files = _find_by_name(root, "full_regression_reconciliation_cp12r.json")
    recon = _json(recon_files[0]) if recon_files else None
    current_pass = None
    if recon:
        inv = recon.get("inventory_reconciliation") if isinstance(recon.get("inventory_reconciliation"), dict) else {}
        unavailable = int(inv.get("exact_old_generated_test_bodies_still_unavailable") or 0)
        current_pass = copy.deepcopy(recon.get("current_materialized_suite"))
        rows = inv.get("cp12k_missing_from_current_materialized_test_tree") if isinstance(inv.get("cp12k_missing_from_current_materialized_test_tree"), dict) else {}
        recovered = {"test_v20_17_deck_optimizer.py", "test_witchcrafter_cp11c1_incremental.py"}
        for name, count in rows.items():
            if name in recovered:
                continue
            c = int(count or 0)
            candidates = [p for p in _all_files(root) if p.name == name]
            exact_body_verified = any(_is_manifest_verified_file(p, verified_paths) for p in candidates)
            if not exact_body_verified:
                missing_groups.append({"fixture": name, "tests": c, "reason": "historical_test_body_unavailable_or_unbound"})
                total += c
        # Preserve the historical explicit total as a guard if the named rows are incomplete.
        if unavailable > total:
            missing_groups.append({"fixture": "unattributed_historical_generated_fixtures", "tests": unavailable-total, "reason": "historical_reconciliation_declares_additional_gap"})
            total = unavailable
    return {
        "complete": total == 0 and bool(recon),
        "missing_test_groups": missing_groups,
        "missing_test_total": total,
        "current_materialized_suite": current_pass,
        "reconciliation_present": bool(recon),
    }


def _tournament_replay_plan(root: Path, verified_paths: set[str], gate: dict | None) -> dict[str, Any]:
    matchups = {}
    gate_tf = ((gate or {}).get("evidence") or {}).get("tournament_final") if isinstance((gate or {}).get("evidence"), dict) else None
    declared = gate_tf.get("matchups") if isinstance(gate_tf, dict) and isinstance(gate_tf.get("matchups"), dict) else {}
    # Aggregate evidence can certify an individual matchup only if its bytes are directly
    # manifest-bound in the capsule. A summary/reference alone is not enough.
    for name, meta in declared.items():
        meta = meta if isinstance(meta, dict) else {"status": meta}
        ref = meta.get("aggregate")
        verified_aggregate = False
        actual = None
        if ref:
            bn = Path(str(ref)).name
            cands = [p for p in _all_files(root) if p.name == bn]
            for p in cands:
                if _is_manifest_verified_file(p, verified_paths):
                    verified_aggregate = True; actual = str(p); break
        matchups[name] = {
            "status": meta.get("status"),
            "aggregate_reference": ref,
            "aggregate_verified": verified_aggregate,
            "actual_aggregate": actual,
            "replay_required": not verified_aggregate,
        }
    complete = bool(matchups) and all(not x["replay_required"] for x in matchups.values())
    return {"complete": complete, "matchups": matchups, "missing_matchups": [k for k,v in matchups.items() if v["replay_required"]]}


class HistoricalEvidenceCapsule:
    def __init__(self, storage_root: str | Path):
        self.storage_root = Path(storage_root)
        self.storage_root.mkdir(parents=True, exist_ok=True)

    def download_file(self, file_obj: dict) -> Path:
        url = str(file_obj.get("download_url") or "").strip()
        if not url:
            raise EvidenceCapsuleError("evidence_capsule_file.download_url is required")
        name = str(file_obj.get("file_name") or "historical-evidence.zip")
        if Path(name).suffix.lower() != ".zip":
            raise EvidenceCapsuleError("historical evidence capsule must be a ZIP archive")
        try:
            return download_limited(url=url, storage_root=self.storage_root, filename="evidence-capsule.zip", max_bytes=MAX_EVIDENCE_ARCHIVE_BYTES, user_agent="verify-tournament-deck-v20.18.22")
        except SafeDownloadError as e:
            raise EvidenceCapsuleError(str(e)) from e

    def inspect_archive(self, *, run: dict, archive_path: str | Path, runtime_root: str | Path | None, source_file: dict | None = None) -> dict:
        archive_path = Path(archive_path)
        capsule_hash = sha256_file(archive_path)
        work = Path(tempfile.mkdtemp(prefix="vtd-evidence-inspect-", dir=self.storage_root))
        extracted = work / "extracted"
        try:
            safe_extract_zip(archive_path, extracted)
        except Exception as e:
            shutil.rmtree(work, ignore_errors=True)
            raise EvidenceCapsuleError(str(e)) from e

        files = _all_files(extracted)
        digest_index: dict[str, list[Path]] = {}
        for p in files:
            digest_index.setdefault(sha256_file(p), []).append(p)

        manifest_records = []
        for p in files:
            if p.name.upper() not in {"SHA256_MANIFEST.JSON", "MANIFEST.JSON", "EVIDENCE_MANIFEST.JSON"}:
                continue
            doc = _json(p)
            if not doc: continue
            entries = _manifest_entries(doc)
            if not entries: continue
            checked = []
            for row in entries:
                actual, method = _resolve_manifest_file(extracted, row["path"], row["sha256"], digest_index)
                checked.append({**row, "actual_path": str(actual.resolve()) if actual else None, "match": bool(actual), "resolution": method})
            manifest_records.append({
                "manifest_path": str(p.resolve()), "manifest_sha256": sha256_file(p),
                "entries": checked, "ok": bool(checked) and all(x["match"] for x in checked),
            })
        verified_paths = _verified_path_set(manifest_records)
        manifest_ok = bool(manifest_records) and all(m["ok"] for m in manifest_records)

        gate_rows = _find_json_by_schema(extracted, "tournament-final-gate-")
        gate_path, gate = gate_rows[0] if gate_rows else (None, None)
        gate_bound = bool(gate_path and _is_manifest_verified_file(gate_path, verified_paths))

        legacy = run.get("legacy_import") if isinstance(run.get("legacy_import"), dict) else {}
        historical_fp = legacy.get("historical_fingerprints") if isinstance(legacy.get("historical_fingerprints"), dict) else {}
        declared_deck_fp = str(legacy.get("declared_deck_fingerprint") or "")
        ruleset_date = _ruleset_date(run.get("ruleset"))
        player_dsl_sha = str(historical_fp.get("player_dsl_sha256") or "") or None

        runtime_root_p = Path(runtime_root) if runtime_root else None
        runtime_exact = bool(runtime_root_p and runtime_root_p.is_dir())
        gate_runtime_match = False; gate_runtime_checks = {}
        if gate and runtime_exact:
            att = gate.get("fingerprint_attestation") if isinstance(gate.get("fingerprint_attestation"), dict) else {}
            gate_runtime_match, gate_runtime_checks = _attested_runtime_matches(att, runtime_root_p)
        gate_dsl_match = bool(gate and player_dsl_sha and ((gate.get("fingerprint_attestation") or {}).get("player_dsl_sha256") == player_dsl_sha))

        regression = _regression_replay_plan(extracted, verified_paths)
        tournament = _tournament_replay_plan(extracted, verified_paths, gate)

        # Holdout certificate: all key payloads must be manifest-bound and cryptographically linked.
        commit_paths = _find_by_name(extracted, "sealed_holdout_commit_v2.json")
        result_paths = _find_by_name(extracted, "sealed_holdout_result.json")
        commit_p = commit_paths[0] if commit_paths else None; result_p = result_paths[0] if result_paths else None
        commit = _json(commit_p) if commit_p else None; result = _json(result_p) if result_p else None
        holdout_bound = bool(commit_p and result_p and _is_manifest_verified_file(commit_p, verified_paths) and _is_manifest_verified_file(result_p, verified_paths))
        holdout_link = bool(commit and result and result.get("commit_sha256") == sha256_file(commit_p))
        holdout_deck = bool(commit and declared_deck_fp and str(commit.get("deck_fingerprint") or "") == declared_deck_fp)
        holdout_ruleset = bool(commit and ruleset_date and _ruleset_date(commit.get("ruleset")) == ruleset_date)
        holdout_runtime = False; holdout_runtime_checks = {}
        if commit and runtime_exact:
            holdout_runtime, holdout_runtime_checks = _commit_runtime_matches(commit, runtime_root_p, player_dsl_sha)
        holdout_result_ok = bool(result and result.get("verified") is True and str(result.get("status") or "").startswith("PASS"))
        holdout_certified = all([manifest_ok, holdout_bound, holdout_link, holdout_deck, holdout_ruleset, holdout_runtime, holdout_result_ok])

        # Final CI certificate is anchored by the manifest-bound final gate attestation.
        ci_paths = _find_by_name(extracted, "final_ci_cp12t.json")
        ci_p = ci_paths[0] if ci_paths else None; ci = _json(ci_p) if ci_p else None
        ci_bound = bool(ci_p and _is_manifest_verified_file(ci_p, verified_paths))
        gate_ci = ((gate or {}).get("evidence") or {}).get("final_ci") if isinstance((gate or {}).get("evidence"), dict) else None
        ci_summary_match = bool(ci and isinstance(gate_ci, dict) and ci.get("ok") is True and gate_ci.get("ok") is True and str(ci.get("engine_version")) == str(gate_ci.get("engine_version")) and str(ci.get("config_fingerprint")) == str(gate_ci.get("config_fingerprint")))
        # If the same capsule carries a sealed-holdout commitment with a broader runtime
        # fingerprint set, Final CI is bound to that exact post-commit runtime too. This
        # prevents a narrower final-gate attestation from silently ignoring a changed
        # shared plugin such as engine/plugins/yugioh.py.
        ci_runtime_complete = bool(gate_runtime_match and (holdout_runtime if holdout_bound and commit else True))
        ci_certified = all([manifest_ok, gate_bound, ci_bound, ci_runtime_complete, gate_dsl_match, ci_summary_match])

        reality_paths = _find_by_name(extracted, "reality_calibration_cp12s.json")
        reality_p = reality_paths[0] if reality_paths else None; reality = _json(reality_p) if reality_p else None
        reality_bound = bool(reality_p and _is_manifest_verified_file(reality_p, verified_paths))
        reality_certified = bool(manifest_ok and reality_bound and gate_bound and gate_runtime_match and gate_dsl_match and reality and str(reality.get("status") or "").startswith("PASS"))

        nodes = {
            "FULL_REGRESSION": {"certified": bool(manifest_ok and regression["complete"] and gate_runtime_match and gate_dsl_match), "evidence": regression.get("current_materialized_suite"), "replay": regression},
            "TOURNAMENT_FINAL": {"certified": bool(manifest_ok and tournament["complete"] and gate_runtime_match and gate_dsl_match), "evidence": ((gate or {}).get("evidence") or {}).get("tournament_final") if gate else None, "replay": tournament},
            "REALITY_CALIBRATION": {"certified": reality_certified, "evidence": reality},
            "SEALED_HOLDOUT": {"certified": holdout_certified, "evidence": result, "commit": commit, "checks": {"manifest_bound":holdout_bound,"commit_result_link":holdout_link,"deck_match":holdout_deck,"ruleset_match":holdout_ruleset,"runtime_and_dsl_match":holdout_runtime,"runtime_details":holdout_runtime_checks,"result_verified":holdout_result_ok}},
            "FINAL_CI": {"certified": ci_certified, "evidence": ci, "checks": {"manifest_bound":ci_bound,"gate_manifest_bound":gate_bound,"gate_runtime_match":gate_runtime_match,"holdout_runtime_match_if_present":holdout_runtime if holdout_bound and commit else None,"gate_dsl_match":gate_dsl_match,"gate_summary_match":ci_summary_match}},
            "FINAL_GATE": {"certified": False, "quarantined": bool(gate and str(gate.get("status") or "").upper()=="PASS"), "reason": "historical_final_gate_never_directly_imported"},
        }
        missing_actions = []
        for row in regression.get("missing_test_groups", []):
            missing_actions.append({"node":"FULL_REGRESSION","kind":"fixture_group","target":row["fixture"],"count":row["tests"]})
        # Absence of a reconciliation record is itself an unresolved regression obligation.
        # Do not allow a zero numeric gap to accidentally look complete when there is no
        # historical inventory proving what the old suite actually covered.
        if not regression.get("complete") and not regression.get("missing_test_groups"):
            missing_actions.append({
                "node":"FULL_REGRESSION",
                "kind":"certificate_or_replay",
                "target":"historical_regression_evidence_capsule_or_replay",
            })
        for name in tournament.get("missing_matchups", []): missing_actions.append({"node":"TOURNAMENT_FINAL","kind":"matchup","target":name})
        if not holdout_certified:
            if holdout_bound and commit and not holdout_runtime:
                missing_actions.append({"node":"RUNTIME_LINEAGE","kind":"exact_hash_recovery","target":"sealed_holdout_runtime","required":holdout_runtime_checks})
            else:
                missing_actions.append({"node":"SEALED_HOLDOUT","kind":"certificate_or_replay","target":"sealed_holdout"})
        if not ci_certified:
            if holdout_bound and commit and not holdout_runtime:
                # One exact runtime recovery can satisfy both Holdout and Final CI.
                pass
            else:
                missing_actions.append({"node":"FINAL_CI","kind":"certificate_or_replay","target":"final_ci"})

        certificate_payload = {
            "capsule_sha256": capsule_hash,
            "deck_fingerprint": declared_deck_fp or None,
            "ruleset_date": ruleset_date,
            "player_dsl_sha256": player_dsl_sha,
            "runtime_engine_bundle_fingerprint": ((run.get("historical_runtime") or {}).get("engine_bundle_fingerprint") if isinstance(run.get("historical_runtime"),dict) else None),
            "manifest_sha256": [m["manifest_sha256"] for m in manifest_records],
            "certified_nodes": sorted(k for k,v in nodes.items() if v.get("certified")),
        }
        cert_hash = hashlib.sha256(json.dumps(certificate_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        record = {
            "schema": "v20.18.4-historical-evidence-certificate-v1",
            "status": "VERIFIED_PARTIAL" if manifest_ok else "UNVERIFIED_MANIFEST",
            "capsule_sha256": capsule_hash,
            "source_file": copy.deepcopy(source_file) if source_file else None,
            "manifest_ok": manifest_ok,
            "manifest_records": manifest_records,
            "manifest_verified_file_count": len(verified_paths),
            "gate_manifest_bound": gate_bound,
            "gate_runtime_match": gate_runtime_match,
            "gate_runtime_checks": gate_runtime_checks,
            "gate_dsl_match": gate_dsl_match,
            "nodes": nodes,
            "replay_plan": {"missing_actions": missing_actions, "missing_action_count": len(missing_actions), "missing_regression_test_total": regression.get("missing_test_total",0), "missing_tournament_matchups": tournament.get("missing_matchups",[])},
            "certificate_fingerprint": cert_hash,
            "certificate_payload": certificate_payload,
        }
        # Keep extracted bytes for audit/replay. A content-addressed destination prevents
        # attaching the same capsule twice from mutating prior evidence.
        dest = self.storage_root / "capsules" / capsule_hash
        if dest.exists(): shutil.rmtree(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(extracted, dest)
        record["capsule_root"] = str(dest.resolve())
        archive_dest = self.storage_root / "archives" / f"{capsule_hash}.zip"
        archive_dest.parent.mkdir(parents=True, exist_ok=True)
        if not archive_dest.exists(): shutil.copy2(archive_path, archive_dest)
        record["archive_path"] = str(archive_dest.resolve())
        shutil.rmtree(work, ignore_errors=True)
        return record
