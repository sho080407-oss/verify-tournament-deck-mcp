from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from pathlib import Path

SCHEMA_VERSION = 1


def canonical_json(data: object) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def state_hash(data: object) -> str:
    return hashlib.sha256(canonical_json(data).encode("utf-8")).hexdigest()


def database_path_from_runs_root(runs_root: str | Path) -> Path:
    return Path(runs_root) / ".state.sqlite3"


def database_path_from_tenant_root(tenant_root: str | Path) -> Path:
    return Path(tenant_root) / "runs" / ".state.sqlite3"


def connect(path: str | Path) -> sqlite3.Connection:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(p, timeout=30.0, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    # FULL is deliberate: verifier checkpoints are low-frequency compared with engine compute.
    con.execute("PRAGMA synchronous=FULL")
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=30000")
    return con


def initialize(path: str | Path) -> None:
    con = connect(path)
    try:
        con.execute("BEGIN IMMEDIATE")
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS metadata(
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS runs(
                run_id TEXT PRIMARY KEY,
                revision INTEGER NOT NULL CHECK(revision >= 1),
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                state_json TEXT NOT NULL,
                state_hash TEXT NOT NULL
            )
            """
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_runs_updated_at ON runs(updated_at DESC)")
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS secrets(
                run_id TEXT PRIMARY KEY,
                updated_at TEXT NOT NULL,
                secret_json TEXT NOT NULL,
                FOREIGN KEY(run_id) REFERENCES runs(run_id) ON DELETE CASCADE
            )
            """
        )
        con.execute(
            """
            CREATE TABLE IF NOT EXISTS operations(
                op_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                operation TEXT NOT NULL,
                request_id TEXT,
                status TEXT NOT NULL,
                started_at TEXT NOT NULL,
                started_ts REAL NOT NULL,
                finished_at TEXT,
                pid INTEGER,
                error TEXT
            )
            """
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_operations_run_status ON operations(run_id,status,started_ts)")
        con.execute(
            "INSERT INTO metadata(key,value) VALUES('schema_version',?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (str(SCHEMA_VERSION),),
        )
        con.execute("COMMIT")
    except Exception:
        try:
            con.execute("ROLLBACK")
        except Exception:
            pass
        raise
    finally:
        con.close()
    try:
        os.chmod(Path(path), 0o600)
    except OSError:
        pass
